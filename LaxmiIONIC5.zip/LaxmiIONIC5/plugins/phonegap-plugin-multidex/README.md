# phonegap-plugin-multidex

Enable multidex in a Apache Cordova/PhoneGap application

## Installation

    phonegap plugin add phonegap-plugin-image-multidex

    phonegap plugin add https://github.com/phonegap/phonegap-plugin-multidex.git
