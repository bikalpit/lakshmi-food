function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["order-summary-order-summary-module"], {
  /***/
  "./node_modules/@ionic-native/downloader/__ivy_ngcc__/ngx/index.js":
  /*!*************************************************************************!*\
    !*** ./node_modules/@ionic-native/downloader/__ivy_ngcc__/ngx/index.js ***!
    \*************************************************************************/

  /*! exports provided: NotificationVisibility, Downloader */

  /***/
  function node_modulesIonicNativeDownloader__ivy_ngcc__NgxIndexJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NotificationVisibility", function () {
      return NotificationVisibility;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Downloader", function () {
      return Downloader;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/core */
    "./node_modules/@ionic-native/core/__ivy_ngcc__/index.js");

    var NotificationVisibility;

    (function (NotificationVisibility) {
      NotificationVisibility[NotificationVisibility["Visible"] = 0] = "Visible";
      NotificationVisibility[NotificationVisibility["VisibleNotifyCompleted"] = 1] = "VisibleNotifyCompleted";
      NotificationVisibility[NotificationVisibility["VisibilityHidden"] = 2] = "VisibilityHidden";
      NotificationVisibility[NotificationVisibility["VisibleNotifyOnlyCompletion"] = 3] = "VisibleNotifyOnlyCompletion";
    })(NotificationVisibility || (NotificationVisibility = {}));

    var Downloader =
    /** @class */
    function (_super) {
      Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(Downloader, _super);

      function Downloader() {
        return _super !== null && _super.apply(this, arguments) || this;
      }

      Downloader.prototype.download = function (request) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "download", {}, arguments);
      };

      Downloader.pluginName = "Downloader";
      Downloader.plugin = "integrator-cordova-plugin-downloader";
      Downloader.pluginRef = "cordova.plugins.Downloader";
      Downloader.repo = "https://github.com/Luka313/integrator-cordova-plugin-downloader.git";
      Downloader.platforms = ["Android"];

      Downloader.ɵfac = function Downloader_Factory(t) {
        return ɵDownloader_BaseFactory(t || Downloader);
      };

      Downloader.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
        token: Downloader,
        factory: function factory(t) {
          return Downloader.ɵfac(t);
        }
      });

      var ɵDownloader_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetInheritedFactory"](Downloader);
      /*@__PURE__*/


      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](Downloader, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"]
        }], null, null);
      })();

      return Downloader;
    }(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["IonicNativePlugin"]); //# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9AaW9uaWMtbmF0aXZlL3BsdWdpbnMvZG93bmxvYWRlci9uZ3gvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyw4QkFBc0MsTUFBTSxvQkFBb0IsQ0FBQzs7QUFFeEUsTUFBTSxDQUFOLElBQVksc0JBS1g7QUFMRCxXQUFZLHNCQUFzQjtBQUNqQyxJQUFDLHlFQUFXLENBQUE7QUFBQyxJQUNaLHVHQUEwQixDQUFBO0FBQUMsSUFDM0IsMkZBQW9CLENBQUE7QUFBQyxJQUNyQixpSEFBK0IsQ0FBQTtBQUNqQyxDQUFDLEVBTFcsc0JBQXNCLEtBQXRCLHNCQUFzQixRQUtqQztBQUNEO0FBRWEsSUF1R21CLDhCQUFpQjtBQUFDO0FBRTlCO0FBQ2I7QUFBTSxJQUdYLDZCQUFRLGFBQUMsT0FBd0I7QUFJbEI7QUFBMEM7QUFBZ0U7QUFBeUQ7QUFBNkY7SUFWcFEsVUFBVSx3QkFEdEIsVUFBVSxFQUFFLFFBQ0EsVUFBVTs7Ozs7MEJBQUU7QUFBQyxxQkFsSDFCO0FBQUUsRUFrSDhCLGlCQUFpQjtBQUNoRCxTQURZLFVBQVU7QUFBSSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvcmRvdmEsIElvbmljTmF0aXZlUGx1Z2luLCBQbHVnaW4gfSBmcm9tICdAaW9uaWMtbmF0aXZlL2NvcmUnO1xuXG5leHBvcnQgZW51bSBOb3RpZmljYXRpb25WaXNpYmlsaXR5IHtcbiAgVmlzaWJsZSA9IDAsXG4gIFZpc2libGVOb3RpZnlDb21wbGV0ZWQgPSAxLFxuICBWaXNpYmlsaXR5SGlkZGVuID0gMixcbiAgVmlzaWJsZU5vdGlmeU9ubHlDb21wbGV0aW9uID0gMyxcbn1cblxuZXhwb3J0IGludGVyZmFjZSBEb3dubG9hZEh0dHBIZWFkZXIge1xuICBoZWFkZXI6IHN0cmluZztcbiAgdmFsdWU6IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBEZXN0aW5hdGlvbkRpcmVjdG9yeSB7XG4gIGRpclR5cGU6IHN0cmluZztcbiAgc3ViUGF0aDogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIERvd25sb2FkUmVxdWVzdCB7XG4gIC8qKlxuICAgKiBMb2NhdGlvbiBvZiB0aGUgcmVzb3VyY2UgdG8gZG93bmxvYWRcbiAgICovXG4gIHVyaTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBTZXQgdGhlIHRpdGxlIG9mIHRoaXMgZG93bmxvYWQsIHRvIGJlIGRpc3BsYXllZCBpbiBub3RpZmljYXRpb25zIChpZiBlbmFibGVkKS5cbiAgICogSWYgbm8gdGl0bGUgaXMgZ2l2ZW4sIGEgZGVmYXVsdCBvbmUgd2lsbCBiZSBhc3NpZ25lZCBiYXNlZCBvbiB0aGUgZG93bmxvYWQgZmlsZW5hbWUsIG9uY2UgdGhlIGRvd25sb2FkIHN0YXJ0cy5cbiAgICovXG4gIHRpdGxlPzogc3RyaW5nO1xuICAvKipcbiAgICogU2V0IGEgZGVzY3JpcHRpb24gb2YgdGhpcyBkb3dubG9hZCwgdG8gYmUgZGlzcGxheWVkIGluIG5vdGlmaWNhdGlvbnMgKGlmIGVuYWJsZWQpXG4gICAqL1xuICBkZXNjcmlwdGlvbj86IHN0cmluZztcbiAgLyoqXG4gICAqIFNldCB0aGUgTUlNRSBjb250ZW50IHR5cGUgb2YgdGhpcyBkb3dubG9hZC4gVGhpcyB3aWxsIG92ZXJyaWRlIHRoZSBjb250ZW50IHR5cGUgZGVjbGFyZWQgaW4gdGhlIHNlcnZlcidzIHJlc3BvbnNlLlxuICAgKi9cbiAgbWltZVR5cGU/OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBTZXQgd2hldGhlciB0aGlzIGRvd25sb2FkIHNob3VsZCBiZSBkaXNwbGF5ZWQgaW4gdGhlIHN5c3RlbSdzIERvd25sb2FkcyBVSS4gVHJ1ZSBieSBkZWZhdWx0LlxuICAgKi9cbiAgdmlzaWJsZUluRG93bmxvYWRzVWk/OiBib29sZWFuO1xuICAvKipcbiAgICogQ29udHJvbCB3aGV0aGVyIGEgc3lzdGVtIG5vdGlmaWNhdGlvbiBpcyBwb3N0ZWQgYnkgdGhlIGRvd25sb2FkIG1hbmFnZXIgd2hpbGUgdGhpcyBkb3dubG9hZCBpcyBydW5uaW5nIG9yIHdoZW4gaXQgaXMgY29tcGxldGVkLlxuICAgKi9cbiAgbm90aWZpY2F0aW9uVmlzaWJpbGl0eT86IE5vdGlmaWNhdGlvblZpc2liaWxpdHk7XG4gIC8qKlxuICAgKiBTZXQgdGhlIGxvY2FsIGRlc3RpbmF0aW9uIGZvciB0aGUgZG93bmxvYWRlZCBmaWxlIHRvIGEgcGF0aCB3aXRoaW4gdGhlIGFwcGxpY2F0aW9uJ3MgZXh0ZXJuYWwgZmlsZXMgZGlyZWN0b3J5XG4gICAqL1xuICBkZXN0aW5hdGlvbkluRXh0ZXJuYWxGaWxlc0Rpcj86IERlc3RpbmF0aW9uRGlyZWN0b3J5O1xuICAvKipcbiAgICogU2V0IHRoZSBsb2NhbCBkZXN0aW5hdGlvbiBmb3IgdGhlIGRvd25sb2FkZWQgZmlsZSB0byBhIHBhdGggd2l0aGluIHRoZSBwdWJsaWMgZXh0ZXJuYWwgc3RvcmFnZSBkaXJlY3RvcnlcbiAgICovXG4gIGRlc3RpbmF0aW9uSW5FeHRlcm5hbFB1YmxpY0Rpcj86IERlc3RpbmF0aW9uRGlyZWN0b3J5O1xuICAvKipcbiAgICogU2V0IHRoZSBsb2NhbCBkZXN0aW5hdGlvbiBmb3IgdGhlIGRvd25sb2FkZWQgZmlsZS5cbiAgICogTXVzdCBiZSBhIGZpbGUgVVJJIHRvIGEgcGF0aCBvbiBleHRlcm5hbCBzdG9yYWdlLCBhbmQgdGhlIGNhbGxpbmcgYXBwbGljYXRpb24gbXVzdCBoYXZlIHRoZSBXUklURV9FWFRFUk5BTF9TVE9SQUdFIHBlcm1pc3Npb24uXG4gICAqL1xuICBkZXN0aW5hdGlvblVyaT86IHN0cmluZztcbiAgLyoqXG4gICAqIEFkZCBhbiBIVFRQIGhlYWRlciB0byBiZSBpbmNsdWRlZCB3aXRoIHRoZSBkb3dubG9hZCByZXF1ZXN0LiBUaGUgaGVhZGVyIHdpbGwgYmUgYWRkZWQgdG8gdGhlIGVuZCBvZiB0aGUgbGlzdC5cbiAgICovXG4gIGhlYWRlcnM/OiBEb3dubG9hZEh0dHBIZWFkZXJbXTtcbn1cblxuLyoqXG4gKiBAbmFtZSBEb3dubG9hZGVyXG4gKiBAZGVzY3JpcHRpb25cbiAqIFRoaXMgcGx1Z2luIGlzIGRlc2lnbmVkIHRvIHN1cHBvcnQgZG93bmxvYWRpbmcgZmlsZXMgdXNpbmcgQW5kcm9pZCBEb3dubG9hZE1hbmFnZXIuXG4gKlxuICpcbiAqIEB1c2FnZVxuICogYGBgdHlwZXNjcmlwdFxuICogaW1wb3J0IHsgRG93bmxvYWRlciB9IGZyb20gJ0Bpb25pYy1uYXRpdmUvZG93bmxvYWRlci9uZ3gnO1xuICpcbiAqXG4gKiBjb25zdHJ1Y3Rvcihwcml2YXRlIGRvd25sb2FkZXI6IERvd25sb2FkZXIpIHsgfVxuICpcbiAqIC4uLlxuICpcbiAqICAgIHZhciByZXF1ZXN0OiBEb3dubG9hZFJlcXVlc3QgPSB7XG4gKiAgICAgICAgICAgdXJpOiBZT1VSX1VSSSxcbiAqICAgICAgICAgICB0aXRsZTogJ015RG93bmxvYWQnLFxuICogICAgICAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAqICAgICAgICAgICBtaW1lVHlwZTogJycsXG4gKiAgICAgICAgICAgdmlzaWJsZUluRG93bmxvYWRzVWk6IHRydWUsXG4gKiAgICAgICAgICAgbm90aWZpY2F0aW9uVmlzaWJpbGl0eTogTm90aWZpY2F0aW9uVmlzaWJpbGl0eS5WaXNpYmxlTm90aWZ5Q29tcGxldGVkLFxuICogICAgICAgICAgIGRlc3RpbmF0aW9uSW5FeHRlcm5hbEZpbGVzRGlyOiB7XG4gKiAgICAgICAgICAgICAgIGRpclR5cGU6ICdEb3dubG9hZHMnLFxuICogICAgICAgICAgICAgICBzdWJQYXRoOiAnTXlGaWxlLmFwaydcbiAqICAgICAgICAgICB9XG4gKiAgICAgICB9O1xuICpcbiAqXG4gKiAgIHRoaXMuZG93bmxvYWRlci5kb3dubG9hZChyZXF1ZXN0KVxuICogICBcdFx0XHQudGhlbigobG9jYXRpb246IHN0cmluZykgPT4gY29uc29sZS5sb2coJ0ZpbGUgZG93bmxvYWRlZCBhdDonK2xvY2F0aW9uKSlcbiAqICAgXHRcdFx0LmNhdGNoKChlcnJvcjogYW55KSA9PiBjb25zb2xlLmVycm9yKGVycm9yKSk7XG4gKlxuICogYGBgXG4gKiBAaW50ZXJmYWNlc1xuICogTm90aWZpY2F0aW9uVmlzaWJpbGl0eVxuICogSGVhZGVyXG4gKiBEZXN0aW5hdGlvbkRpcmVjdG9yeVxuICogRG93bmxvYWRIdHRwSGVhZGVyXG4gKi9cbkBQbHVnaW4oe1xuICBwbHVnaW5OYW1lOiAnRG93bmxvYWRlcicsXG4gIHBsdWdpbjogJ2ludGVncmF0b3ItY29yZG92YS1wbHVnaW4tZG93bmxvYWRlcicsXG4gIHBsdWdpblJlZjogJ2NvcmRvdmEucGx1Z2lucy5Eb3dubG9hZGVyJyxcbiAgcmVwbzogJ2h0dHBzOi8vZ2l0aHViLmNvbS9MdWthMzEzL2ludGVncmF0b3ItY29yZG92YS1wbHVnaW4tZG93bmxvYWRlci5naXQnLFxuICBwbGF0Zm9ybXM6IFsnQW5kcm9pZCddLFxufSlcbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBEb3dubG9hZGVyIGV4dGVuZHMgSW9uaWNOYXRpdmVQbHVnaW4ge1xuICAvKipcbiAgICogIFN0YXJ0cyBhIG5ldyBkb3dubG9hZCBhbmQgcmV0dXJucyBsb2NhdGlvbiBvZiB0aGUgZG93bmxvYWRlZCBmaWxlIG9uIGNvbXBsZXRpb25cbiAgICogIEBwYXJhbSByZXF1ZXN0IHtEb3dubG9hZFJlcXVlc3R9XG4gICAqL1xuICBAQ29yZG92YSgpXG4gIGRvd25sb2FkKHJlcXVlc3Q6IERvd25sb2FkUmVxdWVzdCk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgcmV0dXJuO1xuICB9XG59XG4iXX0=

    /***/

  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/order-summary/order-summary.page.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/order-summary/order-summary.page.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppOrderSummaryOrderSummaryPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <!-- <ion-back-button (click)=\"goBack()\" color=\"danger\"></ion-back-button> -->\n      <ion-icon name=\"arrow-back-outline\" class=\"backarrow1\" (click)=\" goBack()\"></ion-icon>\n    </ion-buttons>\n    <!-- <ion-buttons slot=\"start\" class=\"menu_btn\">\n      <ion-menu-button auto-hide=\"false\"></ion-menu-button>\n    </ion-buttons> -->\n    <ion-buttons slot=\"end\">\n      <ion-button>\n\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"main-title\">Order Summary</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div *ngIf=\"ordersDetails\">\n    <ion-card class=\"main-card\">\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"4\">\n            <h4 class=\"p-label2\">Total</h4>\n          </ion-col>\n\n          <ion-col>\n            <h6 class=\"p-label\">Order Date</h6>\n          </ion-col>\n\n        </ion-row>\n      </ion-grid>\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"4\">\n            <h4 class=\"p-price\">₹{{ordersDetails.order_total}}</h4>\n          </ion-col>\n\n          <ion-col>\n            <h6 class=\"p-date\">{{orderDate}}</h6>\n          </ion-col>\n\n        </ion-row>\n      </ion-grid>\n    </ion-card>\n\n    <ion-card class=\"main-card-item\">\n      <div *ngFor=\"let item of orderItem;\" style=\"margin-top: 10px;\">\n\n        <h6 class=\"p-qty\">{{item.product_name}}</h6>\n\n        <ion-row>\n          <ion-col>\n            <h6 class=\"p-qty\">Qty item.qty * ₹{{item.product_price}}</h6>\n          </ion-col>\n\n          <h6 class=\"p-label4\">₹{{item.price}}</h6>\n        </ion-row>\n      </div>\n    </ion-card>\n  </div>\n  <ion-row style=\"margin-top: 14%;\" *ngIf=\"ordersDetails.status==='New'\">\n    <ion-col>\n      <button ion-button class=\"cancelOrder_btn\" (click)=\"fnCancelOrder()\">Cancel Order</button>\n\n    </ion-col>\n\n    <ion-col>\n      <button ion-button class=\"download_btn\" (click)=\"fnDownload()\">Download</button>\n    </ion-col>\n  </ion-row>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/order-summary/order-summary-routing.module.ts":
  /*!***************************************************************!*\
    !*** ./src/app/order-summary/order-summary-routing.module.ts ***!
    \***************************************************************/

  /*! exports provided: OrderSummaryPageRoutingModule */

  /***/
  function srcAppOrderSummaryOrderSummaryRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OrderSummaryPageRoutingModule", function () {
      return OrderSummaryPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _order_summary_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./order-summary.page */
    "./src/app/order-summary/order-summary.page.ts");

    var routes = [{
      path: '',
      component: _order_summary_page__WEBPACK_IMPORTED_MODULE_3__["OrderSummaryPage"]
    }];

    var OrderSummaryPageRoutingModule = function OrderSummaryPageRoutingModule() {
      _classCallCheck(this, OrderSummaryPageRoutingModule);
    };

    OrderSummaryPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], OrderSummaryPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/order-summary/order-summary.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/order-summary/order-summary.module.ts ***!
    \*******************************************************/

  /*! exports provided: OrderSummaryPageModule */

  /***/
  function srcAppOrderSummaryOrderSummaryModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OrderSummaryPageModule", function () {
      return OrderSummaryPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _order_summary_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./order-summary-routing.module */
    "./src/app/order-summary/order-summary-routing.module.ts");
    /* harmony import */


    var _order_summary_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./order-summary.page */
    "./src/app/order-summary/order-summary.page.ts");
    /* harmony import */


    var _ionic_native_downloader_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @ionic-native/downloader/ngx */
    "./node_modules/@ionic-native/downloader/__ivy_ngcc__/ngx/index.js");

    var OrderSummaryPageModule = function OrderSummaryPageModule() {
      _classCallCheck(this, OrderSummaryPageModule);
    };

    OrderSummaryPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _ionic_native_downloader_ngx__WEBPACK_IMPORTED_MODULE_7__["Downloader"], _order_summary_routing_module__WEBPACK_IMPORTED_MODULE_5__["OrderSummaryPageRoutingModule"]],
      declarations: [_order_summary_page__WEBPACK_IMPORTED_MODULE_6__["OrderSummaryPage"]]
    })], OrderSummaryPageModule);
    /***/
  },

  /***/
  "./src/app/order-summary/order-summary.page.scss":
  /*!*******************************************************!*\
    !*** ./src/app/order-summary/order-summary.page.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppOrderSummaryOrderSummaryPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".menu_btn {\n  color: #E4322E;\n}\n\n.main-title {\n  color: #E4322E;\n}\n\n.main-card {\n  box-shadow: 5px 7px 10px 5px #e8e8e8;\n  margin-top: 20px;\n  background-color: #fff;\n}\n\n.p-label2 {\n  margin-top: 0px;\n  margin-bottom: 0px;\n  margin-right: 10px;\n  color: #000;\n  font-size: 16px;\n}\n\n.p-label {\n  margin-top: 0px;\n  margin-bottom: 0px;\n  margin-right: 10px;\n  color: #000;\n  float: right;\n  font-size: 16px;\n}\n\n.p-price {\n  font-size: 25px;\n  margin-top: 0px;\n  margin-bottom: 0px;\n  margin-right: 10px;\n  color: #000;\n}\n\n.p-date {\n  margin-top: 0px;\n  margin-bottom: 0px;\n  margin-right: 10px;\n  color: #000;\n  float: right;\n  font-size: 22px;\n}\n\n.p-qty {\n  color: #000;\n  margin: 0;\n  margin-left: 10px;\n}\n\n.p-label3 {\n  margin-bottom: 10px;\n  margin-left: 10px;\n  color: #010944;\n}\n\n.p-label4 {\n  margin-top: 0px;\n  margin-bottom: 0px;\n  margin-right: 10px;\n  color: #000;\n  float: right;\n}\n\n.p-qty1 {\n  color: #000;\n  margin: 0;\n  margin-left: 10px;\n  margin-top: 14px;\n}\n\n.Subtotal {\n  margin-top: 0px;\n  margin-bottom: 0px;\n  margin-right: 10px;\n  color: #000;\n}\n\n.main-card-item {\n  box-shadow: 5px 7px 10px 5px #e8e8e8;\n  background-color: #fff;\n  height: 30%;\n}\n\n.main-card-total {\n  box-shadow: 5px 7px 10px 5px #e8e8e8;\n  background-color: #fff;\n  height: 20%;\n}\n\n.cancelOrder_btn {\n  background-color: #E4322E;\n  color: #fff;\n  font-size: 20px;\n  height: 60px;\n  width: 90%;\n  border-radius: 8px;\n  display: block;\n  margin: auto;\n  border: 1px solid #fff;\n  margin-right: 12px;\n  margin-left: 6px;\n  margin-top: 3px;\n}\n\n.download_btn {\n  background-color: #E4322E;\n  color: #fff;\n  font-size: 20px;\n  height: 60px;\n  width: 90%;\n  border-radius: 8px;\n  display: block;\n  margin: auto;\n  border: 1px solid #fff;\n  margin-right: 12px;\n  margin-left: 12px;\n  margin-top: 3px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9vcmRlci1zdW1tYXJ5L29yZGVyLXN1bW1hcnkucGFnZS5zY3NzIiwic3JjL2FwcC9vcmRlci1zdW1tYXJ5L29yZGVyLXN1bW1hcnkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtBQ0NKOztBRENBO0VBQ0ksY0FBQTtBQ0VKOztBREFBO0VBQ0ksb0NBQUE7RUFDQSxnQkFBQTtFQUNBLHNCQUFBO0FDR0o7O0FEREE7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0FDSUo7O0FEREE7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtBQ0lKOztBREZBO0VBQ0ksZUFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtBQ0tKOztBREZBO0VBQ0ksZUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7QUNLSjs7QURIQTtFQUNJLFdBQUE7RUFDQSxTQUFBO0VBQ0EsaUJBQUE7QUNNSjs7QURIQTtFQUNJLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FDTUo7O0FESkE7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDT0o7O0FETEE7RUFDSSxXQUFBO0VBQ0EsU0FBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUNRSjs7QUROQTtFQUNJLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtBQ1NKOztBRE5BO0VBQ0ksb0NBQUE7RUFDQSxzQkFBQTtFQUNBLFdBQUE7QUNTSjs7QURQQTtFQUNJLG9DQUFBO0VBQ0Esc0JBQUE7RUFDQSxXQUFBO0FDVUo7O0FEUEE7RUFDSSx5QkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQ1VKOztBRFJBO0VBQ0kseUJBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUNXSiIsImZpbGUiOiJzcmMvYXBwL29yZGVyLXN1bW1hcnkvb3JkZXItc3VtbWFyeS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWVudV9idG57XG4gICAgY29sb3I6ICNFNDMyMkU7XG59XG4ubWFpbi10aXRsZXtcbiAgICBjb2xvcjogI0U0MzIyRTtcbn1cbi5tYWluLWNhcmR7XG4gICAgYm94LXNoYWRvdzogNXB4IDdweCAxMHB4IDVweCAjZThlOGU4O1xuICAgIG1hcmdpbi10b3A6IDIwcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbn1cbi5wLWxhYmVsMntcbiAgICBtYXJnaW4tdG9wOiAwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICBjb2xvcjogIzAwMDtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgLy9mbG9hdDogcmlnaHQ7XG59XG4ucC1sYWJlbHtcbiAgICBtYXJnaW4tdG9wOiAwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICBjb2xvcjogIzAwMDtcbiAgICBmbG9hdDogcmlnaHQ7XG4gICAgZm9udC1zaXplOiAxNnB4O1xufVxuLnAtcHJpY2V7XG4gICAgZm9udC1zaXplOiAyNXB4O1xuICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgIGNvbG9yOiAjMDAwO1xuICAgIFxufVxuLnAtZGF0ZXtcbiAgICBtYXJnaW4tdG9wOiAwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICBjb2xvcjogIzAwMDtcbiAgICBmbG9hdDogcmlnaHQ7XG4gICAgZm9udC1zaXplOiAyMnB4O1xufVxuLnAtcXR5e1xuICAgIGNvbG9yOiAjMDAwO1xuICAgIG1hcmdpbjogMDtcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbn1cblxuLnAtbGFiZWwze1xuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgY29sb3I6ICMwMTA5NDQ7XG59XG4ucC1sYWJlbDR7XG4gICAgbWFyZ2luLXRvcDogMHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDBweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgY29sb3I6ICMwMDA7XG4gICAgZmxvYXQ6IHJpZ2h0O1xufVxuLnAtcXR5MXtcbiAgICBjb2xvcjogIzAwMDtcbiAgICBtYXJnaW46IDA7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgbWFyZ2luLXRvcDogMTRweDtcbn1cbi5TdWJ0b3RhbHtcbiAgICBtYXJnaW4tdG9wOiAwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICBjb2xvcjogIzAwMDtcbiAgICAvLyBmbG9hdDogcmlnaHQ7XG59XG4ubWFpbi1jYXJkLWl0ZW17XG4gICAgYm94LXNoYWRvdzogNXB4IDdweCAxMHB4IDVweCAjZThlOGU4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gICAgaGVpZ2h0OiAzMCU7XG59XG4ubWFpbi1jYXJkLXRvdGFse1xuICAgIGJveC1zaGFkb3c6IDVweCA3cHggMTBweCA1cHggI2U4ZThlODtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAgIGhlaWdodDogMjAlO1xuXG59XG4uY2FuY2VsT3JkZXJfYnRue1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNFNDMyMkU7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGhlaWdodDogNjBweDtcbiAgICB3aWR0aDogOTAlO1xuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBtYXJnaW46IGF1dG87XG4gICAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbiAgICBtYXJnaW4tcmlnaHQ6IDEycHg7XG4gICAgbWFyZ2luLWxlZnQ6IDZweDtcbiAgICBtYXJnaW4tdG9wOiAzcHg7XG59XG4uZG93bmxvYWRfYnRue1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNFNDMyMkU7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGhlaWdodDogNjBweDtcbiAgICB3aWR0aDogOTAlO1xuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBtYXJnaW46IGF1dG87XG4gICAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbiAgICBtYXJnaW4tcmlnaHQ6IDEycHg7XG4gICAgbWFyZ2luLWxlZnQ6IDEycHg7XG4gICAgbWFyZ2luLXRvcDogM3B4OyAgXG59XG4iLCIubWVudV9idG4ge1xuICBjb2xvcjogI0U0MzIyRTtcbn1cblxuLm1haW4tdGl0bGUge1xuICBjb2xvcjogI0U0MzIyRTtcbn1cblxuLm1haW4tY2FyZCB7XG4gIGJveC1zaGFkb3c6IDVweCA3cHggMTBweCA1cHggI2U4ZThlODtcbiAgbWFyZ2luLXRvcDogMjBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbn1cblxuLnAtbGFiZWwyIHtcbiAgbWFyZ2luLXRvcDogMHB4O1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbiAgY29sb3I6ICMwMDA7XG4gIGZvbnQtc2l6ZTogMTZweDtcbn1cblxuLnAtbGFiZWwge1xuICBtYXJnaW4tdG9wOiAwcHg7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICBjb2xvcjogIzAwMDtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBmb250LXNpemU6IDE2cHg7XG59XG5cbi5wLXByaWNlIHtcbiAgZm9udC1zaXplOiAyNXB4O1xuICBtYXJnaW4tdG9wOiAwcHg7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICBjb2xvcjogIzAwMDtcbn1cblxuLnAtZGF0ZSB7XG4gIG1hcmdpbi10b3A6IDBweDtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIGNvbG9yOiAjMDAwO1xuICBmbG9hdDogcmlnaHQ7XG4gIGZvbnQtc2l6ZTogMjJweDtcbn1cblxuLnAtcXR5IHtcbiAgY29sb3I6ICMwMDA7XG4gIG1hcmdpbjogMDtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG59XG5cbi5wLWxhYmVsMyB7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBjb2xvcjogIzAxMDk0NDtcbn1cblxuLnAtbGFiZWw0IHtcbiAgbWFyZ2luLXRvcDogMHB4O1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbiAgY29sb3I6ICMwMDA7XG4gIGZsb2F0OiByaWdodDtcbn1cblxuLnAtcXR5MSB7XG4gIGNvbG9yOiAjMDAwO1xuICBtYXJnaW46IDA7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBtYXJnaW4tdG9wOiAxNHB4O1xufVxuXG4uU3VidG90YWwge1xuICBtYXJnaW4tdG9wOiAwcHg7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICBjb2xvcjogIzAwMDtcbn1cblxuLm1haW4tY2FyZC1pdGVtIHtcbiAgYm94LXNoYWRvdzogNXB4IDdweCAxMHB4IDVweCAjZThlOGU4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICBoZWlnaHQ6IDMwJTtcbn1cblxuLm1haW4tY2FyZC10b3RhbCB7XG4gIGJveC1zaGFkb3c6IDVweCA3cHggMTBweCA1cHggI2U4ZThlODtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgaGVpZ2h0OiAyMCU7XG59XG5cbi5jYW5jZWxPcmRlcl9idG4ge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTQzMjJFO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBoZWlnaHQ6IDYwcHg7XG4gIHdpZHRoOiA5MCU7XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbjogYXV0bztcbiAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbiAgbWFyZ2luLXJpZ2h0OiAxMnB4O1xuICBtYXJnaW4tbGVmdDogNnB4O1xuICBtYXJnaW4tdG9wOiAzcHg7XG59XG5cbi5kb3dubG9hZF9idG4ge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTQzMjJFO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBoZWlnaHQ6IDYwcHg7XG4gIHdpZHRoOiA5MCU7XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbjogYXV0bztcbiAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbiAgbWFyZ2luLXJpZ2h0OiAxMnB4O1xuICBtYXJnaW4tbGVmdDogMTJweDtcbiAgbWFyZ2luLXRvcDogM3B4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/order-summary/order-summary.page.ts":
  /*!*****************************************************!*\
    !*** ./src/app/order-summary/order-summary.page.ts ***!
    \*****************************************************/

  /*! exports provided: OrderSummaryPage */

  /***/
  function srcAppOrderSummaryOrderSummaryPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OrderSummaryPage", function () {
      return OrderSummaryPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../auth.service */
    "./src/app/auth.service.ts");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");

    var OrderSummaryPage = /*#__PURE__*/function () {
      function OrderSummaryPage(datePipe, location, router, route, navCtrl, auth) {
        _classCallCheck(this, OrderSummaryPage);

        this.datePipe = datePipe;
        this.location = location;
        this.router = router;
        this.route = route;
        this.navCtrl = navCtrl;
        this.auth = auth;
        this.ordersDetails = [];
        this.orderItem = [];
        var state = this.router.getCurrentNavigation().extras.state;

        if (state) {
          this.id = state.id;
          this.orderNum = state.order_number;
          console.log("order id-->", this.id);
        }
        /*     console.log("cartData -->", localStorage.getItem("cartData"));
            this.cartData = JSON.parse(localStorage.getItem("cartData"));
            this.mainSubTotal = localStorage.getItem("mainsubtotal"); */

      }

      _createClass(OrderSummaryPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.getOrderDetails();
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.location.back();
        }
      }, {
        key: "fnCancelOrder",
        value: function fnCancelOrder() {
          this.navCtrl.navigateForward('cancel-order', {
            state: {
              id: this.id,
              order_number: this.orderNum
            }
          });
        }
      }, {
        key: "getOrderDetails",
        value: function getOrderDetails() {
          var _this = this;

          this.requestObject = {
            "order_id": this.id
          };
          console.log(this.requestObject);
          this.auth.showLoader();
          this.auth.getOrderDetails(this.requestObject).subscribe(function (data) {
            console.log(data);

            _this.auth.hideLoader();

            _this.dataResponse = data.data;
            _this.ordersDetails = _this.dataResponse;
            _this.date = _this.dataResponse.create_at;
            _this.orderDate = _this.datePipe.transform(new Date(_this.date), "dd-MM-yyyy");
            console.log("order data-->", _this.ordersDetails);
            _this.orderItem = _this.dataResponse.order_item;
            console.log("order list data-->", _this.orderDate);
          }, function (err) {
            _this.auth.hideLoader();

            console.log("Error=>", err); //this.auth.showError(err.error.message);
          });
        }
      }]);

      return OrderSummaryPage;
    }();

    OrderSummaryPage.ctorParameters = function () {
      return [{
        type: _angular_common__WEBPACK_IMPORTED_MODULE_5__["DatePipe"]
      }, {
        type: _angular_common__WEBPACK_IMPORTED_MODULE_5__["Location"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]
      }];
    };

    OrderSummaryPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-order-summary',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./order-summary.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/order-summary/order-summary.page.html"))["default"],
      providers: [_angular_common__WEBPACK_IMPORTED_MODULE_5__["DatePipe"]],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./order-summary.page.scss */
      "./src/app/order-summary/order-summary.page.scss"))["default"]]
    })], OrderSummaryPage);
    /***/
  }
}]);
//# sourceMappingURL=order-summary-order-summary-module-es5.js.map