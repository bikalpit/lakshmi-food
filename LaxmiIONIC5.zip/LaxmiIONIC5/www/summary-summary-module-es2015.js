(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["summary-summary-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/summary/summary.page.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/summary/summary.page.html ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <!-- <ion-back-button (click)=\"goBack()\" color=\"danger\"></ion-back-button>  -->\n      <ion-icon name=\"arrow-back-outline\" class=\"backarrow1\" (click)=\" goBack()\"></ion-icon>\n    </ion-buttons>\n\n    <ion-buttons slot=\"end\">\n      <ion-button>\n\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"main-title\">Order Summary</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div *ngIf=\"ordersDetails\">\n    <ion-card class=\"main-card\">\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"4\">\n            <h4 class=\"p-label2\">Total</h4>\n          </ion-col>\n\n          <ion-col>\n            <h6 class=\"p-label\">Order Date</h6>\n          </ion-col>\n\n        </ion-row>\n      </ion-grid>\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"4\">\n            <h4 class=\"p-price\">₹{{ordersDetails.order_total | number:'1.0-0'}}</h4>\n          </ion-col>\n\n          <ion-col>\n            <h6 class=\"p-date\">{{orderDate}}</h6>\n          </ion-col>\n\n        </ion-row>\n      </ion-grid>\n    </ion-card>\n  </div>\n\n\n  <ion-card class=\"main-card-item\">\n    <ion-card-content>\n      <h5 class=\"p-label3\"><b>Items</b></h5>\n      <div *ngFor=\"let item of ordersDetails.order_item;\" style=\"margin-top: 20px;\">\n\n        <ion-row>\n          <ion-col>\n            <h6 class=\"p-qty\">{{item.product_name}} {{item.product_weight}} Kg</h6>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size=\"8\">\n            <h6 class=\"p-qty\">Qty {{item.qty}} × ₹{{item.product_price}}</h6>\n          </ion-col>\n          <ion-col size=\"4\">\n            <h6 class=\"p-label5\">₹{{item.price}}</h6>\n          </ion-col>\n        </ion-row>\n      </div>\n    </ion-card-content>\n  </ion-card>\n\n  <div *ngIf=\"ordersDetails\">\n    <ion-card class=\"main-card-total\">\n\n      <ion-grid style=\"margin-top: 20px;\">\n        <ion-row>\n          <ion-col size=\"4\">\n            <h5 class=\"Subtotal\">Sub-Total</h5>\n          </ion-col>\n\n          <ion-col>\n            <h6 class=\"p-label4\">₹ {{ordersDetails.order_total}}</h6>\n          </ion-col>\n\n        </ion-row>\n      </ion-grid>\n\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"4\">\n            <h5 class=\"Subtotal\">Shipping</h5>\n          </ion-col>\n          <ion-col>\n            <h6 class=\"p-label4\">₹ 0</h6>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n      <ion-grid style=\"background-color:#f3f3f3;\">\n        <ion-row>\n          <ion-col size=\"4\">\n            <h5 class=\"Subtotal\">Total</h5>\n          </ion-col>\n          <ion-col>\n            <h6 class=\"p-label4\">₹ {{ordersDetails.order_total}}</h6>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n\n      <ion-grid *ngIf=\"ordersDetails.status=='cancel' || ordersDetails.status=='Reject'\">\n        <ion-row>\n          <ion-col size=\"6\">\n            <h5 class=\"Subtotal\" style=\"text-transform:capitalize;\">{{ordersDetails.status}} reason</h5>\n          </ion-col>\n          <ion-col size=\"6\">\n            <h6 class=\"p-label4\">\n              {{ordersDetails.cancel_reason ? ordersDetails.cancel_reason : ordersDetails.order_reject_reason}}</h6>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n\n    </ion-card>\n\n    <ion-card class=\"main-card-item\" *ngIf=\"ordersDetails.DeliveryBoy && ordersDetails.DeliveryBoy!==null\">\n      <ion-card-header>\n        <ion-card-title>Delivery Boy</ion-card-title>\n      </ion-card-header>\n      <ion-item>\n        <ion-avatar slot=\"start\" *ngIf=\"ordersDetails.DeliveryBoy.photo  && ordersDetails.DeliveryBoy.photo !==null\">\n          <img src=\"{{url.file_url}}assets/uploads/users/{{ordersDetails.DeliveryBoy.photo}}\">\n        </ion-avatar>\n        <ion-avatar slot=\"start\" *ngIf=\"ordersDetails.DeliveryBoy.photo === null || ordersDetails.DeliveryBoy.photo ===''\">\n          <img src=\"../../assets/imgs/avatar1.png\">\n        </ion-avatar>\n        <ion-label>\n          <h3>{{ordersDetails.DeliveryBoy.name}}</h3>\n          <p>{{ordersDetails.DeliveryBoy.phone}}</p>\n        </ion-label>\n      </ion-item>\n      <ion-card-content>\n\n      </ion-card-content>\n    </ion-card>\n\n  </div>\n  <ion-row style=\"margin-top: 14%;\">\n    <ion-col *ngIf=\"ordersDetails.status == 'New'\">\n      <button ion-button class=\"cancelOrder_btn\"\n        (click)=\"fnCancelOrder(ordersDetails.id,ordersDetails.order_number)\">Cancel Order</button>\n    </ion-col>\n\n    <ion-col\n      *ngIf=\"ordersDetails.status == 'New' || ordersDetails.status == 'Approve' || ordersDetails.status == 'Assigned' || ordersDetails.status == 'Delivered' || ordersDetails.status == 'Pickup' \">\n      <button ion-button class=\"download_btn\"\n        (click)=\"fnGetPdfUrl(ordersDetails.id,ordersDetails.order_number)\">Download</button>\n    </ion-col>\n  </ion-row>\n</ion-content>");

/***/ }),

/***/ "./src/app/summary/summary-routing.module.ts":
/*!***************************************************!*\
  !*** ./src/app/summary/summary-routing.module.ts ***!
  \***************************************************/
/*! exports provided: SummaryPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SummaryPageRoutingModule", function() { return SummaryPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _summary_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./summary.page */ "./src/app/summary/summary.page.ts");




const routes = [
    {
        path: '',
        component: _summary_page__WEBPACK_IMPORTED_MODULE_3__["SummaryPage"]
    }
];
let SummaryPageRoutingModule = class SummaryPageRoutingModule {
};
SummaryPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SummaryPageRoutingModule);



/***/ }),

/***/ "./src/app/summary/summary.module.ts":
/*!*******************************************!*\
  !*** ./src/app/summary/summary.module.ts ***!
  \*******************************************/
/*! exports provided: SummaryPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SummaryPageModule", function() { return SummaryPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _summary_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./summary-routing.module */ "./src/app/summary/summary-routing.module.ts");
/* harmony import */ var _summary_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./summary.page */ "./src/app/summary/summary.page.ts");







let SummaryPageModule = class SummaryPageModule {
};
SummaryPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _summary_routing_module__WEBPACK_IMPORTED_MODULE_5__["SummaryPageRoutingModule"]
        ],
        declarations: [_summary_page__WEBPACK_IMPORTED_MODULE_6__["SummaryPage"]]
    })
], SummaryPageModule);



/***/ }),

/***/ "./src/app/summary/summary.page.scss":
/*!*******************************************!*\
  !*** ./src/app/summary/summary.page.scss ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".menu_btn {\n  color: #E4322E;\n}\n\n.main-title {\n  color: #E4322E;\n  text-align: center;\n  font-family: open sans;\n}\n\n.main-card {\n  background-color: #fff;\n}\n\n.p-label2 {\n  font-family: open sans;\n  margin-top: 0px;\n  margin-bottom: 0px;\n  color: #000;\n  font-size: 16px;\n}\n\n.p-label {\n  font-family: open sans;\n  margin-top: 0px;\n  margin-bottom: 0px;\n  color: #000;\n  float: right;\n  font-size: 16px;\n}\n\n.p-price {\n  font-family: open sans;\n  font-size: 20px;\n  margin-top: 0px;\n  margin-bottom: 0px;\n  color: #000;\n}\n\n.p-date {\n  font-family: open sans;\n  margin-top: 0px;\n  margin-bottom: 0px;\n  color: #000;\n  float: right;\n  font-size: 20px;\n}\n\n.p-qty {\n  font-family: open sans;\n  color: #000;\n  margin: 0;\n  margin-left: 10px;\n  font-size: 16px;\n}\n\n.p-label3 {\n  font-family: open sans;\n  margin-bottom: 10px;\n  margin-left: 10px;\n  color: #010944;\n  font-size: 16px;\n  margin-top: 10px;\n}\n\n.p-label4 {\n  font-family: open sans;\n  margin-top: 0px;\n  margin-bottom: 0px;\n  color: #000;\n  float: right;\n  font-size: 16px;\n}\n\n.p-label5 {\n  font-family: open sans;\n  margin-top: 0px;\n  margin-bottom: 0px;\n  margin-right: 7px;\n  color: #000;\n  float: right;\n  font-size: 16px;\n}\n\n.p-qty1 {\n  font-family: open sans;\n  color: #000;\n  margin: 0;\n  margin-left: 10px;\n  margin-top: 14px;\n}\n\n.Subtotal {\n  font-family: open sans;\n  margin-top: 0px;\n  margin-bottom: 0px;\n  color: #000;\n}\n\n.main-card-item {\n  background-color: #fff;\n  height: auto;\n  padding-bottom: 10px;\n}\n\n.main-card-item ion-card-content {\n  padding: 0;\n  max-height: calc(125% - 50px);\n  position: relative;\n  overflow: hidden;\n  overflow-y: auto;\n}\n\n.main-card-item ion-card-content ::-webkit-scrollbar {\n  display: none;\n}\n\n.main-card-total {\n  background-color: #fff;\n  height: 20%;\n}\n\n.cancelOrder_btn {\n  background-color: #E4322E;\n  color: #fff;\n  font-size: 20px;\n  height: 40px;\n  width: 90%;\n  border-radius: 8px;\n  display: block;\n  margin: auto;\n  border: 1px solid #fff;\n  margin-right: 12px;\n  margin-left: 6px;\n  margin-top: 3px;\n  font-family: open sans;\n}\n\n.download_btn {\n  background-color: #E4322E;\n  color: #fff;\n  font-size: 20px;\n  height: 40px;\n  width: 90%;\n  border-radius: 8px;\n  display: block;\n  margin: auto;\n  border: 1px solid #fff;\n  margin-right: 12px;\n  margin-left: 12px;\n  margin-top: 3px;\n  font-family: open sans;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9zdW1tYXJ5L3N1bW1hcnkucGFnZS5zY3NzIiwic3JjL2FwcC9zdW1tYXJ5L3N1bW1hcnkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtBQ0NKOztBRENBO0VBQ0ksY0FBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7QUNFSjs7QURBQTtFQUdJLHNCQUFBO0FDQ0o7O0FEQ0E7RUFDSSxzQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUVBLFdBQUE7RUFDQSxlQUFBO0FDQ0o7O0FERUE7RUFDSSxzQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtBQ0NKOztBRENBO0VBQ0ksc0JBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBRUEsV0FBQTtBQ0NKOztBREVBO0VBQ0ksc0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFFQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7QUNBSjs7QURFQTtFQUNJLHNCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUNDSjs7QURFQTtFQUNJLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDRCxlQUFBO0VBQ0MsZ0JBQUE7QUNDSjs7QURDQTtFQUNJLHNCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBRUEsV0FBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0FDQ0o7O0FEQ0E7RUFDSSxzQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0FDRUo7O0FEQUE7RUFDSSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQ0dKOztBRERBO0VBQ0ksc0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFFQSxXQUFBO0FDR0o7O0FEQUE7RUFFSSxzQkFBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtBQ0VKOztBRERJO0VBQ0ksVUFBQTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0FDR1I7O0FERlE7RUFDRSxhQUFBO0FDSVY7O0FEQ0E7RUFFSSxzQkFBQTtFQUNBLFdBQUE7QUNDSjs7QURFQTtFQUNJLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0Esc0JBQUE7QUNDSjs7QURDQTtFQUNJLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0Esc0JBQUE7QUNFSiIsImZpbGUiOiJzcmMvYXBwL3N1bW1hcnkvc3VtbWFyeS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWVudV9idG57XG4gICAgY29sb3I6ICNFNDMyMkU7XG59XG4ubWFpbi10aXRsZXtcbiAgICBjb2xvcjogI0U0MzIyRTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cbi5tYWluLWNhcmR7XG4gICAgLy8gYm94LXNoYWRvdzogNXB4IDdweCAxMHB4IDVweCAjZThlOGU4O1xuICAgIC8vIG1hcmdpbi10b3A6IDIwcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbn1cbi5wLWxhYmVsMntcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gICAgLy8gbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgIGNvbG9yOiAjMDAwO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAvL2Zsb2F0OiByaWdodDtcbn1cbi5wLWxhYmVse1xuICAgIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG4gICAgbWFyZ2luLXRvcDogMHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDBweDtcbiAgICBjb2xvcjogIzAwMDtcbiAgICBmbG9hdDogcmlnaHQ7XG4gICAgZm9udC1zaXplOiAxNnB4O1xufVxuLnAtcHJpY2V7XG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgbWFyZ2luLXRvcDogMHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDBweDtcbiAgICAvL21hcmdpbi1yaWdodDogMTBweDtcbiAgICBjb2xvcjogIzAwMDtcbiAgICBcbn1cbi5wLWRhdGV7XG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgICBtYXJnaW4tdG9wOiAwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICAgIC8vIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICBjb2xvcjogIzAwMDtcbiAgICBmbG9hdDogcmlnaHQ7XG4gICAgZm9udC1zaXplOiAyMHB4O1xufVxuLnAtcXR5e1xuICAgIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG4gICAgY29sb3I6ICMwMDA7XG4gICAgbWFyZ2luOiAwO1xuICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbn1cblxuLnAtbGFiZWwze1xuICAgIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICBjb2xvcjogIzAxMDk0NDtcbiAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xufVxuLnAtbGFiZWw0e1xuICAgIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG4gICAgbWFyZ2luLXRvcDogMHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDBweDtcbiAgICAvLyBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgY29sb3I6ICMwMDA7XG4gICAgZmxvYXQ6IHJpZ2h0O1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbn1cbi5wLWxhYmVsNXtcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gICAgbWFyZ2luLXJpZ2h0OiA3cHg7XG4gICAgY29sb3I6ICMwMDA7XG4gICAgZmxvYXQ6IHJpZ2h0O1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbn1cbi5wLXF0eTF7XG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgICBjb2xvcjogIzAwMDtcbiAgICBtYXJnaW46IDA7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgbWFyZ2luLXRvcDogMTRweDtcbn1cbi5TdWJ0b3RhbHtcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gICAgLy8gbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgIGNvbG9yOiAjMDAwO1xuICAgIC8vZmxvYXQ6IHJpZ2h0O1xufVxuLm1haW4tY2FyZC1pdGVte1xuICAgIC8vIGJveC1zaGFkb3c6IDVweCA3cHggMTBweCA1cHggI2U4ZThlODtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAgIGhlaWdodDogYXV0bztcbiAgICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbiAgICBpb24tY2FyZC1jb250ZW50IHtcbiAgICAgICAgcGFkZGluZzogMDtcbiAgICAgICAgbWF4LWhlaWdodDogY2FsYygxMjUlIC0gI3s1MHB4fSk7XG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAgICAgb3ZlcmZsb3cteTogYXV0bztcbiAgICAgICAgOjotd2Via2l0LXNjcm9sbGJhciB7XG4gICAgICAgICAgZGlzcGxheTogbm9uZTtcbiAgICAgICAgfVxuICAgICAgfVxufVxuXG4ubWFpbi1jYXJkLXRvdGFse1xuICAgIC8vIGJveC1zaGFkb3c6IDVweCA3cHggMTBweCA1cHggI2U4ZThlODtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAgIGhlaWdodDogMjAlO1xuXG59XG4uY2FuY2VsT3JkZXJfYnRue1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNFNDMyMkU7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGhlaWdodDogNDBweDtcbiAgICB3aWR0aDogOTAlO1xuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBtYXJnaW46IGF1dG87XG4gICAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbiAgICBtYXJnaW4tcmlnaHQ6IDEycHg7XG4gICAgbWFyZ2luLWxlZnQ6IDZweDtcbiAgICBtYXJnaW4tdG9wOiAzcHg7XG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cbi5kb3dubG9hZF9idG57XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0U0MzIyRTtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgaGVpZ2h0OiA0MHB4O1xuICAgIHdpZHRoOiA5MCU7XG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIG1hcmdpbjogYXV0bztcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZmZmO1xuICAgIG1hcmdpbi1yaWdodDogMTJweDtcbiAgICBtYXJnaW4tbGVmdDogMTJweDtcbiAgICBtYXJnaW4tdG9wOiAzcHg7ICBcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuIiwiLm1lbnVfYnRuIHtcbiAgY29sb3I6ICNFNDMyMkU7XG59XG5cbi5tYWluLXRpdGxlIHtcbiAgY29sb3I6ICNFNDMyMkU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cblxuLm1haW4tY2FyZCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG59XG5cbi5wLWxhYmVsMiB7XG4gIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG4gIG1hcmdpbi10b3A6IDBweDtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICBjb2xvcjogIzAwMDtcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG4ucC1sYWJlbCB7XG4gIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG4gIG1hcmdpbi10b3A6IDBweDtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICBjb2xvcjogIzAwMDtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBmb250LXNpemU6IDE2cHg7XG59XG5cbi5wLXByaWNlIHtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgZm9udC1zaXplOiAyMHB4O1xuICBtYXJnaW4tdG9wOiAwcHg7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgY29sb3I6ICMwMDA7XG59XG5cbi5wLWRhdGUge1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICBtYXJnaW4tdG9wOiAwcHg7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgY29sb3I6ICMwMDA7XG4gIGZsb2F0OiByaWdodDtcbiAgZm9udC1zaXplOiAyMHB4O1xufVxuXG4ucC1xdHkge1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICBjb2xvcjogIzAwMDtcbiAgbWFyZ2luOiAwO1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG4ucC1sYWJlbDMge1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgY29sb3I6ICMwMTA5NDQ7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuLnAtbGFiZWw0IHtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgbWFyZ2luLXRvcDogMHB4O1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gIGNvbG9yOiAjMDAwO1xuICBmbG9hdDogcmlnaHQ7XG4gIGZvbnQtc2l6ZTogMTZweDtcbn1cblxuLnAtbGFiZWw1IHtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgbWFyZ2luLXRvcDogMHB4O1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gIG1hcmdpbi1yaWdodDogN3B4O1xuICBjb2xvcjogIzAwMDtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBmb250LXNpemU6IDE2cHg7XG59XG5cbi5wLXF0eTEge1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICBjb2xvcjogIzAwMDtcbiAgbWFyZ2luOiAwO1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgbWFyZ2luLXRvcDogMTRweDtcbn1cblxuLlN1YnRvdGFsIHtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgbWFyZ2luLXRvcDogMHB4O1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gIGNvbG9yOiAjMDAwO1xufVxuXG4ubWFpbi1jYXJkLWl0ZW0ge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICBoZWlnaHQ6IGF1dG87XG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xufVxuLm1haW4tY2FyZC1pdGVtIGlvbi1jYXJkLWNvbnRlbnQge1xuICBwYWRkaW5nOiAwO1xuICBtYXgtaGVpZ2h0OiBjYWxjKDEyNSUgLSA1MHB4KTtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBvdmVyZmxvdy15OiBhdXRvO1xufVxuLm1haW4tY2FyZC1pdGVtIGlvbi1jYXJkLWNvbnRlbnQgOjotd2Via2l0LXNjcm9sbGJhciB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5cbi5tYWluLWNhcmQtdG90YWwge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICBoZWlnaHQ6IDIwJTtcbn1cblxuLmNhbmNlbE9yZGVyX2J0biB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNFNDMyMkU7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LXNpemU6IDIwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgd2lkdGg6IDkwJTtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBkaXNwbGF5OiBibG9jaztcbiAgbWFyZ2luOiBhdXRvO1xuICBib3JkZXI6IDFweCBzb2xpZCAjZmZmO1xuICBtYXJnaW4tcmlnaHQ6IDEycHg7XG4gIG1hcmdpbi1sZWZ0OiA2cHg7XG4gIG1hcmdpbi10b3A6IDNweDtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cblxuLmRvd25sb2FkX2J0biB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNFNDMyMkU7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LXNpemU6IDIwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgd2lkdGg6IDkwJTtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBkaXNwbGF5OiBibG9jaztcbiAgbWFyZ2luOiBhdXRvO1xuICBib3JkZXI6IDFweCBzb2xpZCAjZmZmO1xuICBtYXJnaW4tcmlnaHQ6IDEycHg7XG4gIG1hcmdpbi1sZWZ0OiAxMnB4O1xuICBtYXJnaW4tdG9wOiAzcHg7XG4gIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG59Il19 */");

/***/ }),

/***/ "./src/app/summary/summary.page.ts":
/*!*****************************************!*\
  !*** ./src/app/summary/summary.page.ts ***!
  \*****************************************/
/*! exports provided: SummaryPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SummaryPage", function() { return SummaryPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _common_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../common.service */ "./src/app/common.service.ts");










let SummaryPage = class SummaryPage {
    constructor(commonService, fileOpener, transfer, file, navCtrl, location, datePipe, auth, router) {
        this.commonService = commonService;
        this.fileOpener = fileOpener;
        this.transfer = transfer;
        this.file = file;
        this.navCtrl = navCtrl;
        this.location = location;
        this.datePipe = datePipe;
        this.auth = auth;
        this.router = router;
        this.ordersDetails = [];
        this.orderItem = [];
        const state = this.router.getCurrentNavigation().extras.state;
        if (state) {
            this.id = state.id;
            this.orderNum = state.order_number;
            console.log("order id-->", this.id);
        }
    }
    ngOnInit() {
        this.getOrderDetails();
        this.url = this.commonService.url();
    }
    goBack() {
        this.location.back();
    }
    getOrderDetails() {
        this.requestObject = {
            "order_id": this.id
        };
        console.log(this.requestObject);
        this.auth.showLoader();
        this.auth.getOrderDetails(this.requestObject).subscribe((data) => {
            console.log(data);
            this.auth.hideLoader();
            this.dataResponse = data.data;
            this.ordersDetails = this.dataResponse;
            this.date = this.dataResponse.create_at;
            this.orderDate = this.datePipe.transform(new Date(this.date), "dd/MM/yyyy");
            console.log("order data-->", this.ordersDetails);
            this.orderItem = this.dataResponse.order_item;
            console.log("order list data-->", this.orderDate);
        }, (err) => {
            this.auth.hideLoader();
            console.log("Error=>", err);
        });
    }
    fnCancelOrder(id, orderNo) {
        this.navCtrl.navigateForward('cancel-order', { state: { id: this.id, order_number: this.orderNum, cancel_by: 'CC' } });
    }
    fnDownload(url, fileName) {
        this.auth.showLoader();
        this.fileTransfer = this.transfer.create();
        this.fileTransfer
            .download(url, this.file.dataDirectory + fileName + ".pdf")
            .then(entry => {
            this.auth.hideLoader();
            console.log("download complete: " + entry.toURL());
            this.fileOpener
                .open(entry.toURL(), "application/pdf")
                .then(() => console.log("File is opened"))
                .catch(e => console.log("Error opening file", e));
        });
    }
    fnGetPdfUrl(id, orderNo) {
        console.log(id);
        this.auth.showLoader();
        this.auth.openPdf(id).subscribe((data) => {
            console.log(data);
            this.auth.hideLoader();
            if (data.status === true) {
                this.dataResponse = data.data[0];
                this.fnDownload(this.dataResponse, orderNo);
            }
            else {
                this.auth.showToast("Error while Openinf file!");
            }
        }, (err) => {
            this.auth.hideLoader();
            console.log("Error=>", err);
        });
    }
};
SummaryPage.ctorParameters = () => [
    { type: _common_service__WEBPACK_IMPORTED_MODULE_9__["CommonService"] },
    { type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_8__["FileOpener"] },
    { type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_7__["FileTransfer"] },
    { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_6__["File"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_5__["Location"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_5__["DatePipe"] },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }
];
SummaryPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-summary',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./summary.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/summary/summary.page.html")).default,
        providers: [_angular_common__WEBPACK_IMPORTED_MODULE_5__["DatePipe"]],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./summary.page.scss */ "./src/app/summary/summary.page.scss")).default]
    })
], SummaryPage);



/***/ })

}]);
//# sourceMappingURL=summary-summary-module-es2015.js.map