(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["edit-address-edit-address-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/edit-address/edit-address.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/edit-address/edit-address.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title class=\"main-title\" color=\"primary\">Edit Address</ion-title>\n    <ion-buttons slot=\"start\">\n      <!-- <ion-back-button (click)=\"goBack()\" color=\"danger\"></ion-back-button>  -->\n      <ion-icon name=\"arrow-back-outline\" class=\"backarrow1\" (click)=\"goBack()\"></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header> \n\n<ion-content>\n  <div *ngIf=\"AllAddressArray\">\n  <div class=\"order-no-bg\" style=\"margin-top: 20%;\">\n    <ion-input placeholder=\"House No\" type=\"text\" name=\"house_no\" [(ngModel)]=\"AllAddressArray.address_house_no\" class=\"order_no_txt\">\n    </ion-input>\n  </div>\n\n  <div class=\"order-no-bg\">\n    <ion-input placeholder=\"Road Name, Area, Colony\" type=\"text\" name=\"area\" [(ngModel)]=\"AllAddressArray.address_area\" class=\"order_no_txt\">\n    </ion-input>\n  </div>\n\n  <ion-row>\n    <ion-col>\n      <div class=\"order-no-bgt\">\n        <ion-input placeholder=\"City\"  type=\"text\" name=\"city\" [(ngModel)]=\"AllAddressArray.address_city\" class=\"order_no_txt\"></ion-input>\n      </div>\n    </ion-col>\n    <ion-col>\n      <div  class=\"order-no-bgs\">\n        <ion-input placeholder=\"State\" type=\"text\" name=\"state\" [(ngModel)]=\"AllAddressArray.address_state\" class=\"order_no_txt\"></ion-input>\n      </div>\n    </ion-col>\n  </ion-row>\n\n\n  <div class=\"order-no-bg\">\n    <ion-input placeholder=\"Landmark (Optional)\" type=\"text\" name=\"landmark\" [(ngModel)]=\"AllAddressArray.address_landmark\"\n      class=\"order_no_txt\"></ion-input>\n  </div>\n\n  <div class=\"order-no-bg\">\n    <ion-input placeholder=\"10-digit Mobile Number\" type=\"text\" name=\"mobile_no\" [(ngModel)]=AllAddressArray.address_mobile_no\n      class=\"order_no_txt\"></ion-input>\n  </div>\n</div>\n  <button ion-button class=\"SaveAddress_btn\" (click)=\"fnSaveAddress()\"><b>Save Address</b></button>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/edit-address/edit-address-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/edit-address/edit-address-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: EditAddressPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditAddressPageRoutingModule", function() { return EditAddressPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _edit_address_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./edit-address.page */ "./src/app/edit-address/edit-address.page.ts");




const routes = [
    {
        path: '',
        component: _edit_address_page__WEBPACK_IMPORTED_MODULE_3__["EditAddressPage"]
    }
];
let EditAddressPageRoutingModule = class EditAddressPageRoutingModule {
};
EditAddressPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], EditAddressPageRoutingModule);



/***/ }),

/***/ "./src/app/edit-address/edit-address.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/edit-address/edit-address.module.ts ***!
  \*****************************************************/
/*! exports provided: EditAddressPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditAddressPageModule", function() { return EditAddressPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _edit_address_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./edit-address-routing.module */ "./src/app/edit-address/edit-address-routing.module.ts");
/* harmony import */ var _edit_address_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./edit-address.page */ "./src/app/edit-address/edit-address.page.ts");







let EditAddressPageModule = class EditAddressPageModule {
};
EditAddressPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _edit_address_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditAddressPageRoutingModule"]
        ],
        declarations: [_edit_address_page__WEBPACK_IMPORTED_MODULE_6__["EditAddressPage"]]
    })
], EditAddressPageModule);



/***/ }),

/***/ "./src/app/edit-address/edit-address.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/edit-address/edit-address.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".order-no-bg {\n  background-color: #f5f0f0;\n  width: 90%;\n  height: 45px;\n  margin-left: 20px;\n  border-radius: 7px;\n  margin-top: 15px;\n}\n\n.order_no_txt {\n  color: #010944;\n}\n\n.order-no-bgs {\n  background-color: #f5f0f0;\n  width: 90%;\n  height: 45px;\n  margin-left: 6px;\n  border-radius: 7px;\n  margin-top: 15px;\n}\n\n.order-no-bgt {\n  background-color: #f5f0f0;\n  width: 90%;\n  height: 45px;\n  margin-left: 15px;\n  border-radius: 7px;\n  margin-top: 15px;\n}\n\n.SaveAddress_btn {\n  background-color: #E4322E;\n  color: #fff;\n  font-size: 20px;\n  height: 40px;\n  width: 90%;\n  border-radius: 8px;\n  display: block;\n  margin: auto;\n  margin-top: 25px;\n}\n\n.main-title {\n  text-align: center;\n  color: #E4322E;\n  margin-right: 43px;\n}\n\n.error-wrap {\n  color: red;\n  font-size: 15px;\n}\n\n.input-wrap {\n  position: relative;\n}\n\n.input-wrap .login_text {\n  margin-bottom: 15px;\n}\n\n.input-wrap .error-wrap {\n  position: absolute;\n  bottom: -15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9lZGl0LWFkZHJlc3MvZWRpdC1hZGRyZXNzLnBhZ2Uuc2NzcyIsInNyYy9hcHAvZWRpdC1hZGRyZXNzL2VkaXQtYWRkcmVzcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSx5QkFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FDQ0o7O0FEQ0E7RUFDSSxjQUFBO0FDRUo7O0FEQ0E7RUFDSSx5QkFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FDRUo7O0FEQUE7RUFDSSx5QkFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FDR0o7O0FEREE7RUFDSSx5QkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUNJSjs7QURGQTtFQUNJLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FDS0o7O0FESEE7RUFDSSxVQUFBO0VBQ0EsZUFBQTtBQ01KOztBREpBO0VBQ0ksa0JBQUE7QUNPSjs7QUROSTtFQUNFLG1CQUFBO0FDUU47O0FETkk7RUFDRSxrQkFBQTtFQUNBLGFBQUE7QUNRTiIsImZpbGUiOiJzcmMvYXBwL2VkaXQtYWRkcmVzcy9lZGl0LWFkZHJlc3MucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm9yZGVyLW5vLWJne1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmNWYwZjA7XG4gICAgd2lkdGg6IDkwJTtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XG4gICAgYm9yZGVyLXJhZGl1czogN3B4O1xuICAgIG1hcmdpbi10b3A6IDE1cHg7XG59XG4ub3JkZXJfbm9fdHh0e1xuICAgIGNvbG9yOiAjMDEwOTQ0O1xufVxuXG4ub3JkZXItbm8tYmdze1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmNWYwZjA7XG4gICAgd2lkdGg6IDkwJTtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgbWFyZ2luLWxlZnQ6IDZweDtcbiAgICBib3JkZXItcmFkaXVzOiA3cHg7XG4gICAgbWFyZ2luLXRvcDogMTVweDtcbn1cbi5vcmRlci1uby1iZ3R7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjBmMDtcbiAgICB3aWR0aDogOTAlO1xuICAgIGhlaWdodDogNDVweDtcbiAgICBtYXJnaW4tbGVmdDogMTVweDtcbiAgICBib3JkZXItcmFkaXVzOiA3cHg7XG4gICAgbWFyZ2luLXRvcDogMTVweDtcbn1cbi5TYXZlQWRkcmVzc19idG57XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0U0MzIyRTtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgaGVpZ2h0OiA0MHB4O1xuICAgIHdpZHRoOiA5MCU7XG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIG1hcmdpbjogYXV0bztcbiAgICBtYXJnaW4tdG9wOiAyNXB4O1xufVxuLm1haW4tdGl0bGV7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjRTQzMjJFO1xuICAgIG1hcmdpbi1yaWdodDogNDNweDtcbn1cbi5lcnJvci13cmFwe1xuICAgIGNvbG9yOiByZWQ7IFxuICAgIGZvbnQtc2l6ZTogMTVweDsgICBcbn1cbi5pbnB1dC13cmFwe1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAubG9naW5fdGV4dHtcbiAgICAgIG1hcmdpbi1ib3R0b206IDE1cHg7XG4gICAgfVxuICAgIC5lcnJvci13cmFwe1xuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgYm90dG9tOiAtMTVweDtcbiAgICB9XG4gIH0iLCIub3JkZXItbm8tYmcge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmMGYwO1xuICB3aWR0aDogOTAlO1xuICBoZWlnaHQ6IDQ1cHg7XG4gIG1hcmdpbi1sZWZ0OiAyMHB4O1xuICBib3JkZXItcmFkaXVzOiA3cHg7XG4gIG1hcmdpbi10b3A6IDE1cHg7XG59XG5cbi5vcmRlcl9ub190eHQge1xuICBjb2xvcjogIzAxMDk0NDtcbn1cblxuLm9yZGVyLW5vLWJncyB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmNWYwZjA7XG4gIHdpZHRoOiA5MCU7XG4gIGhlaWdodDogNDVweDtcbiAgbWFyZ2luLWxlZnQ6IDZweDtcbiAgYm9yZGVyLXJhZGl1czogN3B4O1xuICBtYXJnaW4tdG9wOiAxNXB4O1xufVxuXG4ub3JkZXItbm8tYmd0IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjBmMDtcbiAgd2lkdGg6IDkwJTtcbiAgaGVpZ2h0OiA0NXB4O1xuICBtYXJnaW4tbGVmdDogMTVweDtcbiAgYm9yZGVyLXJhZGl1czogN3B4O1xuICBtYXJnaW4tdG9wOiAxNXB4O1xufVxuXG4uU2F2ZUFkZHJlc3NfYnRuIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0U0MzIyRTtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgaGVpZ2h0OiA0MHB4O1xuICB3aWR0aDogOTAlO1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW46IGF1dG87XG4gIG1hcmdpbi10b3A6IDI1cHg7XG59XG5cbi5tYWluLXRpdGxlIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI0U0MzIyRTtcbiAgbWFyZ2luLXJpZ2h0OiA0M3B4O1xufVxuXG4uZXJyb3Itd3JhcCB7XG4gIGNvbG9yOiByZWQ7XG4gIGZvbnQtc2l6ZTogMTVweDtcbn1cblxuLmlucHV0LXdyYXAge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4uaW5wdXQtd3JhcCAubG9naW5fdGV4dCB7XG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XG59XG4uaW5wdXQtd3JhcCAuZXJyb3Itd3JhcCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm90dG9tOiAtMTVweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/edit-address/edit-address.page.ts":
/*!***************************************************!*\
  !*** ./src/app/edit-address/edit-address.page.ts ***!
  \***************************************************/
/*! exports provided: EditAddressPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditAddressPage", function() { return EditAddressPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");






let EditAddressPage = class EditAddressPage {
    constructor(location, navCtrl, route, auth, router) {
        this.location = location;
        this.navCtrl = navCtrl;
        this.route = route;
        this.auth = auth;
        this.router = router;
        this.regex = /^[A-z]+$/;
        const state = this.router.getCurrentNavigation().extras.state;
        if (state) {
            this.AllAddressArray = state.data;
            this.navigateFrom = state.from;
            console.log("Address data-->", this.AllAddressArray);
            console.log("navigateFrom data-->", this.navigateFrom);
        }
    }
    ngOnInit() {
    }
    goBack() {
        this.location.back();
    }
    fnSaveAddress() {
        if (this.AllAddressArray.address_house_no != '' && this.AllAddressArray.area != ''
            && this.AllAddressArray.address_city != ''
            && this.AllAddressArray.address_state != ''
            && this.AllAddressArray.address_zipcode != '' && this.AllAddressArray.address_type != '') {
            if (!this.regex.test(this.AllAddressArray.address_city) && !this.regex.test(this.AllAddressArray.address_state)) {
                console.log("Entered char is not alphabet");
                this.auth.showToast('Entered City or State is not alphabet');
            }
            else {
                console.log("OK");
                this.requestObject = {
                    "address_user_id": this.AllAddressArray.address_user_id,
                    "house_no": this.AllAddressArray.address_house_no,
                    "area": this.AllAddressArray.address_area,
                    "city": this.AllAddressArray.address_city,
                    "state": this.AllAddressArray.address_state,
                    "landmark": this.AllAddressArray.address_landmark,
                    "zipcode": this.AllAddressArray.address_zipcode,
                    "mobile_no": this.AllAddressArray.address_mobile_no,
                    "address_type": this.AllAddressArray.address_type,
                    "address_id": this.AllAddressArray.id
                };
                this.auth.showLoader();
                this.auth.editAddress(this.requestObject).subscribe((data) => {
                    this.auth.hideLoader();
                    this.auth.showToast('Address Sucessfully Updated');
                    if (this.navigateFrom === '1') {
                        this.navCtrl.navigateForward('/select-address');
                    }
                    else {
                        this.navCtrl.navigateForward('/my-address');
                    }
                }, (err) => {
                    console.log("Error=>", err);
                    this.auth.hideLoader();
                });
            }
        }
        else {
            this.auth.showToast('Please fillup all fields');
        }
    }
};
EditAddressPage.ctorParameters = () => [
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_5__["Location"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }
];
EditAddressPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-edit-address',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./edit-address.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/edit-address/edit-address.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./edit-address.page.scss */ "./src/app/edit-address/edit-address.page.scss")).default]
    })
], EditAddressPage);



/***/ })

}]);
//# sourceMappingURL=edit-address-edit-address-module-es2015.js.map