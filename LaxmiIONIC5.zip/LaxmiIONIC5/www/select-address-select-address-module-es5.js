function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["select-address-select-address-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/select-address/select-address.page.html":
  /*!***********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/select-address/select-address.page.html ***!
    \***********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSelectAddressSelectAddressPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\" >\n      <ion-icon name=\"arrow-back-outline\" class=\"backarrow1\" (click)=\" goBack()\"></ion-icon>\n    </ion-buttons>\n\n    <ion-buttons slot=\"end\">\n      <ion-button>\n\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"main-title\">Select Address</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-card class=\"add_card_shadow\">\n\n    <ion-row style=\"margin-top: 5px;\" *ngFor=\"let item of allUpdatedAddress;let i = index\">\n      <ion-col size=\"3\">\n        <ion-checkbox color=\"danger\" class=\"p-check-icon\" [disabled]=\"item.value\" (click)=\"selection(item.id,i);\">\n        </ion-checkbox>\n        <ion-icon *ngIf=\"item.address_type == 'Home' || item.address_type == null\" name=\"home-outline\" class=\"icon-address\"></ion-icon>\n        <ion-icon *ngIf=\"item.address_type == 'Office'\" name=\"business-outline\" class=\"icon-address\"></ion-icon>\n        <ion-icon *ngIf=\"item.address_type == 'Other'\" name=\"location-outline\" class=\"icon-address\"></ion-icon>\n      </ion-col>\n\n      <ion-col size=\"7.5\">\n\n        <p class=\"p-name\">{{item.name}}</p>\n        <p class=\"p-address\">{{item.address_house_no}},{{item.address_area}},{{item.address_landmark}},</p>\n        <p class=\"p-address\">{{item.address_city}},{{item.address_state}},{{item.address_zipcode}}</p>\n        <p class=\"p-address\">{{item.address_mobile_no}}</p>\n      </ion-col>\n      <ion-col size=\"1.5\" style=\"text-align: end !important;\">\n        <ion-icon name=\"create-outline\" color=\"danger\" class=\"p-check-icons float-r\" (click)=\"updateAddress(item)\">\n        </ion-icon>\n      </ion-col>\n\n    </ion-row>\n\n  </ion-card>\n  <ion-card class=\"add_card_shadow\" (click)=\"fnAddNewAddress()\">\n    <ion-row>\n      <ion-col size=\"4\">\n        <ion-icon name=\"add-circle\" class=\"p-icon\"></ion-icon>\n      </ion-col>\n      <ion-col size=\"6\" class=\"p-add\">\n        Add New Address\n      </ion-col>\n    </ion-row>\n  </ion-card>\n\n  <ion-card class=\"payable_amt\">\n    <ion-row class=\"center1\">\n      <ion-col size=\"8\" class=\"p-total\">\n        Payable Amount\n      </ion-col> \n      <ion-col size=\"4\" class=\"p-price\">\n        ₹{{mainSubTotal | number:'1.2-2'}}\n      </ion-col>\n    </ion-row>\n  </ion-card>\n\n  <ion-row class=\"center1\">\n    <ion-card class=\"place_order center\" (click)=\"fnBackToYourCart()\">\n      <ion-icon name=\"chevron-back-outline\" class=\"backarrow\"></ion-icon>\n      <p style=\"color: black;font-size: 1rem;\">Add Item</p>\n    </ion-card>\n    <ion-col>\n      <button float-right ion-button class=\"ProceedToCheckout_btn\" (click)=\"fnProceedToCheckout()\">Place Order</button>\n    </ion-col>\n  </ion-row>\n\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/select-address/select-address-routing.module.ts":
  /*!*****************************************************************!*\
    !*** ./src/app/select-address/select-address-routing.module.ts ***!
    \*****************************************************************/

  /*! exports provided: SelectAddressPageRoutingModule */

  /***/
  function srcAppSelectAddressSelectAddressRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SelectAddressPageRoutingModule", function () {
      return SelectAddressPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _select_address_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./select-address.page */
    "./src/app/select-address/select-address.page.ts");

    var routes = [{
      path: '',
      component: _select_address_page__WEBPACK_IMPORTED_MODULE_3__["SelectAddressPage"]
    }];

    var SelectAddressPageRoutingModule = function SelectAddressPageRoutingModule() {
      _classCallCheck(this, SelectAddressPageRoutingModule);
    };

    SelectAddressPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], SelectAddressPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/select-address/select-address.module.ts":
  /*!*********************************************************!*\
    !*** ./src/app/select-address/select-address.module.ts ***!
    \*********************************************************/

  /*! exports provided: SelectAddressPageModule */

  /***/
  function srcAppSelectAddressSelectAddressModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SelectAddressPageModule", function () {
      return SelectAddressPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _select_address_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./select-address-routing.module */
    "./src/app/select-address/select-address-routing.module.ts");
    /* harmony import */


    var _select_address_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./select-address.page */
    "./src/app/select-address/select-address.page.ts");

    var SelectAddressPageModule = function SelectAddressPageModule() {
      _classCallCheck(this, SelectAddressPageModule);
    };

    SelectAddressPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _select_address_routing_module__WEBPACK_IMPORTED_MODULE_5__["SelectAddressPageRoutingModule"]],
      declarations: [_select_address_page__WEBPACK_IMPORTED_MODULE_6__["SelectAddressPage"]]
    })], SelectAddressPageModule);
    /***/
  },

  /***/
  "./src/app/select-address/select-address.page.scss":
  /*!*********************************************************!*\
    !*** ./src/app/select-address/select-address.page.scss ***!
    \*********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSelectAddressSelectAddressPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".menu_btn {\n  color: #E4322E;\n}\n\n.main-title {\n  text-align: center;\n  color: #E4322E;\n}\n\n.p-name {\n  color: #E4322E;\n  margin: 0;\n  margin-left: 10px;\n  font-size: 18px;\n  margin-bottom: 5px;\n  font-family: open sans;\n}\n\n.p-address {\n  color: #010944;\n  margin: 0;\n  margin-left: 2px;\n  font-size: 1rem;\n  margin-top: 6px;\n  font-family: open sans;\n}\n\n.p-icon {\n  font-size: 1.2rem;\n  color: #E4322E;\n  float: right;\n}\n\n.p-icon-text {\n  font-size: 18px;\n  color: #E4322E;\n  float: left;\n}\n\n.p-add {\n  color: #E4322E;\n  font-size: 18px;\n  font-family: open sans;\n  display: flex;\n  align-items: center;\n}\n\n.p-add-name {\n  font-size: 1.2rem;\n  color: #E4322E;\n  margin: 0;\n  margin-left: 4%;\n  margin-bottom: 5px;\n  margin-top: 11px;\n}\n\n.p-check-icon {\n  font-size: 1.2rem;\n  color: #E4322E;\n  margin-top: 0.1rem;\n  margin-left: 0.5rem;\n}\n\n.p-check-icons {\n  font-size: 1.2rem;\n  margin-right: 0.4rem;\n}\n\n.ProceedToCheckout_btn {\n  background-color: #E4322E;\n  color: #fff;\n  font-size: 18px;\n  height: 40px;\n  width: 90%;\n  border-radius: 8px;\n  display: block;\n  margin: auto;\n  border: 1px solid #fff;\n}\n\n.backarrow {\n  color: #E4322E;\n  font-size: 1.8rem;\n  width: 35%;\n}\n\n.p-total {\n  color: #E4322E;\n  font-size: 1.2rem;\n  padding: 10px !important;\n}\n\n.p-price {\n  color: #E4322E;\n  font-size: 1.2rem;\n  padding: 10px !important;\n  text-align: end;\n}\n\n.p-check-icon-d {\n  font-size: 1.2rem;\n  color: #E4322E;\n  margin: 0;\n  margin-left: 9%;\n  margin-bottom: 5px;\n  margin-top: 11px;\n}\n\n.add_card_shadow {\n  background-color: #fff;\n}\n\n.payable_amt {\n  background-color: #fff;\n  margin-top: 30%;\n}\n\n.place_order {\n  height: 38px;\n  width: 34%;\n  background-color: #fff;\n}\n\n.backarrow1 {\n  margin-left: 10px;\n  color: #E4322E;\n  font-size: 26px;\n}\n\n.center1 {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.icon-address {\n  font-size: 1.2rem;\n  color: red;\n  margin-top: 0.1rem;\n  margin-left: 0.5rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9zZWxlY3QtYWRkcmVzcy9zZWxlY3QtYWRkcmVzcy5wYWdlLnNjc3MiLCJzcmMvYXBwL3NlbGVjdC1hZGRyZXNzL3NlbGVjdC1hZGRyZXNzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGNBQUE7QUNDSjs7QURDQTtFQUNJLGtCQUFBO0VBQ0EsY0FBQTtBQ0VKOztBREFBO0VBQ0ksY0FBQTtFQUNBLFNBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0FDR0o7O0FEREE7RUFDSSxjQUFBO0VBQ0EsU0FBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7RUFDQSxzQkFBQTtBQ0lKOztBREZBO0VBQ0ksaUJBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtBQ0tKOztBREhBO0VBQ0ksZUFBQTtFQUNBLGNBQUE7RUFDQSxXQUFBO0FDTUo7O0FESkE7RUFDSSxjQUFBO0VBQ0EsZUFBQTtFQUNBLHNCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FDT0o7O0FETEE7RUFDSSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxTQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUNRSjs7QUROQTtFQUNJLGlCQUFBO0VBQ0EsY0FBQTtFQUdBLGtCQUFBO0VBQ0EsbUJBQUE7QUNPSjs7QURMQTtFQUNJLGlCQUFBO0VBQ0Esb0JBQUE7QUNRSjs7QUROQTtFQUNJLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtBQ1NKOztBRFBBO0VBRUksY0FBQTtFQUNBLGlCQUFBO0VBQ0EsVUFBQTtBQ1NKOztBRE5BO0VBQ0ksY0FBQTtFQUNBLGlCQUFBO0VBQ0Esd0JBQUE7QUNTSjs7QURQQTtFQUNJLGNBQUE7RUFDQSxpQkFBQTtFQUNBLHdCQUFBO0VBQ0EsZUFBQTtBQ1VKOztBRFJBO0VBQ0ksaUJBQUE7RUFDQSxjQUFBO0VBQ0EsU0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FDV0o7O0FEVEE7RUFDSSxzQkFBQTtBQ1lKOztBRFJBO0VBQ0ksc0JBQUE7RUFDQyxlQUFBO0FDV0w7O0FEUkE7RUFDSSxZQUFBO0VBQ0EsVUFBQTtFQUNBLHNCQUFBO0FDV0o7O0FEUEE7RUFDSSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0FDVUo7O0FEUkE7RUFDSSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQ1dKOztBRFRFO0VBQ0UsaUJBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQ1lKIiwiZmlsZSI6InNyYy9hcHAvc2VsZWN0LWFkZHJlc3Mvc2VsZWN0LWFkZHJlc3MucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1lbnVfYnRue1xuICAgIGNvbG9yOiAjRTQzMjJFO1xufVxuLm1haW4tdGl0bGV7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjRTQzMjJFO1xufVxuLnAtbmFtZXtcbiAgICBjb2xvcjogI0U0MzIyRTtcbiAgICBtYXJnaW46IDA7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDVweDtcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuLnAtYWRkcmVzc3tcbiAgICBjb2xvcjogIzAxMDk0NDtcbiAgICBtYXJnaW46IDA7XG4gICAgbWFyZ2luLWxlZnQ6IDJweDtcbiAgICBmb250LXNpemU6IDFyZW07XG4gICAgbWFyZ2luLXRvcDogNnB4O1xuICAgIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG59XG4ucC1pY29ue1xuICAgIGZvbnQtc2l6ZTogMS4ycmVtO1xuICAgIGNvbG9yOiAjRTQzMjJFO1xuICAgIGZsb2F0OiByaWdodDtcbn1cbi5wLWljb24tdGV4dHtcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgY29sb3I6ICNFNDMyMkU7XG4gICAgZmxvYXQ6IGxlZnQ7XG59XG4ucC1hZGR7XG4gICAgY29sb3I6ICNFNDMyMkU7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLnAtYWRkLW5hbWV7XG4gICAgZm9udC1zaXplOiAxLjJyZW07XG4gICAgY29sb3I6ICNFNDMyMkU7XG4gICAgbWFyZ2luOiAwO1xuICAgIG1hcmdpbi1sZWZ0OiA0JTtcbiAgICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gICAgbWFyZ2luLXRvcDogMTFweDtcbn1cbi5wLWNoZWNrLWljb257XG4gICAgZm9udC1zaXplOiAxLjJyZW07XG4gICAgY29sb3I6ICNFNDMyMkU7XG4gICAgLy9tYXJnaW4tbGVmdDogNCU7XG4gIFxuICAgIG1hcmdpbi10b3A6IDAuMXJlbTtcbiAgICBtYXJnaW4tbGVmdDogMC41cmVtO1xufVxuLnAtY2hlY2staWNvbnN7XG4gICAgZm9udC1zaXplOiAxLjJyZW07XG4gICAgbWFyZ2luLXJpZ2h0OiAwLjRyZW07XG59XG4uUHJvY2VlZFRvQ2hlY2tvdXRfYnRue1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNFNDMyMkU7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGhlaWdodDogNDBweDtcbiAgICB3aWR0aDogOTAlO1xuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBtYXJnaW46IGF1dG87XG4gICAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbn1cbi5iYWNrYXJyb3d7XG4gICAgLy8gbWFyZ2luLWxlZnQ6IDI1cHg7XG4gICAgY29sb3I6ICNFNDMyMkU7XG4gICAgZm9udC1zaXplOiAxLjhyZW07XG4gICAgd2lkdGg6IDM1JTtcbiAgICAvLyBtYXJnaW4tdG9wOiAxMnB4O1xufVxuLnAtdG90YWx7XG4gICAgY29sb3I6ICNFNDMyMkU7XG4gICAgZm9udC1zaXplOiAxLjJyZW07XG4gICAgcGFkZGluZzogMTBweCAhaW1wb3J0YW50O1xufVxuLnAtcHJpY2V7XG4gICAgY29sb3I6ICNFNDMyMkU7XG4gICAgZm9udC1zaXplOiAxLjJyZW07XG4gICAgcGFkZGluZzogMTBweCAhaW1wb3J0YW50O1xuICAgIHRleHQtYWxpZ246IGVuZDtcbn1cbi5wLWNoZWNrLWljb24tZHtcbiAgICBmb250LXNpemU6IDEuMnJlbTtcbiAgICBjb2xvcjogI0U0MzIyRTtcbiAgICBtYXJnaW46IDA7XG4gICAgbWFyZ2luLWxlZnQ6IDklOyBcbiAgICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gICAgbWFyZ2luLXRvcDogMTFweDtcbn1cbi5hZGRfY2FyZF9zaGFkb3d7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgICAvLyBtYXJnaW4tdG9wOiAyNXB4O1xuICAgIC8vIGJveC1zaGFkb3c6IDVweCA3cHggMTBweCA1cHggI2U4ZThlODtcbn1cbi5wYXlhYmxlX2FtdHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAgICBtYXJnaW4tdG9wOjMwJTtcbiAgICAvLyAgYm94LXNoYWRvdzogNXB4IDdweCAxMHB4IDVweCAjZThlOGU4O1xufVxuLnBsYWNlX29yZGVye1xuICAgIGhlaWdodDogMzhweDtcbiAgICB3aWR0aDogMzQlO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gICAgLy8gYm94LXNoYWRvdzogNXB4IDdweCAxMHB4IDVweCAjZThlOGU4O1xufVxuXG4uYmFja2Fycm93MXtcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICBjb2xvcjogI0U0MzIyRTtcbiAgICBmb250LXNpemU6IDI2cHg7XG59XG4uY2VudGVyMSB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICB9XG4gIC5pY29uLWFkZHJlc3N7XG4gICAgZm9udC1zaXplOiAxLjJyZW07XG4gICAgY29sb3I6IHJlZDtcbiAgICBtYXJnaW4tdG9wOiAwLjFyZW07XG4gICAgbWFyZ2luLWxlZnQ6IDAuNXJlbTtcbn0iLCIubWVudV9idG4ge1xuICBjb2xvcjogI0U0MzIyRTtcbn1cblxuLm1haW4tdGl0bGUge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjRTQzMjJFO1xufVxuXG4ucC1uYW1lIHtcbiAgY29sb3I6ICNFNDMyMkU7XG4gIG1hcmdpbjogMDtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuXG4ucC1hZGRyZXNzIHtcbiAgY29sb3I6ICMwMTA5NDQ7XG4gIG1hcmdpbjogMDtcbiAgbWFyZ2luLWxlZnQ6IDJweDtcbiAgZm9udC1zaXplOiAxcmVtO1xuICBtYXJnaW4tdG9wOiA2cHg7XG4gIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG59XG5cbi5wLWljb24ge1xuICBmb250LXNpemU6IDEuMnJlbTtcbiAgY29sb3I6ICNFNDMyMkU7XG4gIGZsb2F0OiByaWdodDtcbn1cblxuLnAtaWNvbi10ZXh0IHtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBjb2xvcjogI0U0MzIyRTtcbiAgZmxvYXQ6IGxlZnQ7XG59XG5cbi5wLWFkZCB7XG4gIGNvbG9yOiAjRTQzMjJFO1xuICBmb250LXNpemU6IDE4cHg7XG4gIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbi5wLWFkZC1uYW1lIHtcbiAgZm9udC1zaXplOiAxLjJyZW07XG4gIGNvbG9yOiAjRTQzMjJFO1xuICBtYXJnaW46IDA7XG4gIG1hcmdpbi1sZWZ0OiA0JTtcbiAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICBtYXJnaW4tdG9wOiAxMXB4O1xufVxuXG4ucC1jaGVjay1pY29uIHtcbiAgZm9udC1zaXplOiAxLjJyZW07XG4gIGNvbG9yOiAjRTQzMjJFO1xuICBtYXJnaW4tdG9wOiAwLjFyZW07XG4gIG1hcmdpbi1sZWZ0OiAwLjVyZW07XG59XG5cbi5wLWNoZWNrLWljb25zIHtcbiAgZm9udC1zaXplOiAxLjJyZW07XG4gIG1hcmdpbi1yaWdodDogMC40cmVtO1xufVxuXG4uUHJvY2VlZFRvQ2hlY2tvdXRfYnRuIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0U0MzIyRTtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgaGVpZ2h0OiA0MHB4O1xuICB3aWR0aDogOTAlO1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW46IGF1dG87XG4gIGJvcmRlcjogMXB4IHNvbGlkICNmZmY7XG59XG5cbi5iYWNrYXJyb3cge1xuICBjb2xvcjogI0U0MzIyRTtcbiAgZm9udC1zaXplOiAxLjhyZW07XG4gIHdpZHRoOiAzNSU7XG59XG5cbi5wLXRvdGFsIHtcbiAgY29sb3I6ICNFNDMyMkU7XG4gIGZvbnQtc2l6ZTogMS4ycmVtO1xuICBwYWRkaW5nOiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5wLXByaWNlIHtcbiAgY29sb3I6ICNFNDMyMkU7XG4gIGZvbnQtc2l6ZTogMS4ycmVtO1xuICBwYWRkaW5nOiAxMHB4ICFpbXBvcnRhbnQ7XG4gIHRleHQtYWxpZ246IGVuZDtcbn1cblxuLnAtY2hlY2staWNvbi1kIHtcbiAgZm9udC1zaXplOiAxLjJyZW07XG4gIGNvbG9yOiAjRTQzMjJFO1xuICBtYXJnaW46IDA7XG4gIG1hcmdpbi1sZWZ0OiA5JTtcbiAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICBtYXJnaW4tdG9wOiAxMXB4O1xufVxuXG4uYWRkX2NhcmRfc2hhZG93IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbn1cblxuLnBheWFibGVfYW10IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgbWFyZ2luLXRvcDogMzAlO1xufVxuXG4ucGxhY2Vfb3JkZXIge1xuICBoZWlnaHQ6IDM4cHg7XG4gIHdpZHRoOiAzNCU7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG59XG5cbi5iYWNrYXJyb3cxIHtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIGNvbG9yOiAjRTQzMjJFO1xuICBmb250LXNpemU6IDI2cHg7XG59XG5cbi5jZW50ZXIxIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbi5pY29uLWFkZHJlc3Mge1xuICBmb250LXNpemU6IDEuMnJlbTtcbiAgY29sb3I6IHJlZDtcbiAgbWFyZ2luLXRvcDogMC4xcmVtO1xuICBtYXJnaW4tbGVmdDogMC41cmVtO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/select-address/select-address.page.ts":
  /*!*******************************************************!*\
    !*** ./src/app/select-address/select-address.page.ts ***!
    \*******************************************************/

  /*! exports provided: SelectAddressPage */

  /***/
  function srcAppSelectAddressSelectAddressPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SelectAddressPage", function () {
      return SelectAddressPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../auth.service */
    "./src/app/auth.service.ts");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");

    var SelectAddressPage = /*#__PURE__*/function () {
      function SelectAddressPage(location, alertCtrl, navCtrl, auth, change) {
        _classCallCheck(this, SelectAddressPage);

        this.location = location;
        this.alertCtrl = alertCtrl;
        this.navCtrl = navCtrl;
        this.auth = auth;
        this.change = change;
        this.addressList = [];
        this.allUpdatedAddress = [];
        this.mycheck = false;
        this.user_id = localStorage.getItem("id");
        this.cartData = JSON.parse(localStorage.getItem("cartData"));
        this.mainSubTotal = localStorage.getItem("mainsubtotal");
      }

      _createClass(SelectAddressPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          this.fngetAddressDetails();
        }
      }, {
        key: "fnAddNewAddress",
        value: function fnAddNewAddress() {
          this.navCtrl.navigateForward('add-address');
        }
      }, {
        key: "fnBackToYourCart",
        value: function fnBackToYourCart() {
          this.navCtrl.navigateForward('your-cart');
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.location.back();
        }
      }, {
        key: "fngetAddressDetails",
        value: function fngetAddressDetails() {
          var _this = this;

          this.allUpdatedAddress = [];
          this.requestObject = {
            "user_id": this.user_id
          };
          this.auth.showLoader();
          this.auth.getAddressList(this.requestObject).subscribe(function (data) {
            _this.auth.hideLoader();

            _this.dataResponse = data.data;
            _this.addressList = _this.dataResponse;

            _this.addressList.forEach(function (element) {
              element.is_check = false;
            });

            var _iterator = _createForOfIteratorHelper(_this.addressList),
                _step;

            try {
              for (_iterator.s(); !(_step = _iterator.n()).done;) {
                var obj = _step.value;

                _this.allUpdatedAddress.push({
                  id: obj.id,
                  address_user_id: obj.address_user_id,
                  address_house_no: obj.address_house_no,
                  address_area: obj.address_area,
                  address_city: obj.address_city,
                  address_state: obj.address_state,
                  address_landmark: obj.address_landmark,
                  address_zipcode: obj.address_zipcode,
                  address_type: obj.address_type,
                  address_mobile_no: obj.address_mobile_no,
                  address_created: obj.address_created,
                  address_updated: obj.address_updated,
                  name: obj.name,
                  value: false
                });
              }
            } catch (err) {
              _iterator.e(err);
            } finally {
              _iterator.f();
            }

            console.log('allUpdatedAddress - > ', _this.allUpdatedAddress);
          }, function (err) {
            console.log("Error=>", err);

            _this.auth.hideLoader();
          });
        }
      }, {
        key: "updateAddress",
        value: function updateAddress(data) {
          console.log(data);
          this.navCtrl.navigateForward('edit-address', {
            state: {
              data: data,
              from: '1'
            }
          });
        }
      }, {
        key: "fnProceedToCheckout",
        value: function fnProceedToCheckout() {
          var _this2 = this;

          if (this.mycheck == false) {
            this.auth.showToast('Please select address');
            return;
          }

          this.address_id = this.allUpdatedAddress[this.address_index].id;
          var sendcartDate = [];
          this.cartData.forEach(function (element) {
            sendcartDate.push({
              'productId': element.id,
              'product_price': element.price,
              'product_qty': element.qty,
              'totalPrice': parseInt(element.price) * parseInt(element.qty)
            });
          });
          this.requestObject = {
            "userId": this.user_id,
            "totalAmount": this.mainSubTotal,
            "addressId": this.address_id,
            "cartData": sendcartDate
          };
          this.auth.showLoader();
          this.auth.orderPlace(this.requestObject).subscribe(function (data) {
            _this2.auth.hideLoader();

            if (data.status == true) {
              localStorage.removeItem('cartData');
              localStorage.setItem('OrderNumber', data.data.order_id);

              _this2.auth.showToast('Orders Place successfully');

              _this2.navCtrl.navigateRoot('success-order');
            } else {
              _this2.auth.showToast(data.message);
            }
          }, function (err) {
            console.log("Error=>", err);
          });
        }
      }, {
        key: "selection",
        value: function selection(id, index) {
          this.address_index = index;
          this.mycheck = !this.mycheck;
          this.allUpdatedAddress.forEach(function (x) {
            if (x.id !== id) {
              x.value = !x.value;
            }
          });
        }
      }, {
        key: "presentAlertConfirm",
        value: function presentAlertConfirm() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var alert;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.alertCtrl.create({
                      message: "Are you sure want to Book order?",
                      buttons: [{
                        text: 'Cancel',
                        role: 'cancel',
                        handler: function handler() {
                          console.log('Cancel clicked');
                        }
                      }, {
                        text: 'Logout',
                        handler: function handler() {
                          console.log('Logout clicked');
                        }
                      }]
                    });

                  case 2:
                    alert = _context.sent;
                    _context.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }]);

      return SelectAddressPage;
    }();

    SelectAddressPage.ctorParameters = function () {
      return [{
        type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["Location"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"]
      }];
    };

    SelectAddressPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-select-address',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./select-address.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/select-address/select-address.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./select-address.page.scss */
      "./src/app/select-address/select-address.page.scss"))["default"]]
    })], SelectAddressPage);
    /***/
  }
}]);
//# sourceMappingURL=select-address-select-address-module-es5.js.map