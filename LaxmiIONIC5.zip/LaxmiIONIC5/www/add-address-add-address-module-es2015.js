(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["add-address-add-address-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/add-address/add-address.page.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/add-address/add-address.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <!-- <ion-buttons slot=\"start\" class=\"main-title\">\n      <ion-menu-button auto-hide=\"false\"></ion-menu-button>\n    </ion-buttons> -->\n    <ion-buttons slot=\"start\">\n      <!-- <ion-back-button (click)=\"goBack()\" color=\"danger\"></ion-back-button> -->\n      <ion-icon name=\"arrow-back-outline\" (click)=\"goBack()\" class=\"backarrow1\"></ion-icon>\n    </ion-buttons>\n\n    <ion-buttons slot=\"end\">\n      <ion-button>\n\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"main-title\">Add Address</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-list>\n    <ion-card class=\"current-location\">\n      <!-- <ion-row class=\"center\">\n        <ion-col class=\"imgCard\" size=\"3\">\n          <img src=\"../../assets/imgs/gps-fixed-indicator.png\">\n        </ion-col>\n        <ion-col size=\"9\">\n          <ion-label class=\"txt-location\"><b>Use My Current Location</b></ion-label>\n        </ion-col>\n      </ion-row> -->\n\n    </ion-card>\n    <ion-card class=\"main-address ios\">\n      <h6 class=\"txt-location\"><b>Choose Your Address Type</b></h6>\n\n      <ion-row class=\"main-img ios\" style=\"margin-bottom: 15%;\">\n        <ion-radio-group [(ngModel)]=\"data\" (ionChange)=\"onChangeHandler($event)\" style=\"margin-top: 5px;display: flex;\">\n          <div class=\"office-img\">\n            <p class=\"p-office\">Office</p>\n\n            <ion-radio style=\"margin-left: 35px;margin-top: 17px;\" value=\"Office\" [checked]=\"this.data === 'Office'\">\n            </ion-radio>\n\n          </div>\n\n          <div class=\"home-img\">\n            <p class=\"p-office\">Home</p>\n\n            <ion-radio style=\"margin-left: 35px;margin-top: 17px;\"  value=\"Home\" [checked]=\"this.data === 'Home'\">\n            </ion-radio>\n\n          </div>\n\n          <div class=\"other-img\">\n            <p class=\"p-office\">Other</p>\n\n            <ion-radio style=\"margin-left: 35px;margin-top: 17px; \" value=\"Other\" [checked]=\"this.data === 'Other'\">\n            </ion-radio>\n\n          </div>\n\n        </ion-radio-group>\n      </ion-row>\n      <div class=\"input-wrap\" *ngIf=\"this.data === 'Office'\">\n         <div class=\"order-no-bg\">\n           <ion-input placeholder=\"GST No (Optional)\" [(ngModel)]=\"gstText\"\n             type=\"text\" name=\"GST_no\" class=\"order_no_txt\" (ionChange)=\"GSTFetch()\">\n           </ion-input>\n         </div> \n       </div>\n\n      <form [formGroup]=\"ionicForm\">\n\n        <!-- by arshad -->\n        <div class=\"input-wrap\">\n         <!--  <div class=\"order-no-bg\" style=\"margin-top: 15%;\">\n            <ion-input placeholder=\"GST No\" [(ngModel)]=\"gstText\"\n              type=\"text\" name=\"GST_no\" class=\"order_no_txt\" (ionChange)=\"GSTFetch()\">\n            </ion-input> -->\n            <!-- <ion-input placeholder=\"GST No\" formControlName=\"GSTNo\"  [formControl]=\"ionicForm.controls['GSTNo']\"\n              type=\"text\" name=\"GST_no\" class=\"order_no_txt\" (ionChange)=\"GSTFetch()\">\n            </ion-input> -->\n           <!--  <span class=\"error-wrap\" *ngIf=\"ionicForm.get('GSTNo').touched || ionicForm.get('GSTNo').dirty\">\n              <small *ngIf=\"ionicForm.get('GSTNo').hasError('required')\" class=\"error\">GST No is required.</small>\n            </span> -->\n          <!-- </div> -->\n        </div>\n        <!-- close -->\n        <div class=\"input-wrap\">\n          <div class=\"order-no-bg\" >\n            <ion-input placeholder=\"{{dataHint}} No\" formControlName=\"houseNo\" [formControl]=\"ionicForm.controls['houseNo']\"\n              type=\"text\" name=\"house_no\" class=\"order_no_txt\">\n            </ion-input>\n            <span class=\"error-wrap\" *ngIf=\"ionicForm.get('houseNo').touched || ionicForm.get('houseNo').dirty\">\n              <small *ngIf=\"ionicForm.get('houseNo').hasError('required')\" class=\"error\">{{dataHint}} Number is required.</small>\n            </span>\n          </div>\n        </div>\n\n        <div class=\"input-wrap\">\n          <div class=\"order-no-bg\">\n            <ion-input placeholder=\"Address\" formControlName=\"AreaColony\"\n              [formControl]=\"ionicForm.controls['AreaColony']\" type=\"text\" name=\"area\" class=\"order_no_txt\">\n            </ion-input>\n            <span class=\"error-wrap\" *ngIf=\"ionicForm.get('AreaColony').touched || ionicForm.get('AreaColony').dirty\">\n              <small *ngIf=\"ionicForm.get('AreaColony').hasError('required')\" class=\"error\">Address is\n                required.</small>\n            </span>\n          </div>\n        </div>\n        <ion-row style=\"margin-left: 10px;\n        margin-right: 10px;\">\n          <ion-col>\n            <div class=\"order-no-bgs\">\n              <ion-input  placeholder=\"City\" type=\"text\" formControlName=\"City\"\n                [formControl]=\"ionicForm.controls['City']\" name=\"city\" class=\"order_no_txt\"></ion-input>\n              <span class=\"error-wrap\" *ngIf=\"ionicForm.get('City').touched || ionicForm.get('City').dirty\">\n                <small *ngIf=\"ionicForm.get('City').hasError('required')\" class=\"error\">City is required.</small>\n                <small *ngIf=\"ionicForm.get('City').hasError('pattern')\" class=\"error\">Only character allowed.</small>\n              </span>\n            </div>\n          </ion-col>\n          <ion-col>\n            <div class=\"order-no-bgt\">\n              <ion-input  placeholder=\"State\" type=\"text\" formControlName=\"State\"\n                [formControl]=\"ionicForm.controls['State']\" name=\"state\" class=\"order_no_txt\">\n              </ion-input>\n              <span class=\"error-wrap\" *ngIf=\"ionicForm.get('State').touched || ionicForm.get('State').dirty\">\n                <small *ngIf=\"ionicForm.get('State').hasError('required')\" class=\"error\">State is required.</small>\n                <small *ngIf=\"ionicForm.get('State').hasError('pattern')\" class=\"error\">Only character allowed.</small>\n              </span>\n            </div>\n          </ion-col>\n        </ion-row>\n        <div class=\"input-wrap\">\n          <div class=\"order-no-bg\">\n            <ion-input placeholder=\"Landmark\" formControlName=\"Landmark\"\n              [formControl]=\"ionicForm.controls['Landmark']\" type=\"text\" name=\"landmark\" class=\"order_no_txt\">\n            </ion-input>\n\n            <span class=\"error-wrap\" *ngIf=\"ionicForm.get('Landmark').touched || ionicForm.get('Landmark').dirty\">\n              <small *ngIf=\"ionicForm.get('Landmark').hasError('required')\" class=\"error\">Landmark is required.</small>\n            </span>\n          </div>\n        </div>\n\n        <div class=\"input-wrap\">\n          <div class=\"order-no-bg\">\n            <ion-input maxlength=\"10\" placeholder=\"10-digit Mobile Number\" formControlName=\"MobileNo\"\n              [formControl]=\"ionicForm.controls['MobileNo']\" type=\"text\" name=\"mobile_no\" class=\"order_no_txt\">\n            </ion-input>\n            <span class=\"error-wrap\" *ngIf=\"ionicForm.get('MobileNo').touched || ionicForm.get('MobileNo').dirty\">\n              <small *ngIf=\"ionicForm.get('MobileNo').hasError('required')\" class=\"error\">Contact details required.</small>\n              <small *ngIf=\"ionicForm.get('MobileNo').hasError('minlength') || ionicForm.get('MobileNo').hasError('maxlength')\" class=\"error\">Contact details should be 10 \n                digits.</small>\n            </span>\n          </div>\n        </div>\n        <div class=\"input-wrap\">\n          <div class=\"order-no-bg\">\n            <ion-input placeholder=\"Zipcode\" type=\"number\" formControlName=\"Zipcode\"\n              [formControl]=\"ionicForm.controls['Zipcode']\" name=\"zipcode\" class=\"order_no_txt\">\n            </ion-input>\n            <span class=\"error-wrap\" *ngIf=\"ionicForm.get('Zipcode').touched || ionicForm.get('Zipcode').dirty\">\n              <small *ngIf=\"ionicForm.get('Zipcode').hasError('required')\" class=\"error\">Zipcode is required.</small>\n              <small *ngIf=\"ionicForm.get('Zipcode').hasError('pattern')\" class=\"error\">Enter valid Zipcode.</small>\n              <small\n                *ngIf=\"ionicForm.get('Zipcode').hasError('minlength') || ionicForm.get('Zipcode').hasError('maxlength')\"\n                class=\"error\">Zipcode should be 6 digits long.</small>\n            </span>\n          </div>\n        </div>\n        <button ion-button class=\"SaveAddress_btn\" (click)=\"fnSaveAddress()\"><b>Save Address</b></button>\n      </form>\n    </ion-card>\n  </ion-list>\n</ion-content>");

/***/ }),

/***/ "./src/app/add-address/add-address-routing.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/add-address/add-address-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: AddAddressPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddAddressPageRoutingModule", function() { return AddAddressPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _add_address_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./add-address.page */ "./src/app/add-address/add-address.page.ts");




const routes = [
    {
        path: '',
        component: _add_address_page__WEBPACK_IMPORTED_MODULE_3__["AddAddressPage"]
    }
];
let AddAddressPageRoutingModule = class AddAddressPageRoutingModule {
};
AddAddressPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AddAddressPageRoutingModule);



/***/ }),

/***/ "./src/app/add-address/add-address.module.ts":
/*!***************************************************!*\
  !*** ./src/app/add-address/add-address.module.ts ***!
  \***************************************************/
/*! exports provided: AddAddressPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddAddressPageModule", function() { return AddAddressPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _add_address_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./add-address-routing.module */ "./src/app/add-address/add-address-routing.module.ts");
/* harmony import */ var _add_address_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./add-address.page */ "./src/app/add-address/add-address.page.ts");







let AddAddressPageModule = class AddAddressPageModule {
};
AddAddressPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _add_address_routing_module__WEBPACK_IMPORTED_MODULE_5__["AddAddressPageRoutingModule"]
        ],
        declarations: [_add_address_page__WEBPACK_IMPORTED_MODULE_6__["AddAddressPage"]]
    })
], AddAddressPageModule);



/***/ }),

/***/ "./src/app/add-address/add-address.page.scss":
/*!***************************************************!*\
  !*** ./src/app/add-address/add-address.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".menu_btn {\n  color: #E4322E;\n}\n\n.main-title {\n  text-align: center;\n  color: #E4322E;\n}\n\n.current-location {\n  background-color: #fff;\n}\n\n.main-address {\n  background-color: #fff;\n  height: 115%;\n}\n\n.txt-location {\n  color: #E4322E;\n  text-align: center;\n}\n\n.error-wrap {\n  color: red;\n  font-size: 15px;\n}\n\n.input-wrap {\n  position: relative;\n}\n\n.input-wrap .login_text {\n  margin-bottom: 15px;\n}\n\n.input-wrap .error-wrap {\n  position: absolute;\n  bottom: -15px;\n}\n\n.img {\n  margin-left: 22px;\n  width: 9%;\n  height: 30px;\n  margin-top: 17px;\n}\n\n.office-img {\n  background-image: url('Group 569.png');\n  width: 90px;\n  height: 46px;\n  margin-right: 10px;\n}\n\n.home-img {\n  background-image: url('home.png');\n  width: 90px;\n  height: 46px;\n  margin-right: 10px;\n}\n\n.other-img {\n  background-image: url('other.png');\n  width: 90px;\n  height: 46px;\n}\n\n.p-office {\n  text-align: center;\n  font-size: 22px;\n  color: #fff;\n  margin-top: 10px;\n  margin-bottom: 0px;\n}\n\n.main-img {\n  justify-content: center;\n  margin-top: 5%;\n}\n\n.order-no-bg {\n  background-color: #f5f0f0;\n  width: 90%;\n  height: 45px;\n  margin-left: 20px;\n  border-radius: 7px;\n  margin-top: 22px;\n}\n\n.order_no_txt {\n  color: #010944;\n  margin-bottom: 5px;\n}\n\n.SaveAddress_btn {\n  background-color: #E4322E;\n  color: #fff;\n  font-size: 20px;\n  height: 40px;\n  width: 75%;\n  border-radius: 8px;\n  display: block;\n  margin: auto;\n  border: 1px solid #fff;\n  margin-top: 25px;\n  margin-bottom: 25px;\n}\n\n.order-no-bgs {\n  background-color: #f5f0f0;\n  width: 90%;\n  height: 45px;\n  margin-left: 6px;\n  border-radius: 7px;\n  margin-top: 15px;\n}\n\n.order-no-bgt {\n  background-color: #f5f0f0;\n  width: 90%;\n  height: 45px;\n  margin-left: 15px;\n  border-radius: 7px;\n  margin-top: 15px;\n}\n\n.ios {\n  color: #E4322E;\n  background-color: #fff;\n}\n\n.ios .current-location {\n  margin: 10px;\n}\n\n.p-check-icon-d {\n  color: #E4322E;\n  margin: auto;\n}\n\n.radio-icon {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n  height: 100%;\n  contain: size layout style;\n  color: red !important;\n}\n\n.imgCard {\n  text-align: end;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9hZGQtYWRkcmVzcy9hZGQtYWRkcmVzcy5wYWdlLnNjc3MiLCJzcmMvYXBwL2FkZC1hZGRyZXNzL2FkZC1hZGRyZXNzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGNBQUE7QUNDSjs7QURDQTtFQUNJLGtCQUFBO0VBQ0EsY0FBQTtBQ0VKOztBREFBO0VBQ0ksc0JBQUE7QUNHSjs7QUREQTtFQUNJLHNCQUFBO0VBQ0EsWUFBQTtBQ0lKOztBREZBO0VBQ0ksY0FBQTtFQUNBLGtCQUFBO0FDS0o7O0FESEE7RUFDSSxVQUFBO0VBQ0EsZUFBQTtBQ01KOztBREpBO0VBQ0ksa0JBQUE7QUNPSjs7QUROSTtFQUNFLG1CQUFBO0FDUU47O0FETkk7RUFDRSxrQkFBQTtFQUNBLGFBQUE7QUNRTjs7QURMQTtFQUVJLGlCQUFBO0VBQ0EsU0FBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQ09KOztBREhBO0VBRUksc0NBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FDS0o7O0FERkE7RUFFSSxpQ0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUNJSjs7QURGQTtFQUVJLGtDQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNJSjs7QUREQTtFQUNJLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FDSUo7O0FEREE7RUFFSSx1QkFBQTtFQUNBLGNBQUE7QUNHSjs7QUREQTtFQUNJLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUNJSjs7QURGQTtFQUNJLGNBQUE7RUFDQSxrQkFBQTtBQ0tKOztBREhBO0VBQ0kseUJBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtBQ01KOztBREpBO0VBQ0kseUJBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQ09KOztBRExBO0VBQ0kseUJBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQ1FKOztBRE5BO0VBQ0csY0FBQTtFQUNDLHNCQUFBO0FDU0o7O0FESEc7RUFDQyxZQUFBO0FDS0o7O0FERUE7RUFFSSxjQUFBO0VBQ0EsWUFBQTtBQ0FKOztBREdBO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLDBCQUFBO0VBQ0EscUJBQUE7QUNBSjs7QURHQTtFQUNJLGVBQUE7QUNBSiIsImZpbGUiOiJzcmMvYXBwL2FkZC1hZGRyZXNzL2FkZC1hZGRyZXNzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tZW51X2J0bntcbiAgICBjb2xvcjogI0U0MzIyRTtcbn1cbi5tYWluLXRpdGxle1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogI0U0MzIyRTsgXG59XG4uY3VycmVudC1sb2NhdGlvbntcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xufVxuLm1haW4tYWRkcmVzc3tcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAgIGhlaWdodDogMTE1JTtcbn1cbi50eHQtbG9jYXRpb257XG4gICAgY29sb3I6ICNFNDMyMkU7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuLmVycm9yLXdyYXB7XG4gICAgY29sb3I6IHJlZDsgXG4gICAgZm9udC1zaXplOiAxNXB4OyAgIFxufVxuLmlucHV0LXdyYXB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIC5sb2dpbl90ZXh0e1xuICAgICAgbWFyZ2luLWJvdHRvbTogMTVweDtcbiAgICB9XG4gICAgLmVycm9yLXdyYXB7XG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICBib3R0b206IC0xNXB4O1xuICAgIH1cbiAgfVxuLmltZ3tcbiAgICBcbiAgICBtYXJnaW4tbGVmdDogMjJweDtcbiAgICB3aWR0aDogOSU7XG4gICAgaGVpZ2h0OiAzMHB4O1xuICAgIG1hcmdpbi10b3A6IDE3cHg7XG5cbn1cblxuLm9mZmljZS1pbWd7XG5cbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy4uLy4uL2Fzc2V0cy9pbWdzL0dyb3VwIDU2OS5wbmcnKTtcbiAgICB3aWR0aDogOTBweDtcbiAgICBoZWlnaHQ6IDQ2cHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgXG59XG4uaG9tZS1pbWd7XG5cbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy4uLy4uL2Fzc2V0cy9pbWdzL2hvbWUucG5nJyk7XG4gICAgd2lkdGg6IDkwcHg7XG4gICAgaGVpZ2h0OiA0NnB4O1xuICAgIG1hcmdpbi1yaWdodDogMTBweDtcbn1cbi5vdGhlci1pbWd7XG5cbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy4uLy4uL2Fzc2V0cy9pbWdzL290aGVyLnBuZycpO1xuICAgIHdpZHRoOiA5MHB4O1xuICAgIGhlaWdodDogNDZweDtcbiAgIFxufVxuLnAtb2ZmaWNle1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXNpemU6IDIycHg7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgbWFyZ2luLXRvcDogMTBweDtcbiAgICBtYXJnaW4tYm90dG9tOiAwcHg7XG5cbn1cbi5tYWluLWltZ3tcblxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIG1hcmdpbi10b3A6IDUlO1xufVxuLm9yZGVyLW5vLWJne1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmNWYwZjA7XG4gICAgd2lkdGg6IDkwJTtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XG4gICAgYm9yZGVyLXJhZGl1czogN3B4O1xuICAgIG1hcmdpbi10b3A6IDIycHg7XG59XG4ub3JkZXJfbm9fdHh0e1xuICAgIGNvbG9yOiAjMDEwOTQ0O1xuICAgIG1hcmdpbi1ib3R0b206IDVweDtcbn1cbi5TYXZlQWRkcmVzc19idG57XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0U0MzIyRTtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgaGVpZ2h0OiA0MHB4O1xuICAgIHdpZHRoOiA3NSU7XG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIG1hcmdpbjogYXV0bztcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZmZmO1xuICAgIG1hcmdpbi10b3A6IDI1cHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMjVweDtcbn1cbi5vcmRlci1uby1iZ3N7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjBmMDtcbiAgICB3aWR0aDogOTAlO1xuICAgIGhlaWdodDogNDVweDtcbiAgICBtYXJnaW4tbGVmdDogNnB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDdweDtcbiAgICBtYXJnaW4tdG9wOiAxNXB4O1xufVxuLm9yZGVyLW5vLWJndHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmMGYwO1xuICAgIHdpZHRoOiA5MCU7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIG1hcmdpbi1sZWZ0OiAxNXB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDdweDtcbiAgICBtYXJnaW4tdG9wOiAxNXB4O1xufVxuLmlvc3tcbiAgIGNvbG9yOiAjRTQzMjJFO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gICAgXG4gICBcbi8vICAgIG1hcmdpbjogOXB4O1xuLy8gICAgaGVpZ2h0OiAxMDclO1xuXG4gICAuY3VycmVudC1sb2NhdGlvbntcbiAgICBtYXJnaW46IDEwcHg7XG4gICB9XG59XG4vLyAubWFpbi1pbWcuaW9ze1xuLy8gICAgIG1hcmdpbi1yaWdodDogMTBweDtcbi8vIH1cblxuLnAtY2hlY2staWNvbi1ke1xuIFxuICAgIGNvbG9yOiAjRTQzMjJFO1xuICAgIG1hcmdpbjogYXV0bztcblxufVxuLnJhZGlvLWljb24ge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgY29udGFpbjogc2l6ZSBsYXlvdXQgc3R5bGU7XG4gICAgY29sb3I6cmVkICFpbXBvcnRhbnQ7XG59XG5cbi5pbWdDYXJke1xuICAgIHRleHQtYWxpZ246IGVuZDtcbn0iLCIubWVudV9idG4ge1xuICBjb2xvcjogI0U0MzIyRTtcbn1cblxuLm1haW4tdGl0bGUge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjRTQzMjJFO1xufVxuXG4uY3VycmVudC1sb2NhdGlvbiB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG59XG5cbi5tYWluLWFkZHJlc3Mge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICBoZWlnaHQ6IDExNSU7XG59XG5cbi50eHQtbG9jYXRpb24ge1xuICBjb2xvcjogI0U0MzIyRTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uZXJyb3Itd3JhcCB7XG4gIGNvbG9yOiByZWQ7XG4gIGZvbnQtc2l6ZTogMTVweDtcbn1cblxuLmlucHV0LXdyYXAge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4uaW5wdXQtd3JhcCAubG9naW5fdGV4dCB7XG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XG59XG4uaW5wdXQtd3JhcCAuZXJyb3Itd3JhcCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm90dG9tOiAtMTVweDtcbn1cblxuLmltZyB7XG4gIG1hcmdpbi1sZWZ0OiAyMnB4O1xuICB3aWR0aDogOSU7XG4gIGhlaWdodDogMzBweDtcbiAgbWFyZ2luLXRvcDogMTdweDtcbn1cblxuLm9mZmljZS1pbWcge1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuLi8uLi9hc3NldHMvaW1ncy9Hcm91cCA1NjkucG5nXCIpO1xuICB3aWR0aDogOTBweDtcbiAgaGVpZ2h0OiA0NnB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG5cbi5ob21lLWltZyB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi4uLy4uL2Fzc2V0cy9pbWdzL2hvbWUucG5nXCIpO1xuICB3aWR0aDogOTBweDtcbiAgaGVpZ2h0OiA0NnB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG5cbi5vdGhlci1pbWcge1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuLi8uLi9hc3NldHMvaW1ncy9vdGhlci5wbmdcIik7XG4gIHdpZHRoOiA5MHB4O1xuICBoZWlnaHQ6IDQ2cHg7XG59XG5cbi5wLW9mZmljZSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1zaXplOiAyMnB4O1xuICBjb2xvcjogI2ZmZjtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xufVxuXG4ubWFpbi1pbWcge1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgbWFyZ2luLXRvcDogNSU7XG59XG5cbi5vcmRlci1uby1iZyB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmNWYwZjA7XG4gIHdpZHRoOiA5MCU7XG4gIGhlaWdodDogNDVweDtcbiAgbWFyZ2luLWxlZnQ6IDIwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDdweDtcbiAgbWFyZ2luLXRvcDogMjJweDtcbn1cblxuLm9yZGVyX25vX3R4dCB7XG4gIGNvbG9yOiAjMDEwOTQ0O1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG59XG5cbi5TYXZlQWRkcmVzc19idG4ge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTQzMjJFO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBoZWlnaHQ6IDQwcHg7XG4gIHdpZHRoOiA3NSU7XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbjogYXV0bztcbiAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbiAgbWFyZ2luLXRvcDogMjVweDtcbiAgbWFyZ2luLWJvdHRvbTogMjVweDtcbn1cblxuLm9yZGVyLW5vLWJncyB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmNWYwZjA7XG4gIHdpZHRoOiA5MCU7XG4gIGhlaWdodDogNDVweDtcbiAgbWFyZ2luLWxlZnQ6IDZweDtcbiAgYm9yZGVyLXJhZGl1czogN3B4O1xuICBtYXJnaW4tdG9wOiAxNXB4O1xufVxuXG4ub3JkZXItbm8tYmd0IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjBmMDtcbiAgd2lkdGg6IDkwJTtcbiAgaGVpZ2h0OiA0NXB4O1xuICBtYXJnaW4tbGVmdDogMTVweDtcbiAgYm9yZGVyLXJhZGl1czogN3B4O1xuICBtYXJnaW4tdG9wOiAxNXB4O1xufVxuXG4uaW9zIHtcbiAgY29sb3I6ICNFNDMyMkU7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG59XG4uaW9zIC5jdXJyZW50LWxvY2F0aW9uIHtcbiAgbWFyZ2luOiAxMHB4O1xufVxuXG4ucC1jaGVjay1pY29uLWQge1xuICBjb2xvcjogI0U0MzIyRTtcbiAgbWFyZ2luOiBhdXRvO1xufVxuXG4ucmFkaW8taWNvbiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBjb250YWluOiBzaXplIGxheW91dCBzdHlsZTtcbiAgY29sb3I6IHJlZCAhaW1wb3J0YW50O1xufVxuXG4uaW1nQ2FyZCB7XG4gIHRleHQtYWxpZ246IGVuZDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/add-address/add-address.page.ts":
/*!*************************************************!*\
  !*** ./src/app/add-address/add-address.page.ts ***!
  \*************************************************/
/*! exports provided: AddAddressPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddAddressPage", function() { return AddAddressPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");






const RES_DATA = {
    taxpayerInfo: {
        ctjCd: 'ZD1102',
        stj: 'Mukatsar - Ward No.5',
        pradr: {
            addr: {
                city: '',
                bno: '1915',
                flno: '',
                loc: 'GIDDERBAHA',
                st: 'STREET NO. 02',
                lg: '',
                dst: 'Muktsar',
                stcd: 'Punjab',
                lt: '',
                bnm: 'SHAHEED BHAGAT SINGH NAGAR',
                pncd: '152101',
            },
            ntr: 'Export',
        },
        dty: 'Regular',
        frequencyType: null,
        errorMsg: null,
        tradeNam: 'BROADVIEW INNOVATIONS PRIVATE LIMITED',
        rgdt: '02/11/2018',
        adadr: [],
        nba: ['Export'],
        cxdt: '',
        ctj: 'GIDDERBAHA',
        sts: 'Active',
        stjCd: 'PB165',
        ctb: 'Private Limited Company',
        gstin: '03AAFCB3420K1Z3',
        lgnm: 'BROADVIEW INNOVATIONS PRIAVATE LIMITED',
        panNo: 'AAFCB3420K',
    },
    filing: [],
    compliance: {
        filingFrequency: null,
    },
};
let AddAddressPage = class AddAddressPage {
    constructor(formbulider, location, navCtrl, auth, toast) {
        this.formbulider = formbulider;
        this.location = location;
        this.navCtrl = navCtrl;
        this.auth = auth;
        this.toast = toast;
        this.onlynumeric = /^-?(0|[1-9]\d*)?$/;
        this.data = "Home";
        this.dataHint = 'Home';
        this.user_id = localStorage.getItem("id");
        this.ionicForm = this.formbulider.group({
            /*  GSTNo: ['', [Validators.required]], */
            houseNo: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]],
            AreaColony: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]],
            State: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].pattern('[a-zA-Z ]*')]],
            City: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].pattern('[a-zA-Z ]*')]],
            Landmark: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]],
            MobileNo: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].minLength(10), _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].maxLength(10), _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].pattern(this.onlynumeric)]],
            Zipcode: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].minLength(6), _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].maxLength(6), _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].pattern(this.onlynumeric)]]
        });
    }
    ngOnInit() {
    }
    onChangeHandler(event) {
        this.data = event.target.value;
        if (this.data !== "Office") {
            this.gstText = '';
        }
        if (this.data === "Other") {
            this.dataHint = 'Resident';
        }
        if (this.data === "Home") {
            this.dataHint = 'Home';
        }
        if (this.data === "Office") {
            this.dataHint = 'Office';
        }
    }
    GSTFetch() {
        // let dd = this.ionicForm.get('GSTNo').value
        let dd = this.gstText;
        if (this.fetchGst)
            clearTimeout(this.fetchGst);
        this.fetchGst = setTimeout(() => {
            console.log(dd);
            this.fnGetGST(dd);
        }, 1000);
    }
    fnGetGST(gst) {
        if (gst.length < 14) {
            return false;
        }
        this.auth.showLoader();
        this.auth.getAddressFromGst(gst).subscribe((data) => {
            this.auth.hideLoader();
            if (data.error === true) {
                this.auth.showToast(data.message);
            }
            else {
                this.ionicForm.setValue({
                    /*  GSTNo: gst, */
                    houseNo: data.taxpayerInfo.pradr.addr.bnm,
                    AreaColony: data.taxpayerInfo.pradr.addr.flno,
                    Landmark: data.taxpayerInfo.pradr.addr.st,
                    Zipcode: data.taxpayerInfo.pradr.addr.pncd,
                    City: data.taxpayerInfo.pradr.addr.dst,
                    State: data.taxpayerInfo.pradr.addr.stcd,
                    MobileNo: '',
                });
            }
        }, (err) => {
            this.auth.hideLoader();
            console.log("Error=>", err);
        });
    }
    goBack() {
        this.location.back();
    }
    fnSaveAddress() {
        if (this.ionicForm.invalid) {
            console.log('invalid');
            // this.ionicForm.get('GSTNo').markAllAsTouched();
            this.ionicForm.get('houseNo').markAsTouched();
            this.ionicForm.get('AreaColony').markAsTouched();
            this.ionicForm.get('State').markAsTouched();
            this.ionicForm.get('City').markAsTouched();
            this.ionicForm.get('Landmark').markAsTouched();
            this.ionicForm.get('MobileNo').markAsTouched();
            this.ionicForm.get('Zipcode').markAsTouched();
            return false;
        }
        console.log('OK');
        this.requestObject = {
            "house_no": this.ionicForm.get('houseNo').value,
            "area": this.ionicForm.get('AreaColony').value,
            "city": this.ionicForm.get('City').value,
            "state": this.ionicForm.get('State').value,
            "landmark": this.ionicForm.get('Landmark').value,
            "zipcode": this.ionicForm.get('Zipcode').value,
            "mobile_no": this.ionicForm.get('MobileNo').value,
            "user_id": this.user_id,
            "gst_no": this.gstText,
            "address_type": this.data
        };
        console.log(this.requestObject);
        this.auth.showLoader();
        this.auth.addAddress(this.requestObject).subscribe((data) => {
            this.dataResponse = data;
            console.log(this.dataResponse);
            this.auth.hideLoader();
            if (this.dataResponse.status == true) {
                this.auth.showToast('Save address successfully');
                this.navCtrl.navigateForward('select-address');
            }
        }, (err) => {
            this.auth.hideLoader();
            console.log("Error=>", err);
        });
    }
};
AddAddressPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["Location"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
];
AddAddressPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-add-address',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./add-address.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/add-address/add-address.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./add-address.page.scss */ "./src/app/add-address/add-address.page.scss")).default]
    })
], AddAddressPage);



/***/ })

}]);
//# sourceMappingURL=add-address-add-address-module-es2015.js.map