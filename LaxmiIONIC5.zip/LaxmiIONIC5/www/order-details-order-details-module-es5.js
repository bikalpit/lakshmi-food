function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["order-details-order-details-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/order-details/order-details.page.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/order-details/order-details.page.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppOrderDetailsOrderDetailsPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <!-- <ion-buttons slot=\"start\" class=\"menu_btn\">\n      <ion-menu-button auto-hide=\"false\"></ion-menu-button>\n    </ion-buttons> -->\n    <ion-buttons slot=\"start\">\n      <!-- <ion-back-button (click)=\"goBack()\" color=\"danger\"></ion-back-button> -->\n      <ion-icon name=\"arrow-back-outline\" class=\"backarrow1\" (click)=\"goBack()\"></ion-icon>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-button>\n\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"main-title\">Order Details</ion-title>\n  </ion-toolbar>\n</ion-header> \n\n<ion-content>\n  <ion-list *ngIf=\"ordersDetails\">\n\n    <ion-card class=\"main-card\">\n      <ion-grid>\n        <ion-row>\n          <ion-col>\n            <h4 class=\"p-label2\">Order # {{ordersDetails.order_number}}</h4>\n          </ion-col>\n          <ion-col>\n            <h6 class=\"p-label\">Order Date</h6>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n      <ion-grid>\n        <ion-row>\n          <ion-col>\n            <!-- <h4 class=\"p-price\">{{ordersDetails.status}}</h4> -->\n            <h4 class=\"p-price\" *ngIf=\"ordersDetails.status == 'New'\">Pending</h4>\n            <h4 class=\"p-price\" *ngIf=\"ordersDetails.status == 'Pickup'\">Pickup</h4>\n            <h4 class=\"p-price\" *ngIf=\"ordersDetails.status == 'Assigned'\">Assigned</h4>\n            <h4 class=\"p-price\" *ngIf=\"ordersDetails.status == 'Approve'\">Approve</h4>\n            <h4 class=\"p-price\" *ngIf=\"ordersDetails.status == 'cancel'\">Cancel</h4>\n            <h4 class=\"p-price\" *ngIf=\"ordersDetails.status == 'Delivered'\">Delivered</h4>\n          </ion-col>\n\n          <ion-col>\n            <h6 class=\"p-date\">{{orderDate}}</h6>\n          </ion-col>\n\n        </ion-row>\n      </ion-grid>\n    </ion-card>\n\n    <ion-card class=\"cust-profile\">\n      <p class=\"profile-txt\"><b>Customer Profile</b></p>\n      <ion-row>\n        <ion-col size=\"4\">\n          <h4 class=\"p-label2\">Firm Name</h4>\n        </ion-col>\n\n        <ion-col size=\"8\">\n          <h6 class=\"p-label-nm\">{{ordersDetails.firm_name}}</h6>\n        </ion-col>\n\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"4\">\n          <h4 class=\"p-label2\">Name</h4>\n        </ion-col>\n\n        <ion-col size=\"8\">\n          <h6 class=\"p-label-nm\">{{ordersDetails.name}}</h6>\n        </ion-col>\n\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"4\">\n          <h4 class=\"p-label2\">Email</h4>\n        </ion-col>\n\n        <ion-col size=\"8\">\n          <h6 class=\"p-label-nm\">{{ordersDetails.email}}</h6>\n        </ion-col>\n\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"4\">\n          <h4 class=\"p-label2\">Contact </h4>\n        </ion-col>\n\n        <ion-col size=\"8\">\n          <h6 class=\"p-label-nm\">{{ordersDetails.phone}}</h6>\n        </ion-col>\n\n      </ion-row>\n    </ion-card>\n    <ion-card class=\"main-card-item\">\n      <p class=\"profile-txt\"><b>Address</b></p>\n      <!--  <h6 class=\"add-txt\"><img src=\"../../assets/imgs/location.png\"\n          class=\"img\">{{ordersDetails.address_house_no}},{{ordersDetails.address_city}}{{ordersDetails.address_state}}\n      </h6> -->\n      <ion-row style=\"font-size: 16px; font-weight: bold;\">\n        <ion-col size=\"1\">\n          <img src=\"../../assets/imgs/location.png\" class=\"img\">\n        </ion-col>\n        <ion-col size=\"11\" *ngIf=\"ordersDetails.address_house_no!==''\">\n          {{ordersDetails.address_house_no}}, {{ordersDetails.address_landmark}}, {{ordersDetails.address_city}},\n          {{ordersDetails.address_state}}, {{ordersDetails.address_zipcode}}\n        </ion-col>\n        <ion-col size=\"11\" *ngIf=\"ordersDetails.address_house_no===''\">\n          {{ordersDetails.address_landmark}}, {{ordersDetails.address_city}},\n          {{ordersDetails.address_state}}, {{ordersDetails.address_zipcode}}\n        </ion-col>\n      </ion-row>\n    </ion-card>\n    <!-- <div *ngFor=\"let item of orderItem;\"> -->\n    <ion-card class=\"main-card-item\">\n      <ion-card-content>\n        <h5 class=\"p-label3\"><b>Items</b></h5>\n        <div *ngFor=\"let item of orderItem;\" style=\"margin-top: 20px;\">\n          <h6 class=\"p-qty\">{{item.product_name}} {{item.product_weight}}Kg</h6>\n\n          <ion-row>\n            <ion-col>\n              <h6 class=\"p-qty\">Qty {{item.qty}} × ₹{{item.product_price}}</h6>\n            </ion-col>\n\n            <h6 class=\"p-label4\">₹{{item.price}}</h6>\n          </ion-row>\n        </div>\n      </ion-card-content>\n    </ion-card>\n\n    <ion-card class=\"main-card-item\" *ngIf=\"ordersDetails.ApproveUser && ordersDetails.ApproveUser!==null && role==='DeliveryBoy'\">\n      <ion-card-header>\n        <ion-card-title>Assigned By</ion-card-title>\n      </ion-card-header>\n      <ion-item>\n        <ion-avatar slot=\"start\" *ngIf=\"ordersDetails.ApproveUser.photo  && ordersDetails.ApproveUser.photo !==null\">\n          <img src=\"{{url.file_url}}assets/uploads/users/{{ordersDetails.ApproveUser.photo}}\">\n        </ion-avatar>\n        <ion-avatar slot=\"start\" *ngIf=\"ordersDetails.ApproveUser.photo === null || ordersDetails.ApproveUser.photo ===''\">\n          <img src=\"../../assets/imgs/avatar1.png\">\n        </ion-avatar>\n        <ion-label>\n          <h3>{{ordersDetails.ApproveUser.name}}</h3>\n          <p>{{ordersDetails.ApproveUser.phone}}</p>\n        </ion-label>\n      </ion-item>\n      <ion-card-content>\n\n      </ion-card-content>\n    </ion-card>\n\n    <ion-row class=\"cancel_completed_btn\">\n      <ion-col hidden *ngIf=\"ordersDetails.status && ordersDetails.status != 'cancel' && ordersDetails.status !='Delivered'\">\n        <button ion-button class=\"cancelOrder_btn\"\n          (click)=\"fnCancelOrder(ordersDetails.id,ordersDetails.order_number,'CD')\">Cancel</button>\n      </ion-col>\n\n      <ion-col>\n        <button ion-button *ngIf=\"ordersDetails.status == 'Assigned'\" class=\"completed_btn\"\n          (click)=\"fnCompleted('Pickup')\">Pickup</button>\n        <button ion-button *ngIf=\"ordersDetails.status == 'Pickup'\" class=\"completed_btn\"\n          (click)=\"fnCompleted('Delivered')\">Deliver</button>\n        <!-- <button ion-button *ngIf=\"ordersDetails.status == 'Delivered'\" class=\"completed_btn\" (click)=\"fnCompleted('Completed')\">Completed</button> -->\n\n      </ion-col>\n    </ion-row> \n  </ion-list>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/order-details/order-details-routing.module.ts":
  /*!***************************************************************!*\
    !*** ./src/app/order-details/order-details-routing.module.ts ***!
    \***************************************************************/

  /*! exports provided: OrderDetailsPageRoutingModule */

  /***/
  function srcAppOrderDetailsOrderDetailsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OrderDetailsPageRoutingModule", function () {
      return OrderDetailsPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _order_details_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./order-details.page */
    "./src/app/order-details/order-details.page.ts");

    var routes = [{
      path: '',
      component: _order_details_page__WEBPACK_IMPORTED_MODULE_3__["OrderDetailsPage"]
    }];

    var OrderDetailsPageRoutingModule = function OrderDetailsPageRoutingModule() {
      _classCallCheck(this, OrderDetailsPageRoutingModule);
    };

    OrderDetailsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], OrderDetailsPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/order-details/order-details.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/order-details/order-details.module.ts ***!
    \*******************************************************/

  /*! exports provided: OrderDetailsPageModule */

  /***/
  function srcAppOrderDetailsOrderDetailsModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OrderDetailsPageModule", function () {
      return OrderDetailsPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _order_details_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./order-details-routing.module */
    "./src/app/order-details/order-details-routing.module.ts");
    /* harmony import */


    var _order_details_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./order-details.page */
    "./src/app/order-details/order-details.page.ts");

    var OrderDetailsPageModule = function OrderDetailsPageModule() {
      _classCallCheck(this, OrderDetailsPageModule);
    };

    OrderDetailsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _order_details_routing_module__WEBPACK_IMPORTED_MODULE_5__["OrderDetailsPageRoutingModule"]],
      declarations: [_order_details_page__WEBPACK_IMPORTED_MODULE_6__["OrderDetailsPage"]]
    })], OrderDetailsPageModule);
    /***/
  },

  /***/
  "./src/app/order-details/order-details.page.scss":
  /*!*******************************************************!*\
    !*** ./src/app/order-details/order-details.page.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppOrderDetailsOrderDetailsPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".menu_btn {\n  color: #E4322E;\n}\n\n.main-title {\n  color: #E4322E;\n  text-align: center;\n  font-family: open sans;\n}\n\n.main-card {\n  margin-top: 20px;\n  background-color: #fff;\n}\n\n.p-label2 {\n  font-family: open sans;\n  margin-top: 0px;\n  margin-bottom: 5px;\n  margin-right: 10px;\n  color: #000;\n  font-size: 16px;\n}\n\n.p-label {\n  font-family: open sans;\n  margin-top: 0px;\n  margin-bottom: 0px;\n  margin-right: 10px;\n  color: #000;\n  float: right;\n  font-size: 16px;\n}\n\n.p-price {\n  font-size: 22px;\n  margin-top: 0px;\n  margin-bottom: 0px;\n  color: #000;\n  font-family: open sans;\n}\n\n.p-date {\n  margin-top: 0px;\n  margin-bottom: 0px;\n  margin-right: 10px;\n  color: #000;\n  float: right;\n  font-size: 22px;\n  font-family: open sans;\n}\n\n.p-qty {\n  color: #000;\n  margin: 0;\n  margin-left: 10px;\n  font-family: open sans;\n  font-size: 16px;\n}\n\n.cust-profile {\n  background-color: #fff;\n}\n\n.p-label-nm {\n  font-family: open sans;\n  margin-top: 0px;\n  margin-bottom: 0px;\n  margin-right: 10px;\n  color: #000;\n  font-size: 16px;\n}\n\n.profile-txt {\n  font-size: 18px;\n  color: #000;\n  margin-left: 10px;\n  font-family: open sans;\n}\n\n.add-txt {\n  margin-left: 10px;\n  font-family: open sans;\n}\n\n.img {\n  margin-right: 10px;\n}\n\n.p-label3 {\n  margin-bottom: 10px;\n  margin-left: 10px;\n  color: #000;\n  font-family: open sans;\n  font-size: 18px;\n}\n\n.p-label4 {\n  margin-top: 0px;\n  margin-bottom: 0px;\n  margin-right: 10px;\n  color: #000;\n  float: right;\n  font-family: open sans;\n  font-size: 18px;\n}\n\n.p-qty1 {\n  color: #000;\n  margin: 0;\n  margin-left: 10px;\n  margin-top: 14px;\n  font-family: open sans;\n  font-size: 18px;\n}\n\n.main-card-item {\n  margin-top: -7px;\n  height: 30%;\n}\n\n.main-card-item ion-card-content {\n  padding: 0;\n  max-height: calc(125% - 50px);\n  position: relative;\n  overflow: hidden;\n  overflow-y: auto;\n}\n\n.main-card-item ion-card-content ::-webkit-scrollbar {\n  display: none;\n}\n\n.cancel_completed_btn {\n  margin-top: 12%;\n  margin-bottom: 8px;\n}\n\n.cancel_completed_btn .cancelOrder_btn {\n  background-color: #E4322E;\n  color: #fff;\n  font-size: 20px;\n  height: 40px;\n  width: 90%;\n  border-radius: 8px;\n  display: block;\n  margin: auto;\n  border: 1px solid #fff;\n  margin-right: 12px;\n  margin-left: 6px;\n  margin-top: 3px;\n  font-family: open sans;\n}\n\n.cancel_completed_btn .completed_btn {\n  background-color: #E4322E;\n  color: #fff;\n  font-size: 20px;\n  height: 40px;\n  width: 90%;\n  border-radius: 8px;\n  display: block;\n  margin: auto;\n  border: 1px solid #fff;\n  margin-right: 12px;\n  margin-left: 12px;\n  margin-top: 3px;\n  font-family: open sans;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9vcmRlci1kZXRhaWxzL29yZGVyLWRldGFpbHMucGFnZS5zY3NzIiwic3JjL2FwcC9vcmRlci1kZXRhaWxzL29yZGVyLWRldGFpbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtBQ0NKOztBRENBO0VBQ0ksY0FBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7QUNFSjs7QURBQztFQUVHLGdCQUFBO0VBQ0Esc0JBQUE7QUNFSjs7QURBQTtFQUNJLHNCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtBQ0dKOztBREFBO0VBQ0ksc0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtBQ0dKOztBRERBO0VBQ0ksZUFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxzQkFBQTtBQ0lKOztBREZBO0VBQ0ksZUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxzQkFBQTtBQ0tKOztBREhBO0VBQ0ksV0FBQTtFQUNBLFNBQUE7RUFDQSxpQkFBQTtFQUNBLHNCQUFBO0VBQ0EsZUFBQTtBQ01KOztBREpBO0VBRUksc0JBQUE7QUNNSjs7QURKQTtFQUNJLHNCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBRUEsZUFBQTtBQ01KOztBREpBO0VBQ0ksZUFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLHNCQUFBO0FDT0o7O0FETEE7RUFDSSxpQkFBQTtFQUNBLHNCQUFBO0FDUUo7O0FETkE7RUFDSSxrQkFBQTtBQ1NKOztBRE5BO0VBQ0ksbUJBQUE7RUFDQSxpQkFBQTtFQUNBLFdBQUE7RUFDQSxzQkFBQTtFQUNBLGVBQUE7QUNTSjs7QURQQTtFQUNJLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtFQUNBLGVBQUE7QUNVSjs7QURSQTtFQUNJLFdBQUE7RUFDQSxTQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLHNCQUFBO0VBQ0EsZUFBQTtBQ1dKOztBRFRBO0VBQ0ksZ0JBQUE7RUFFQSxXQUFBO0FDV0o7O0FEVkk7RUFDSSxVQUFBO0VBQ0EsNkJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7QUNZUjs7QURYUTtFQUNFLGFBQUE7QUNhVjs7QURUQTtFQUNJLGVBQUE7RUFDQSxrQkFBQTtBQ1lKOztBRFhJO0VBQ0kseUJBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxzQkFBQTtBQ2FSOztBRFhJO0VBQ0kseUJBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxzQkFBQTtBQ2FSIiwiZmlsZSI6InNyYy9hcHAvb3JkZXItZGV0YWlscy9vcmRlci1kZXRhaWxzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tZW51X2J0bntcbiAgICBjb2xvcjogI0U0MzIyRTtcbn1cbi5tYWluLXRpdGxle1xuICAgIGNvbG9yOiAjRTQzMjJFO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuIH1cbiAubWFpbi1jYXJke1xuICAgIC8vIGJveC1zaGFkb3c6IDVweCA3cHggMTBweCA1cHggI2U4ZThlODtcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG59XG4ucC1sYWJlbDJ7XG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgICBtYXJnaW4tdG9wOiAwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICBjb2xvcjogIzAwMDtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgLy9mbG9hdDogcmlnaHQ7XG59XG4ucC1sYWJlbHtcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgIGNvbG9yOiAjMDAwO1xuICAgIGZsb2F0OiByaWdodDtcbiAgICBmb250LXNpemU6IDE2cHg7XG59XG4ucC1wcmljZXtcbiAgICBmb250LXNpemU6IDIycHg7XG4gICAgbWFyZ2luLXRvcDogMHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDBweDtcbiAgICBjb2xvcjogIzAwMDsgXG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cbi5wLWRhdGV7XG4gICAgbWFyZ2luLXRvcDogMHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDBweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgY29sb3I6ICMwMDA7XG4gICAgZmxvYXQ6IHJpZ2h0O1xuICAgIGZvbnQtc2l6ZTogMjJweDtcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuLnAtcXR5e1xuICAgIGNvbG9yOiAjMDAwO1xuICAgIG1hcmdpbjogMDtcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbn1cbi5jdXN0LXByb2ZpbGV7XG4gICAgLy8gYm94LXNoYWRvdzogNXB4IDdweCAxMHB4IDVweCAjZThlOGU4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG59XG4ucC1sYWJlbC1ubXtcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgIGNvbG9yOiAjMDAwO1xuICAgIC8vIGZsb2F0OiBsZWZ0O1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbn1cbi5wcm9maWxlLXR4dHtcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgY29sb3I6ICMwMDA7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cbi5hZGQtdHh0e1xuICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG59XG4uaW1ne1xuICAgIG1hcmdpbi1yaWdodDogMTBweDtcbn1cblxuLnAtbGFiZWwze1xuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgY29sb3I6ICMwMDA7XG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgICBmb250LXNpemU6IDE4cHg7XG59XG4ucC1sYWJlbDR7XG4gICAgbWFyZ2luLXRvcDogMHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDBweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgY29sb3I6ICMwMDA7XG4gICAgZmxvYXQ6IHJpZ2h0O1xuICAgIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG4gICAgZm9udC1zaXplOiAxOHB4O1xufVxuLnAtcXR5MXtcbiAgICBjb2xvcjogIzAwMDtcbiAgICBtYXJnaW46IDA7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgbWFyZ2luLXRvcDogMTRweDtcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbn1cbi5tYWluLWNhcmQtaXRlbXtcbiAgICBtYXJnaW4tdG9wOiAtN3B4O1xuICAgIC8vIGJveC1zaGFkb3c6IDVweCA3cHggMTBweCA1cHggI2U4ZThlODtcbiAgICBoZWlnaHQ6IDMwJTtcbiAgICBpb24tY2FyZC1jb250ZW50IHtcbiAgICAgICAgcGFkZGluZzogMDtcbiAgICAgICAgbWF4LWhlaWdodDogY2FsYygxMjUlIC0gI3s1MHB4fSk7XG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAgICAgb3ZlcmZsb3cteTogYXV0bztcbiAgICAgICAgOjotd2Via2l0LXNjcm9sbGJhciB7XG4gICAgICAgICAgZGlzcGxheTogbm9uZTtcbiAgICAgICAgfVxuICAgICAgfVxufVxuLmNhbmNlbF9jb21wbGV0ZWRfYnRue1xuICAgIG1hcmdpbi10b3A6IDEyJTtcbiAgICBtYXJnaW4tYm90dG9tOiA4cHg7ICAgICAgXG4gICAgLmNhbmNlbE9yZGVyX2J0bntcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI0U0MzIyRTtcbiAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICAgICAgaGVpZ2h0OiA0MHB4O1xuICAgICAgICB3aWR0aDogOTAlO1xuICAgICAgICBib3JkZXItcmFkaXVzOiA4cHg7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICBtYXJnaW46IGF1dG87XG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNmZmY7XG4gICAgICAgIG1hcmdpbi1yaWdodDogMTJweDtcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDZweDtcbiAgICAgICAgbWFyZ2luLXRvcDogM3B4O1xuICAgICAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICAgIH1cbiAgICAuY29tcGxldGVkX2J0bntcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI0U0MzIyRTtcbiAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICAgICAgaGVpZ2h0OiA0MHB4O1xuICAgICAgICB3aWR0aDogOTAlO1xuICAgICAgICBib3JkZXItcmFkaXVzOiA4cHg7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICBtYXJnaW46IGF1dG87XG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNmZmY7XG4gICAgICAgIG1hcmdpbi1yaWdodDogMTJweDtcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDEycHg7XG4gICAgICAgIG1hcmdpbi10b3A6IDNweDsgIFxuICAgICAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuXG4gICAgfVxufVxuIiwiLm1lbnVfYnRuIHtcbiAgY29sb3I6ICNFNDMyMkU7XG59XG5cbi5tYWluLXRpdGxlIHtcbiAgY29sb3I6ICNFNDMyMkU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cblxuLm1haW4tY2FyZCB7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG59XG5cbi5wLWxhYmVsMiB7XG4gIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG4gIG1hcmdpbi10b3A6IDBweDtcbiAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIGNvbG9yOiAjMDAwO1xuICBmb250LXNpemU6IDE2cHg7XG59XG5cbi5wLWxhYmVsIHtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgbWFyZ2luLXRvcDogMHB4O1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbiAgY29sb3I6ICMwMDA7XG4gIGZsb2F0OiByaWdodDtcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG4ucC1wcmljZSB7XG4gIGZvbnQtc2l6ZTogMjJweDtcbiAgbWFyZ2luLXRvcDogMHB4O1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gIGNvbG9yOiAjMDAwO1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuXG4ucC1kYXRlIHtcbiAgbWFyZ2luLXRvcDogMHB4O1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbiAgY29sb3I6ICMwMDA7XG4gIGZsb2F0OiByaWdodDtcbiAgZm9udC1zaXplOiAyMnB4O1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuXG4ucC1xdHkge1xuICBjb2xvcjogIzAwMDtcbiAgbWFyZ2luOiAwO1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG4uY3VzdC1wcm9maWxlIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbn1cblxuLnAtbGFiZWwtbm0ge1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICBtYXJnaW4tdG9wOiAwcHg7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICBjb2xvcjogIzAwMDtcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG4ucHJvZmlsZS10eHQge1xuICBmb250LXNpemU6IDE4cHg7XG4gIGNvbG9yOiAjMDAwO1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cblxuLmFkZC10eHQge1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cblxuLmltZyB7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cblxuLnAtbGFiZWwzIHtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIGNvbG9yOiAjMDAwO1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICBmb250LXNpemU6IDE4cHg7XG59XG5cbi5wLWxhYmVsNCB7XG4gIG1hcmdpbi10b3A6IDBweDtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIGNvbG9yOiAjMDAwO1xuICBmbG9hdDogcmlnaHQ7XG4gIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG4gIGZvbnQtc2l6ZTogMThweDtcbn1cblxuLnAtcXR5MSB7XG4gIGNvbG9yOiAjMDAwO1xuICBtYXJnaW46IDA7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBtYXJnaW4tdG9wOiAxNHB4O1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICBmb250LXNpemU6IDE4cHg7XG59XG5cbi5tYWluLWNhcmQtaXRlbSB7XG4gIG1hcmdpbi10b3A6IC03cHg7XG4gIGhlaWdodDogMzAlO1xufVxuLm1haW4tY2FyZC1pdGVtIGlvbi1jYXJkLWNvbnRlbnQge1xuICBwYWRkaW5nOiAwO1xuICBtYXgtaGVpZ2h0OiBjYWxjKDEyNSUgLSA1MHB4KTtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBvdmVyZmxvdy15OiBhdXRvO1xufVxuLm1haW4tY2FyZC1pdGVtIGlvbi1jYXJkLWNvbnRlbnQgOjotd2Via2l0LXNjcm9sbGJhciB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5cbi5jYW5jZWxfY29tcGxldGVkX2J0biB7XG4gIG1hcmdpbi10b3A6IDEyJTtcbiAgbWFyZ2luLWJvdHRvbTogOHB4O1xufVxuLmNhbmNlbF9jb21wbGV0ZWRfYnRuIC5jYW5jZWxPcmRlcl9idG4ge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTQzMjJFO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBoZWlnaHQ6IDQwcHg7XG4gIHdpZHRoOiA5MCU7XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbjogYXV0bztcbiAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbiAgbWFyZ2luLXJpZ2h0OiAxMnB4O1xuICBtYXJnaW4tbGVmdDogNnB4O1xuICBtYXJnaW4tdG9wOiAzcHg7XG4gIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG59XG4uY2FuY2VsX2NvbXBsZXRlZF9idG4gLmNvbXBsZXRlZF9idG4ge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTQzMjJFO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBoZWlnaHQ6IDQwcHg7XG4gIHdpZHRoOiA5MCU7XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbjogYXV0bztcbiAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbiAgbWFyZ2luLXJpZ2h0OiAxMnB4O1xuICBtYXJnaW4tbGVmdDogMTJweDtcbiAgbWFyZ2luLXRvcDogM3B4O1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/order-details/order-details.page.ts":
  /*!*****************************************************!*\
    !*** ./src/app/order-details/order-details.page.ts ***!
    \*****************************************************/

  /*! exports provided: OrderDetailsPage */

  /***/
  function srcAppOrderDetailsOrderDetailsPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OrderDetailsPage", function () {
      return OrderDetailsPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../auth.service */
    "./src/app/auth.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _common_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../common.service */
    "./src/app/common.service.ts");

    var OrderDetailsPage = /*#__PURE__*/function () {
      function OrderDetailsPage(commonService, router, datePipe, auth, location, navCtrl) {
        _classCallCheck(this, OrderDetailsPage);

        this.commonService = commonService;
        this.router = router;
        this.datePipe = datePipe;
        this.auth = auth;
        this.location = location;
        this.navCtrl = navCtrl;
        this.ordersDetails = [];
        this.orderItem = [];
        this.ordersList = [];
        var state = this.router.getCurrentNavigation().extras.state;

        if (state) {
          this.id = state;
          console.log("order id-->", this.id);
        }

        this.user_id = localStorage.getItem("id");
        console.log(this.user_id);
        this.role = localStorage.getItem("role");
      }

      _createClass(OrderDetailsPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.getOrderDetails(); //this.fnGetCustomerDetails();

          this.url = this.commonService.url();
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.location.back();
        }
      }, {
        key: "fnCancelOrder",
        value: function fnCancelOrder(id, order_number, cancel_by) {
          // alert(cancel_by);
          var params = {
            id: id,
            order_number: order_number,
            cancel_by: cancel_by
          };
          console.log(params);
          this.navCtrl.navigateForward('cancel-order', {
            state: params
          });
        }
      }, {
        key: "getOrderDetails",
        value: function getOrderDetails() {
          var _this = this;

          this.requestObject = {
            "order_id": this.id
          };
          console.log(this.requestObject);
          this.auth.showLoader();
          this.auth.getOrderDetails(this.requestObject).subscribe(function (data) {
            console.log(data);

            _this.auth.hideLoader();

            _this.dataResponse = data.data;
            _this.ordersDetails = _this.dataResponse;
            _this.date = _this.dataResponse.create_at;
            _this.orderDate = _this.datePipe.transform(new Date(_this.date), "dd/MM/yyyy");
            console.log("order data-->", _this.ordersDetails);
            _this.orderItem = _this.dataResponse.order_item;
            console.log("order item data-->", _this.orderDate);
          }, function (err) {
            console.log("Error=>", err); //this.auth.showError(err.error.message);

            _this.auth.hideLoader();
          });
        }
      }, {
        key: "fnCompleted",
        value: function fnCompleted(status) {
          var _this2 = this;

          console.log(status);
          this.requestObject = {
            "order_id": this.id,
            "order_status": status,
            "user_id": this.user_id,
            "user_type": this.role
          };
          this.auth.showLoader();
          console.log(this.requestObject);
          this.auth.updateOrderStatus(this.requestObject).subscribe(function (data) {
            console.log(data);

            _this2.auth.hideLoader();

            _this2.auth.showToast('Order status updated succesfully');

            _this2.navCtrl.navigateForward('my-account');
          }, function (err) {
            console.log("Error=>", err);

            _this2.auth.hideLoader();
          });
        }
      }]);

      return OrderDetailsPage;
    }();

    OrderDetailsPage.ctorParameters = function () {
      return [{
        type: _common_service__WEBPACK_IMPORTED_MODULE_6__["CommonService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
      }, {
        type: _angular_common__WEBPACK_IMPORTED_MODULE_3__["DatePipe"]
      }, {
        type: _auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]
      }, {
        type: _angular_common__WEBPACK_IMPORTED_MODULE_3__["Location"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }];
    };

    OrderDetailsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-order-details',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./order-details.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/order-details/order-details.page.html"))["default"],
      providers: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["DatePipe"]],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./order-details.page.scss */
      "./src/app/order-details/order-details.page.scss"))["default"]]
    })], OrderDetailsPage);
    /***/
  }
}]);
//# sourceMappingURL=order-details-order-details-module-es5.js.map