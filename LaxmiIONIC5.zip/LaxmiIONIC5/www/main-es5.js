function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
  /***/
  "./$$_lazy_route_resource lazy recursive":
  /*!******************************************************!*\
    !*** ./$$_lazy_route_resource lazy namespace object ***!
    \******************************************************/

  /*! no static exports found */

  /***/
  function $$_lazy_route_resourceLazyRecursive(module, exports) {
    function webpackEmptyAsyncContext(req) {
      // Here Promise.resolve().then() is used instead of new Promise() to prevent
      // uncaught exception popping up in devtools
      return Promise.resolve().then(function () {
        var e = new Error("Cannot find module '" + req + "'");
        e.code = 'MODULE_NOT_FOUND';
        throw e;
      });
    }

    webpackEmptyAsyncContext.keys = function () {
      return [];
    };

    webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
    module.exports = webpackEmptyAsyncContext;
    webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";
    /***/
  },

  /***/
  "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
  /*!*****************************************************************************************************************************************!*\
    !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
    \*****************************************************************************************************************************************/

  /*! no static exports found */

  /***/
  function node_modulesIonicCoreDistEsmLazyRecursiveEntryJs$IncludeEntryJs$ExcludeSystemEntryJs$(module, exports, __webpack_require__) {
    var map = {
      "./ion-action-sheet-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-action-sheet-ios.entry.js", "common", 0],
      "./ion-action-sheet-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-action-sheet-md.entry.js", "common", 1],
      "./ion-alert-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-alert-ios.entry.js", "common", 2],
      "./ion-alert-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-alert-md.entry.js", "common", 3],
      "./ion-app_8-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-app_8-ios.entry.js", "common", 4],
      "./ion-app_8-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-app_8-md.entry.js", "common", 5],
      "./ion-avatar_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-avatar_3-ios.entry.js", "common", 6],
      "./ion-avatar_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-avatar_3-md.entry.js", "common", 7],
      "./ion-back-button-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-back-button-ios.entry.js", "common", 8],
      "./ion-back-button-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-back-button-md.entry.js", "common", 9],
      "./ion-backdrop-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-backdrop-ios.entry.js", 10],
      "./ion-backdrop-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-backdrop-md.entry.js", 11],
      "./ion-button_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-button_2-ios.entry.js", "common", 12],
      "./ion-button_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-button_2-md.entry.js", "common", 13],
      "./ion-card_5-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-card_5-ios.entry.js", "common", 14],
      "./ion-card_5-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-card_5-md.entry.js", "common", 15],
      "./ion-checkbox-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-checkbox-ios.entry.js", "common", 16],
      "./ion-checkbox-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-checkbox-md.entry.js", "common", 17],
      "./ion-chip-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-chip-ios.entry.js", "common", 18],
      "./ion-chip-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-chip-md.entry.js", "common", 19],
      "./ion-col_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-col_3.entry.js", 20],
      "./ion-datetime_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-datetime_3-ios.entry.js", "common", 21],
      "./ion-datetime_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-datetime_3-md.entry.js", "common", 22],
      "./ion-fab_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-fab_3-ios.entry.js", "common", 23],
      "./ion-fab_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-fab_3-md.entry.js", "common", 24],
      "./ion-img.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-img.entry.js", 25],
      "./ion-infinite-scroll_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2-ios.entry.js", 26],
      "./ion-infinite-scroll_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2-md.entry.js", 27],
      "./ion-input-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-input-ios.entry.js", "common", 28],
      "./ion-input-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-input-md.entry.js", "common", 29],
      "./ion-item-option_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item-option_3-ios.entry.js", "common", 30],
      "./ion-item-option_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item-option_3-md.entry.js", "common", 31],
      "./ion-item_8-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item_8-ios.entry.js", "common", 32],
      "./ion-item_8-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item_8-md.entry.js", "common", 33],
      "./ion-loading-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-loading-ios.entry.js", "common", 34],
      "./ion-loading-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-loading-md.entry.js", "common", 35],
      "./ion-menu_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-menu_3-ios.entry.js", "common", 36],
      "./ion-menu_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-menu_3-md.entry.js", "common", 37],
      "./ion-modal-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-modal-ios.entry.js", "common", 38],
      "./ion-modal-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-modal-md.entry.js", "common", 39],
      "./ion-nav_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-nav_2.entry.js", "common", 40],
      "./ion-popover-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-popover-ios.entry.js", "common", 41],
      "./ion-popover-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-popover-md.entry.js", "common", 42],
      "./ion-progress-bar-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-progress-bar-ios.entry.js", "common", 43],
      "./ion-progress-bar-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-progress-bar-md.entry.js", "common", 44],
      "./ion-radio_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-radio_2-ios.entry.js", "common", 45],
      "./ion-radio_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-radio_2-md.entry.js", "common", 46],
      "./ion-range-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-range-ios.entry.js", "common", 47],
      "./ion-range-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-range-md.entry.js", "common", 48],
      "./ion-refresher_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-refresher_2-ios.entry.js", "common", 49],
      "./ion-refresher_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-refresher_2-md.entry.js", "common", 50],
      "./ion-reorder_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-reorder_2-ios.entry.js", "common", 51],
      "./ion-reorder_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-reorder_2-md.entry.js", "common", 52],
      "./ion-ripple-effect.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-ripple-effect.entry.js", 53],
      "./ion-route_4.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-route_4.entry.js", "common", 54],
      "./ion-searchbar-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-searchbar-ios.entry.js", "common", 55],
      "./ion-searchbar-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-searchbar-md.entry.js", "common", 56],
      "./ion-segment_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-segment_2-ios.entry.js", "common", 57],
      "./ion-segment_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-segment_2-md.entry.js", "common", 58],
      "./ion-select_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-select_3-ios.entry.js", "common", 59],
      "./ion-select_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-select_3-md.entry.js", "common", 60],
      "./ion-slide_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-slide_2-ios.entry.js", 61],
      "./ion-slide_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-slide_2-md.entry.js", 62],
      "./ion-spinner.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-spinner.entry.js", "common", 63],
      "./ion-split-pane-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-split-pane-ios.entry.js", 64],
      "./ion-split-pane-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-split-pane-md.entry.js", 65],
      "./ion-tab-bar_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab-bar_2-ios.entry.js", "common", 66],
      "./ion-tab-bar_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab-bar_2-md.entry.js", "common", 67],
      "./ion-tab_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab_2.entry.js", "common", 68],
      "./ion-text.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-text.entry.js", "common", 69],
      "./ion-textarea-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-textarea-ios.entry.js", "common", 70],
      "./ion-textarea-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-textarea-md.entry.js", "common", 71],
      "./ion-toast-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toast-ios.entry.js", "common", 72],
      "./ion-toast-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toast-md.entry.js", "common", 73],
      "./ion-toggle-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toggle-ios.entry.js", "common", 74],
      "./ion-toggle-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toggle-md.entry.js", "common", 75],
      "./ion-virtual-scroll.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-virtual-scroll.entry.js", 76]
    };

    function webpackAsyncContext(req) {
      if (!__webpack_require__.o(map, req)) {
        return Promise.resolve().then(function () {
          var e = new Error("Cannot find module '" + req + "'");
          e.code = 'MODULE_NOT_FOUND';
          throw e;
        });
      }

      var ids = map[req],
          id = ids[0];
      return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function () {
        return __webpack_require__(id);
      });
    }

    webpackAsyncContext.keys = function webpackAsyncContextKeys() {
      return Object.keys(map);
    };

    webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
    module.exports = webpackAsyncContext;
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
  /*!**************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
    \**************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAppComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-app>\n  <ion-menu side=\"start\" menuId=\"first\" contentId=\"content1\">\n    <ion-header>\n      <ion-toolbar>\n        <ion-grid class=\"drwawerCard\">\n          <ion-row class=\"center\">\n            <ion-col size=\"4\">\n              <div class=\"user_avatar\">\n                <img *ngIf=\"!photo\" src=\"../assets/imgs/avatar1.png\">\n                <img *ngIf=\"photo\" [src]=\"photo\">\n              </div>\n            </ion-col>\n            <ion-col size=\"8\">\n              <h5 ion-text class=\"cardColor twoLinesText textCap\">\n                {{name}}\n              </h5>\n              <span class=\"cardColor fontSizeRole\" *ngIf=\"role == 'Customer'\">Customer</span>\n              <span class=\"cardColor fontSizeRole\" *ngIf=\"role == 'DeliveryBoy'\">Staff</span>\n              <span class=\"cardColor fontSizeRole\" *ngIf=\"role == 'Salesman'\">Sales Man</span>\n              <br>\n              <span class=\"cardColor fontSizeEmail\">{{email}}</span>\n            </ion-col>\n          </ion-row>\n\n        </ion-grid>\n      </ion-toolbar>\n    </ion-header>\n    <ion-content>\n      <ion-item class=\"main-title\" (click)=\"fnDashboard()\"><img src=\"../assets/imgs/home-run.png\" height=\"20\" width=\"20\"\n          class=\"img\">Home\n      </ion-item>\n\n      <ion-item class=\"main-title\" (click)=\"fnEditProfile()\"><img src=\"../assets/imgs/person.png\" height=\"23\" width=\"23\"\n          class=\"img\">Edit\n        Profile</ion-item>\n      <ion-item class=\"main-title\" (click)=\"fnMyAddress()\" *ngIf=\"role == 'Customer'\"><img\n          src=\"../assets/imgs/location.png\" height=\"23\" width=\"23\" class=\"img\">My\n        Address</ion-item>\n\n      <ion-item class=\"main-title\" (click)=\"fnChangePassword()\"><img src=\"../assets/imgs/password.svg\" height=\"23\"\n          width=\"23\" class=\"img\">Change\n        Password</ion-item>\n\n      <ion-item class=\"main-title\" (click)=\"fnComplain()\" *ngIf=\"role == 'Customer'\"><img src=\"../assets/imgs/complain.png\" height=\"23\"\n          width=\"23\" class=\"img\">Complaint\n       </ion-item>\n\n      <!-- <ion-item *ngIf=\"role == 'Customer'\" class=\"main-title\" (click)=\"fnMyOrders()\"><img src=\"../assets/imgs/order (3).png\" class=\"img\">My\n        Orders</ion-item> -->\n\n      <ion-item class=\"main-title\" (click)=\"presentAlertConfirm()\"><img src=\"../assets/imgs/logout.png\" height=\"23\"\n          width=\"23\" class=\"img\">Logout\n      </ion-item>\n\n      <!-- <div *ngIf=\"role == 'Customer'\">\n        <ion-item class=\"main-title\" (click)=\"fnDashboard()\"><img src=\"../assets/imgs/home-run.png\" class=\"img\">Home\n        </ion-item>\n        <ion-item class=\"main-title\" (click)=\"fnEditProfile()\"><img src=\"../assets/imgs/person.png\" class=\"img\">Edit\n          Profile</ion-item>\n        <ion-item class=\"main-title\" (click)=\"fnChangePassword()\"><img src=\"../assets/imgs/gear.png\" class=\"img\">Change\n          Password</ion-item>\n        <ion-item class=\"main-title\" (click)=\"fnMyOrders()\"><img src=\"../assets/imgs/order (3).png\" class=\"img\">My\n          Orders</ion-item>\n        <ion-item class=\"main-title\" (click)=\"fnLogout()\"><img src=\"../assets/imgs/logout.png\" class=\"img\">Logout\n        </ion-item>\n      </div>\n\n      <div *ngIf=\"role == 'DeliveryBoy'\">\n        <ion-item class=\"main-title\" (click)=\"fnMyAccount()\"><img src=\"../assets/imgs/home-run.png\" class=\"img\">Home\n        </ion-item>\n        <ion-item class=\"main-title\" (click)=\"fnEditProfile()\"><img src=\"../assets/imgs/person.png\" class=\"img\">Edit\n          Profile</ion-item>\n        <ion-item class=\"main-title\" (click)=\"fnChangePassword()\"><img src=\"../assets/imgs/gear.png\" class=\"img\">Change\n          Password</ion-item>\n        <ion-item class=\"main-title\" (click)=\"fnLogout()\"><img src=\"../assets/imgs/logout.png\" class=\"img\">Logout\n        </ion-item>\n      </div> -->\n\n      <!-- <ion-list *ngIf=\"role == 'Customer'\">\n        <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let page of pages\">\n          <ion-item class=\"main-title\" [routerLink]=\"page.path\" routerDirection=\"root\" [class.active-menu]=\"activePath === page.path\">\n            {{page.name}}\n          </ion-item>\n        </ion-menu-toggle>\n      </ion-list>\n\n      <ion-list *ngIf=\"role == 'DeliveryBoy'\">\n        <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let page of pagess\">\n          <ion-item class=\"main-title\" [routerLink]=\"page.path\" routerDirection=\"root\" [class.active-menu]=\"activePath === page.path\">\n            {{page.name}}\n          </ion-item>\n        </ion-menu-toggle>\n      </ion-list> -->\n\n    </ion-content>\n  </ion-menu>\n  <ion-router-outlet id=\"content1\"></ion-router-outlet>\n</ion-app>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/modal-popup/modal-popup.page.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/modal-popup/modal-popup.page.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppModalPopupModalPopupPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content ion-fixed>\n\n  <ion-grid>\n    <ion-row class=\"btnCloseContainer\">\n      <ion-buttons class=\"close_btn\">\n        <ion-icon name=\"close-outline\" (click)=\"closeModal()\"></ion-icon>\n      </ion-buttons>\n    </ion-row>\n    <ion-row class=\"center\">\n      <ion-col *ngIf=\"name.images\" size=\"12\">\n        <ion-slides pager=\"true\" [options]=\"slideOpts\" #slideWithNav>\n          <ion-slide *ngFor=\"let item of name.images\">\n            <img *ngIf=\"name.images.length != 0\"\n              src=\"{{url.file_url}}assets/uploads/products/thumbs/{{item.product_image}}\" class=\"img_slide\">\n\n          </ion-slide> \n          <ion-slide *ngIf=\"name.images.length == 0\">\n            <img src=\"../../assets/imgs/not_found.png\" class=\"img_slide\">\n          </ion-slide>\n       \n        </ion-slides>\n        <p class=\"slide-text\">{{name.product_name}} {{name.product_weight}}Kg </p>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <ion-grid class=\"card-width\">\n    <ion-row class=\"left center\">\n      <ion-col size=\"8\">\n        <span class=\"slide-price\">\n          {{name.product_weight}}Kg x {{item_qty}} qty\n          <!-- <span style=\"color: gray;font-size: 1rem;\">₹{{name.product_price * item_qty}}</span> -->\n        </span>\n      </ion-col>\n      <ion-col size=\"4\">\n        <div class=\"add-rm-btn center\">\n          <ion-icon name=\"remove-circle\" (click)=\"fnremove()\" class=\"add-remove-circle\"></ion-icon>\n            <div style=\"padding: 0 10px;font-size: 1.4rem;\">{{item_qty}}</div>\n          <ion-icon name=\"add-circle\" (click)=\"fnadd()\" class=\"add-remove-circle\"></ion-icon>\n        </div>\n      </ion-col>\n    </ion-row>\n\n    <ion-row class=\"left\">\n      <ion-col size=\"12\">\n        <span class=\"slide-price\"><b>Total Amount ₹{{(name.product_price*item_qty).toFixed(2)}}</b></span>\n      </ion-col>\n    </ion-row>\n\n    <!-- <ion-row *ngIf=\"name.product_description!=''\">\n      <ion-label class=\"Description\"><b>Product Description</b></ion-label>\n    </ion-row> -->\n    <!-- <ion-row *ngIf=\"name.product_description!=''\">\n      <p class=\"product\">{{name.product_description}}</p>\n    </ion-row> -->\n  </ion-grid>\n\n  <button ion-button class=\"AddToCart_btn\"\n    (click)=\"fnAddToCart(name.id,name.product_name,name.product_weight,name.product_price,item_qty,name.images)\">Add To Cart</button>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/app-routing.module.ts":
  /*!***************************************!*\
    !*** ./src/app/app-routing.module.ts ***!
    \***************************************/

  /*! exports provided: AppRoutingModule */

  /***/
  function srcAppAppRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
      return AppRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

    var routes = [{
      path: 'home',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | home-home-module */
        "home-home-module").then(__webpack_require__.bind(null,
        /*! ./home/home.module */
        "./src/app/home/home.module.ts")).then(function (m) {
          return m.HomePageModule;
        });
      }
    }, {
      path: '',
      redirectTo: 'home',
      pathMatch: 'full'
    }, {
      path: 'register',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | register-register-module */
        "register-register-module").then(__webpack_require__.bind(null,
        /*! ./register/register.module */
        "./src/app/register/register.module.ts")).then(function (m) {
          return m.RegisterPageModule;
        });
      }
    }, {
      path: 'dashboard',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | dashboard-dashboard-module */
        "dashboard-dashboard-module").then(__webpack_require__.bind(null,
        /*! ./dashboard/dashboard.module */
        "./src/app/dashboard/dashboard.module.ts")).then(function (m) {
          return m.DashboardPageModule;
        });
      }
    }, {
      path: 'product-list',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | product-list-product-list-module */
        "product-list-product-list-module").then(__webpack_require__.bind(null,
        /*! ./product-list/product-list.module */
        "./src/app/product-list/product-list.module.ts")).then(function (m) {
          return m.ProductListPageModule;
        });
      }
    }, {
      path: 'modal-popup',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | modal-popup-modal-popup-module */
        "modal-popup-modal-popup-module").then(__webpack_require__.bind(null,
        /*! ./modal-popup/modal-popup.module */
        "./src/app/modal-popup/modal-popup.module.ts")).then(function (m) {
          return m.ModalPopupPageModule;
        });
      }
    }, {
      path: 'your-cart',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | your-cart-your-cart-module */
        "your-cart-your-cart-module").then(__webpack_require__.bind(null,
        /*! ./your-cart/your-cart.module */
        "./src/app/your-cart/your-cart.module.ts")).then(function (m) {
          return m.YourCartPageModule;
        });
      }
    }, {
      path: 'select-address',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | select-address-select-address-module */
        "select-address-select-address-module").then(__webpack_require__.bind(null,
        /*! ./select-address/select-address.module */
        "./src/app/select-address/select-address.module.ts")).then(function (m) {
          return m.SelectAddressPageModule;
        });
      }
    }, {
      path: 'add-address',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | add-address-add-address-module */
        "add-address-add-address-module").then(__webpack_require__.bind(null,
        /*! ./add-address/add-address.module */
        "./src/app/add-address/add-address.module.ts")).then(function (m) {
          return m.AddAddressPageModule;
        });
      }
    }, {
      path: 'success-order',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | success-order-success-order-module */
        "success-order-success-order-module").then(__webpack_require__.bind(null,
        /*! ./success-order/success-order.module */
        "./src/app/success-order/success-order.module.ts")).then(function (m) {
          return m.SuccessOrderPageModule;
        });
      }
    }, {
      path: 'customer-orders',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | customer-orders-customer-orders-module */
        "customer-orders-customer-orders-module").then(__webpack_require__.bind(null,
        /*! ./customer-orders/customer-orders.module */
        "./src/app/customer-orders/customer-orders.module.ts")).then(function (m) {
          return m.CustomerOrdersPageModule;
        });
      }
    }, {
      path: 'order-summary',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | order-summary-order-summary-module */
        "order-summary-order-summary-module").then(__webpack_require__.bind(null,
        /*! ./order-summary/order-summary.module */
        "./src/app/order-summary/order-summary.module.ts")).then(function (m) {
          return m.OrderSummaryPageModule;
        });
      }
    }, {
      path: 'cancel-order',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | cancel-order-cancel-order-module */
        "cancel-order-cancel-order-module").then(__webpack_require__.bind(null,
        /*! ./cancel-order/cancel-order.module */
        "./src/app/cancel-order/cancel-order.module.ts")).then(function (m) {
          return m.CancelOrderPageModule;
        });
      }
    }, {
      path: 'forgot-password',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | forgot-password-forgot-password-module */
        "forgot-password-forgot-password-module").then(__webpack_require__.bind(null,
        /*! ./forgot-password/forgot-password.module */
        "./src/app/forgot-password/forgot-password.module.ts")).then(function (m) {
          return m.ForgotPasswordPageModule;
        });
      }
    }, {
      path: 'my-account',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | my-account-my-account-module */
        "my-account-my-account-module").then(__webpack_require__.bind(null,
        /*! ./my-account/my-account.module */
        "./src/app/my-account/my-account.module.ts")).then(function (m) {
          return m.MyAccountPageModule;
        });
      }
    }, {
      path: 'edit-profile',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | edit-profile-edit-profile-module */
        "edit-profile-edit-profile-module").then(__webpack_require__.bind(null,
        /*! ./edit-profile/edit-profile.module */
        "./src/app/edit-profile/edit-profile.module.ts")).then(function (m) {
          return m.EditProfilePageModule;
        });
      }
    }, {
      path: 'order-details',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | order-details-order-details-module */
        "order-details-order-details-module").then(__webpack_require__.bind(null,
        /*! ./order-details/order-details.module */
        "./src/app/order-details/order-details.module.ts")).then(function (m) {
          return m.OrderDetailsPageModule;
        });
      }
    }, {
      path: 'change-password',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | change-password-change-password-module */
        "change-password-change-password-module").then(__webpack_require__.bind(null,
        /*! ./change-password/change-password.module */
        "./src/app/change-password/change-password.module.ts")).then(function (m) {
          return m.ChangePasswordPageModule;
        });
      }
    }, {
      path: 'otp',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | otp-otp-module */
        "otp-otp-module").then(__webpack_require__.bind(null,
        /*! ./otp/otp.module */
        "./src/app/otp/otp.module.ts")).then(function (m) {
          return m.OtpPageModule;
        });
      }
    }, {
      path: 'update-password',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | update-password-update-password-module */
        "update-password-update-password-module").then(__webpack_require__.bind(null,
        /*! ./update-password/update-password.module */
        "./src/app/update-password/update-password.module.ts")).then(function (m) {
          return m.UpdatePasswordPageModule;
        });
      }
    }, {
      path: 'edit-address',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | edit-address-edit-address-module */
        "edit-address-edit-address-module").then(__webpack_require__.bind(null,
        /*! ./edit-address/edit-address.module */
        "./src/app/edit-address/edit-address.module.ts")).then(function (m) {
          return m.EditAddressPageModule;
        });
      }
    }, {
      path: 'summary',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | summary-summary-module */
        "summary-summary-module").then(__webpack_require__.bind(null,
        /*! ./summary/summary.module */
        "./src/app/summary/summary.module.ts")).then(function (m) {
          return m.SummaryPageModule;
        });
      }
    }, {
      path: 'my-address',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | my-address-my-address-module */
        "my-address-my-address-module").then(__webpack_require__.bind(null,
        /*! ./my-address/my-address.module */
        "./src/app/my-address/my-address.module.ts")).then(function (m) {
          return m.MyAddressPageModule;
        });
      }
    }, {
      path: 'sales-dashboard',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | sales-dashboard-sales-dashboard-module */
        "sales-dashboard-sales-dashboard-module").then(__webpack_require__.bind(null,
        /*! ./sales-dashboard/sales-dashboard.module */
        "./src/app/sales-dashboard/sales-dashboard.module.ts")).then(function (m) {
          return m.SalesDashboardPageModule;
        });
      }
    }, {
      path: 'sales-order-details',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | sales-order-details-sales-order-details-module */
        "sales-order-details-sales-order-details-module").then(__webpack_require__.bind(null,
        /*! ./sales-order-details/sales-order-details.module */
        "./src/app/sales-order-details/sales-order-details.module.ts")).then(function (m) {
          return m.SalesOrderDetailsPageModule;
        });
      }
    }, {
      path: 'complain-order',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | complain-order-complain-order-module */
        "complain-order-complain-order-module").then(__webpack_require__.bind(null,
        /*! ./complain-order/complain-order.module */
        "./src/app/complain-order/complain-order.module.ts")).then(function (m) {
          return m.ComplainOrderPageModule;
        });
      }
    }];

    var AppRoutingModule = function AppRoutingModule() {
      _classCallCheck(this, AppRoutingModule);
    };

    AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, {
        preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"]
      })],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], AppRoutingModule);
    /***/
  },

  /***/
  "./src/app/app.component.scss":
  /*!************************************!*\
    !*** ./src/app/app.component.scss ***!
    \************************************/

  /*! exports provided: default */

  /***/
  function srcAppAppComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".img {\n  margin-right: 10px;\n}\n\n.user_list {\n  padding-top: 10px;\n}\n\n.sidebar_text {\n  padding-left: 26px;\n  font-size: 20px;\n}\n\n.content_bg {\n  background-color: transparent;\n}\n\n.content_text {\n  color: #e4322e;\n  font-size: 28px;\n  font-weight: 500;\n  text-transform: capitalize;\n}\n\n.sidebar_icon {\n  color: #e4322e;\n  font-size: 28px;\n  margin-right: 0;\n  margin-top: 10px;\n}\n\n.user_profile {\n  background-color: transparent !important;\n}\n\n.user_avatar {\n  display: inline-block;\n}\n\n.user_avatar img {\n  width: 80px;\n  height: 80px;\n  border-radius: 50%;\n  border: 2px solid #fff;\n}\n\n.drwawerCard {\n  width: auto;\n  height: 8rem !important;\n  background-color: #e4322e;\n}\n\n.center {\n  height: 100%;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.cardColor {\n  color: #fff;\n}\n\n.fontSizeRole {\n  font-size: 14px;\n}\n\n.fontSizeEmail {\n  font-size: 12px;\n  color: lightgrey;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9hcHAuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFBO0FDQ0Y7O0FERUE7RUFDRSxpQkFBQTtBQ0NGOztBRENBO0VBQ0Usa0JBQUE7RUFDQSxlQUFBO0FDRUY7O0FEQ0E7RUFDRSw2QkFBQTtBQ0VGOztBREFBO0VBQ0UsY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLDBCQUFBO0FDR0Y7O0FEREE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQ0lGOztBREZBO0VBQ0Usd0NBQUE7QUNLRjs7QURIQTtFQUNFLHFCQUFBO0FDTUY7O0FESkE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7QUNPRjs7QURMQTtFQUNFLFdBQUE7RUFDQSx1QkFBQTtFQUVBLHlCQUFBO0FDT0Y7O0FETEE7RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUNRRjs7QUROQTtFQUNFLFdBQUE7QUNTRjs7QURQQTtFQUNFLGVBQUE7QUNVRjs7QURSQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtBQ1dGIiwiZmlsZSI6InNyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmltZyB7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cblxuLnVzZXJfbGlzdCB7XG4gIHBhZGRpbmctdG9wOiAxMHB4O1xufVxuLnNpZGViYXJfdGV4dCB7XG4gIHBhZGRpbmctbGVmdDogMjZweDtcbiAgZm9udC1zaXplOiAyMHB4O1xufVxuXG4uY29udGVudF9iZyB7XG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xufVxuLmNvbnRlbnRfdGV4dCB7XG4gIGNvbG9yOiAjZTQzMjJlO1xuICBmb250LXNpemU6IDI4cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xufVxuLnNpZGViYXJfaWNvbiB7XG4gIGNvbG9yOiAjZTQzMjJlO1xuICBmb250LXNpemU6IDI4cHg7XG4gIG1hcmdpbi1yaWdodDogMDtcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cbi51c2VyX3Byb2ZpbGUge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xufVxuLnVzZXJfYXZhdGFyIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xufVxuLnVzZXJfYXZhdGFyIGltZyB7XG4gIHdpZHRoOiA4MHB4O1xuICBoZWlnaHQ6IDgwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgYm9yZGVyOiAycHggc29saWQgI2ZmZjtcbn1cbi5kcndhd2VyQ2FyZCB7XG4gIHdpZHRoOiBhdXRvO1xuICBoZWlnaHQ6IDhyZW0gIWltcG9ydGFudDtcbiAgLy8gYmFja2dyb3VuZDogdXJsKC4uL2Fzc2V0cy9pbWdzL2RyYXdlcmJhY2suanBnKTtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2U0MzIyZTtcbn1cbi5jZW50ZXIge1xuICBoZWlnaHQ6IDEwMCU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLmNhcmRDb2xvciB7XG4gIGNvbG9yOiAjZmZmO1xufVxuLmZvbnRTaXplUm9sZXtcbiAgZm9udC1zaXplOjE0cHg7XG59XG4uZm9udFNpemVFbWFpbHtcbiAgZm9udC1zaXplOjEycHg7XG4gIGNvbG9yOiBsaWdodGdyZXk7XG59XG4iLCIuaW1nIHtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuXG4udXNlcl9saXN0IHtcbiAgcGFkZGluZy10b3A6IDEwcHg7XG59XG5cbi5zaWRlYmFyX3RleHQge1xuICBwYWRkaW5nLWxlZnQ6IDI2cHg7XG4gIGZvbnQtc2l6ZTogMjBweDtcbn1cblxuLmNvbnRlbnRfYmcge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbn1cblxuLmNvbnRlbnRfdGV4dCB7XG4gIGNvbG9yOiAjZTQzMjJlO1xuICBmb250LXNpemU6IDI4cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xufVxuXG4uc2lkZWJhcl9pY29uIHtcbiAgY29sb3I6ICNlNDMyMmU7XG4gIGZvbnQtc2l6ZTogMjhweDtcbiAgbWFyZ2luLXJpZ2h0OiAwO1xuICBtYXJnaW4tdG9wOiAxMHB4O1xufVxuXG4udXNlcl9wcm9maWxlIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbn1cblxuLnVzZXJfYXZhdGFyIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xufVxuXG4udXNlcl9hdmF0YXIgaW1nIHtcbiAgd2lkdGg6IDgwcHg7XG4gIGhlaWdodDogODBweDtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBib3JkZXI6IDJweCBzb2xpZCAjZmZmO1xufVxuXG4uZHJ3YXdlckNhcmQge1xuICB3aWR0aDogYXV0bztcbiAgaGVpZ2h0OiA4cmVtICFpbXBvcnRhbnQ7XG4gIGJhY2tncm91bmQtY29sb3I6ICNlNDMyMmU7XG59XG5cbi5jZW50ZXIge1xuICBoZWlnaHQ6IDEwMCU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4uY2FyZENvbG9yIHtcbiAgY29sb3I6ICNmZmY7XG59XG5cbi5mb250U2l6ZVJvbGUge1xuICBmb250LXNpemU6IDE0cHg7XG59XG5cbi5mb250U2l6ZUVtYWlsIHtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBjb2xvcjogbGlnaHRncmV5O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/app.component.ts":
  /*!**********************************!*\
    !*** ./src/app/app.component.ts ***!
    \**********************************/

  /*! exports provided: AppComponent */

  /***/
  function srcAppAppComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
      return AppComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic-native/splash-screen/ngx */
    "./node_modules/@ionic-native/splash-screen/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic-native/status-bar/ngx */
    "./node_modules/@ionic-native/status-bar/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _global_foo_service_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./global-foo-service.service */
    "./src/app/global-foo-service.service.ts");
    /* harmony import */


    var _ionic_native_push_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @ionic-native/push/ngx */
    "./node_modules/@ionic-native/push/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _auth_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./auth.service */
    "./src/app/auth.service.ts");

    var AppComponent = /*#__PURE__*/function () {
      function AppComponent(auth, push, globalFooService, changeDetectorRef, _location, platform, splashScreen, statusBar, menu, navCtrl, alertCtrl) {
        _classCallCheck(this, AppComponent);

        this.auth = auth;
        this.push = push;
        this.globalFooService = globalFooService;
        this.changeDetectorRef = changeDetectorRef;
        this._location = _location;
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.menu = menu;
        this.navCtrl = navCtrl;
        this.alertCtrl = alertCtrl;
        this.firm_name = localStorage.getItem('firm_name');
        this.name = localStorage.getItem('name');
        this.email = localStorage.getItem('email');
        this.role = localStorage.getItem("role");
        this.photo = localStorage.getItem("photos");

        if (localStorage.getItem("photos")) {
          this.photo = localStorage.getItem("photos");
        } else {
          this.photo = '';
        }

        console.log('this.photo  -- ', this.photo);
        this.initializeApp();
      }

      _createClass(AppComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "initializeApp",
        value: function initializeApp() {
          var _this = this;

          this.platform.ready().then(function () {
            _this.initPushNotification();

            _this.statusBar.styleDefault();

            _this.statusBar.backgroundColorByHexString('#ffffff');

            _this.splashScreen.hide();

            _this.user_id = localStorage.getItem("id");
            _this.firm_name = localStorage.getItem("firm_name");
            _this.name = localStorage.getItem("name");
            _this.email = localStorage.getItem("email");
            _this.role = localStorage.getItem("role");
            _this.photo = localStorage.getItem("photos");

            _this.globalFooService.getObservable().subscribe(function (data) {
              console.log('Data received', data);
              _this.name = data.name;
              _this.email = data.email;
              _this.role = data.role;
              _this.photo = data.photo;
              _this.rootPage = data.rootPage;
            });

            _this.platform.backButton.subscribeWithPriority(10, function (processNextHandler) {
              console.log('Back press handler!');
              Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();

              if (_this._location.isCurrentPathEqualTo(_this.rootPage)) {
                // Show Exit Alert!
                console.log('Show Exit Alert!');

                _this.showExitConfirm();

                processNextHandler();
              } else {
                // Navigate to back page
                console.log('Navigate to back page');

                _this._location.back();
              }
            });

            _this.platform.backButton.subscribeWithPriority(5, function () {
              console.log('Handler called to force close!');

              _this.alertCtrl.getTop().then(function (r) {
                if (r) {
                  navigator['app'].exitApp();
                }
              })["catch"](function (e) {
                console.log(e);
              });
            });

            console.log("this.role-----", _this.role);

            if (!_this.role && _this.role === null) {
              _this.rootPage = "/home"; // this.navCtrl.navigateRoot('home');
            } else {
              if (_this.role == 'Customer') {
                _this.rootPage = "/dashboard"; // this.navCtrl.navigateRoot('dashboard');
                // this.navCtrl.navigateForward('add-address');
              } else if (_this.role == 'DeliveryBoy') {
                _this.rootPage = "/my-account"; // this.navCtrl.navigateRoot('my-account'); 
              } else if (_this.role == 'Salesman') {
                _this.rootPage = "/sales-dashboard"; // this.navCtrl.navigateRoot('sales-dashboard');
              }
            }

            _this.navCtrl.navigateRoot(_this.rootPage);
          });
        }
      }, {
        key: "showExitConfirm",
        value: function showExitConfirm() {
          this.alertCtrl.create({
            header: 'App termination',
            message: 'Do you want to close the app?',
            backdropDismiss: false,
            buttons: [{
              text: 'Stay',
              role: 'cancel',
              handler: function handler() {
                console.log('Application exit prevented!');
              }
            }, {
              text: 'Exit',
              handler: function handler() {
                navigator['app'].exitApp();
              }
            }]
          }).then(function (alert) {
            alert.present();
          });
        }
      }, {
        key: "openCustom",
        value: function openCustom() {
          this.menu.enable(true, 'custom');
          this.menu.open('custom');
        }
      }, {
        key: "fnMyAccount",
        value: function fnMyAccount() {
          this.menu.enable(true);
          this.navCtrl.navigateForward('my-account');
          this.menu.enable(false);
        }
      }, {
        key: "fnEditProfile",
        value: function fnEditProfile() {
          this.menu.enable(true);
          this.navCtrl.navigateForward('edit-profile');
          this.menu.enable(false);
        }
      }, {
        key: "fnMyAddress",
        value: function fnMyAddress() {
          this.menu.enable(true);
          this.navCtrl.navigateForward('my-address');
          this.menu.enable(false);
        }
      }, {
        key: "fnChangePassword",
        value: function fnChangePassword() {
          this.menu.enable(true);
          this.navCtrl.navigateForward('change-password');
          this.menu.enable(false);
        }
      }, {
        key: "fnComplain",
        value: function fnComplain() {
          this.menu.enable(true);
          this.navCtrl.navigateForward('complain-order');
          this.menu.enable(false);
        }
      }, {
        key: "fnLogout",
        value: function fnLogout() {
          var _this2 = this;

          var requestObject = {
            "userId": this.user_id
          };
          this.auth.showLoader();
          this.auth.logout(requestObject).subscribe(function (data) {
            _this2.auth.hideLoader();

            if (data.status === true) {
              // this.auth.showToast(data.message);
              _this2.rootPage = "/home";
              localStorage.clear();

              _this2.menu.enable(true);

              _this2.navCtrl.navigateRoot('/home');

              _this2.menu.enable(false);
            } else {
              _this2.auth.showToast(data.message);
            }
          }, function (err) {
            _this2.auth.hideLoader();

            console.log("Error=>", err);
          });
        }
      }, {
        key: "fnDashboard",
        value: function fnDashboard() {
          this.menu.toggle();
        }
      }, {
        key: "fnMyOrders",
        value: function fnMyOrders() {
          this.menu.enable(true);
          this.navCtrl.navigateForward('customer-orders');
          this.menu.enable(false);
        }
      }, {
        key: "presentAlertConfirm",
        value: function presentAlertConfirm() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this3 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.alertCtrl.create({
                      message: "Are you sure want to logout?",
                      buttons: [{
                        text: 'Cancel',
                        role: 'cancel',
                        handler: function handler() {
                          console.log('Cancel clicked');
                        }
                      }, {
                        text: 'Logout',
                        handler: function handler() {
                          _this3.fnLogout();

                          console.log('Logout clicked');
                        }
                      }]
                    });

                  case 2:
                    alert = _context.sent;
                    _context.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        } // / Push notification /

      }, {
        key: "initPushNotification",
        value: function initPushNotification() {
          if (!this.platform.is('cordova')) {
            console.warn('Arshad :- Push notifications not initialized. Cordova is not available - Run in physical device');
            return;
          }

          var options = {
            android: {
              senderID: '330083022899',
              sound: 'true',
              vibrate: true,
              forceShow: true
            },
            ios: {
              alert: 'true',
              badge: true,
              sound: 'true',
              clearBadge: 'false'
            },
            windows: {}
          };
          var pushObject = this.push.init(options);
          pushObject.on('registration').subscribe(function (data) {
            //alert('device data ->' + JSON.stringify(data));
            console.log('device token -> ' + JSON.stringify(data.registrationId));
            localStorage.setItem('device_token', JSON.stringify(data.registrationId));
          });
          pushObject.on('notification').subscribe(function (notification) {
            console.log('Received a notification', notification);

            if (notification.additionalData.foreground) {// if application open, show popup
            } else {
              console.log('this.user_type in background ');
            }
          });
          pushObject.on('error').subscribe(function (error) {
            return console.error('Error with Push plugin' + error);
          });
        }
      }]);

      return AppComponent;
    }();

    AppComponent.ctorParameters = function () {
      return [{
        type: _auth_service__WEBPACK_IMPORTED_MODULE_8__["AuthService"]
      }, {
        type: _ionic_native_push_ngx__WEBPACK_IMPORTED_MODULE_7__["Push"]
      }, {
        type: _global_foo_service_service__WEBPACK_IMPORTED_MODULE_6__["GlobalFooServiceService"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"]
      }, {
        type: _angular_common__WEBPACK_IMPORTED_MODULE_5__["Location"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
      }, {
        type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"]
      }, {
        type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }];
    };

    AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-root',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./app.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./app.component.scss */
      "./src/app/app.component.scss"))["default"]]
    })], AppComponent);
    /***/
  },

  /***/
  "./src/app/app.module.ts":
  /*!*******************************!*\
    !*** ./src/app/app.module.ts ***!
    \*******************************/

  /*! exports provided: AppModule */

  /***/
  function srcAppAppModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppModule", function () {
      return AppModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/platform-browser */
    "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic-native/splash-screen/ngx */
    "./node_modules/@ionic-native/splash-screen/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic-native/status-bar/ngx */
    "./node_modules/@ionic-native/status-bar/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./app.component */
    "./src/app/app.component.ts");
    /* harmony import */


    var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./app-routing.module */
    "./src/app/app-routing.module.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var _common_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ./common.service */
    "./src/app/common.service.ts");
    /* harmony import */


    var _auth_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ./auth.service */
    "./src/app/auth.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _modal_popup_modal_popup_page__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! ./modal-popup/modal-popup.page */
    "./src/app/modal-popup/modal-popup.page.ts");
    /* harmony import */


    var _ionic_native_keyboard_ngx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! @ionic-native/keyboard/ngx */
    "./node_modules/@ionic-native/keyboard/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_document_viewer_ngx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
    /*! @ionic-native/document-viewer/ngx */
    "./node_modules/@ionic-native/document-viewer/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
    /*! @ionic-native/file/ngx */
    "./node_modules/@ionic-native/file/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
    /*! @ionic-native/file-transfer/ngx */
    "./node_modules/@ionic-native/file-transfer/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
    /*! @ionic-native/file-opener/ngx */
    "./node_modules/@ionic-native/file-opener/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(
    /*! @ionic-native/camera/ngx */
    "./node_modules/@ionic-native/camera/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_push_ngx__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(
    /*! @ionic-native/push/ngx */
    "./node_modules/@ionic-native/push/__ivy_ngcc__/ngx/index.js");

    var AppModule = function AppModule() {
      _classCallCheck(this, AppModule);
    };

    AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"], _modal_popup_modal_popup_page__WEBPACK_IMPORTED_MODULE_13__["ModalPopupPage"]],
      entryComponents: [_modal_popup_modal_popup_page__WEBPACK_IMPORTED_MODULE_13__["ModalPopupPage"]],
      imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_12__["ReactiveFormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpClientModule"]],
      providers: [_ionic_native_keyboard_ngx__WEBPACK_IMPORTED_MODULE_14__["Keyboard"], _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"], _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"], _common_service__WEBPACK_IMPORTED_MODULE_10__["CommonService"], _auth_service__WEBPACK_IMPORTED_MODULE_11__["AuthService"], _ionic_native_document_viewer_ngx__WEBPACK_IMPORTED_MODULE_15__["DocumentViewer"], _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_16__["File"], _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_18__["FileOpener"], _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_17__["FileTransfer"], _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_19__["Camera"], _ionic_native_push_ngx__WEBPACK_IMPORTED_MODULE_20__["Push"], {
        provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"],
        useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"]
      }],
      bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
    })], AppModule);
    /***/
  },

  /***/
  "./src/app/auth.service.ts":
  /*!*********************************!*\
    !*** ./src/app/auth.service.ts ***!
    \*********************************/

  /*! exports provided: AuthService */

  /***/
  function srcAppAuthServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AuthService", function () {
      return AuthService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var _common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./common.service */
    "./src/app/common.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js"); //import { ToastrService } from 'ngx-toastr';


    var AuthService = /*#__PURE__*/function () {
      function AuthService(loadingCtrl, http, toastCtrl, commonService) {
        _classCallCheck(this, AuthService);

        this.loadingCtrl = loadingCtrl;
        this.http = http;
        this.toastCtrl = toastCtrl;
        this.commonService = commonService;
      }

      _createClass(AuthService, [{
        key: "login",
        value: function login(data) {
          return this.commonService.postWithoutToken('users/login', data);
        }
      }, {
        key: "signup",
        value: function signup(data) {
          return this.commonService.postWithoutToken('users/signup', data);
        }
      }, {
        key: "changePassword",
        value: function changePassword(data) {
          return this.commonService.postWithoutToken('users/change_password', data);
        }
      }, {
        key: "forgotPassword",
        value: function forgotPassword(data) {
          return this.commonService.postWithoutToken('users/forgot_password', data);
        }
      }, {
        key: "checkOtp",
        value: function checkOtp(data) {
          return this.commonService.postWithoutToken('users/check-otp', data);
        }
      }, {
        key: "updatePassword",
        value: function updatePassword(data) {
          return this.commonService.postWithoutToken('users/update-password', data);
        }
      }, {
        key: "getProductDetails",
        value: function getProductDetails(data) {
          return this.commonService.postWithoutToken('products/get_product_list', data);
        }
      }, {
        key: "getUsersDetails",
        value: function getUsersDetails(data) {
          return this.commonService.postWithoutToken('users/get_user_detail', data);
        }
      }, {
        key: "editProfile",
        value: function editProfile(data) {
          return this.commonService.postWithoutToken('users/edit-profile', data);
        }
      }, {
        key: "addAddress",
        value: function addAddress(data) {
          return this.commonService.post('users/add-address', data);
        }
      }, {
        key: "getAddressList",
        value: function getAddressList(data) {
          return this.commonService.postWithoutToken('users/get_address_list', data);
        }
      }, {
        key: "editAddress",
        value: function editAddress(data) {
          return this.commonService.postWithoutToken('users/edit_address', data);
        }
      }, {
        key: "orderPlace",
        value: function orderPlace(data) {
          return this.commonService.postWithoutToken('orders/order-place', data);
        }
      }, {
        key: "getOrderList",
        value: function getOrderList(data) {
          return this.commonService.postWithoutToken('orders/orders_list', data);
        }
      }, {
        key: "getOrderDetails",
        value: function getOrderDetails(data) {
          return this.commonService.postWithoutToken('orders/get_order_detail', data);
        }
      }, {
        key: "getDeliveryBoyOrders",
        value: function getDeliveryBoyOrders(data) {
          return this.commonService.postWithoutToken('orders/get_delivery_boy_orders', data);
        }
      }, {
        key: "getSalesOrders",
        value: function getSalesOrders(data) {
          return this.commonService.postWithoutToken('orders/getSalesManOrder', data);
        }
      }, {
        key: "updateStatusOrder",
        value: function updateStatusOrder(data) {
          return this.commonService.postWithoutToken('orders/update_order_status', data);
        }
      }, {
        key: "getAllDriver",
        value: function getAllDriver(data) {
          return this.commonService.postWithoutToken('users/get_role_user', data);
        }
      }, {
        key: "assignDriver",
        value: function assignDriver(data) {
          return this.commonService.postWithoutToken('orders/assign_order_to_deliveryboy', data);
        }
      }, {
        key: "cancelOrder",
        value: function cancelOrder(data) {
          return this.commonService.postWithoutToken('orders/cancel_order', data);
        }
      }, {
        key: "complainOrder",
        value: function complainOrder(data) {
          return this.commonService.postWithoutToken('users/Complain', data);
        }
      }, {
        key: "updateOrderStatus",
        value: function updateOrderStatus(data) {
          return this.commonService.postWithoutToken('orders/update_order_status', data);
        }
      }, {
        key: "openPdf",
        value: function openPdf(data) {
          return this.commonService.getWithoutToken('orders/orderPDF/' + data);
        }
      }, {
        key: "getAddressFromGst",
        value: function getAddressFromGst(data) {
          return this.commonService.getAddFromGST('users/getGST?gst=' + data);
        }
      }, {
        key: "logout",
        value: function logout(data) {
          return this.commonService.postWithoutToken('users/logout', data);
        }
      }, {
        key: "showToast",
        value: function showToast(msg) {
          return this.toastCtrl.create({
            message: msg,
            duration: 2000
          }).then(function (toastData) {
            console.log(toastData);
            toastData.present();
          });
        }
      }, {
        key: "showToastLong",
        value: function showToastLong(msg) {
          return this.toastCtrl.create({
            message: msg,
            duration: 8000,
            position: "middle"
          }).then(function (toastData) {
            console.log(toastData);
            toastData.present();
          });
        }
      }, {
        key: "showLoader",
        value: function showLoader() {
          this.loadingCtrl.create({
            message: 'Please wait...'
          }).then(function (res) {
            res.present();
          });
        }
      }, {
        key: "hideLoader",
        value: function hideLoader() {
          this.loadingCtrl.dismiss().then(function (res) {
            console.log('Loading dismissed!', res);
          })["catch"](function (error) {
            console.log('error', error);
          });
        }
      }]);

      return AuthService;
    }();

    AuthService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]
      }, {
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"]
      }, {
        type: _common_service__WEBPACK_IMPORTED_MODULE_3__["CommonService"]
      }];
    };

    AuthService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()], AuthService);
    /***/
  },

  /***/
  "./src/app/common.service.ts":
  /*!***********************************!*\
    !*** ./src/app/common.service.ts ***!
    \***********************************/

  /*! exports provided: CommonService */

  /***/
  function srcAppCommonServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CommonService", function () {
      return CommonService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");

    var API_URL = 'http://laxmiatta.bi-team.in/api/';
    var file_url = 'http://laxmiatta.bi-team.in/';

    var CommonService = /*#__PURE__*/function () {
      function CommonService(http) {
        _classCallCheck(this, CommonService);

        this.http = http;
        this.customerOrder = [];
      }

      _createClass(CommonService, [{
        key: "postWithoutToken",
        value: function postWithoutToken(url, data) {
          var httpHeaders = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
          httpHeaders.set('Content-Type', 'application/json');
          return this.http.post(API_URL + url, data, {
            headers: httpHeaders
          });
        }
      }, {
        key: "postComplain",
        value: function postComplain(data) {
          var httpHeaders = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
          httpHeaders.set('Content-Type', 'application/json');
          return this.http.post("https://laxmiatta.bi-team.in/api/users/complainOrders", data, {
            headers: httpHeaders
          });
        }
      }, {
        key: "get",
        value: function get(url) {
          var header = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
            "Content-Type": "application/json",
            "Authorization": localStorage.getItem('token')
          });
          return this.http.get(API_URL + url, {
            headers: header
          });
        }
      }, {
        key: "getWithoutToken",
        value: function getWithoutToken(url) {
          var header = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
            "Content-Type": "application/json"
          });
          return this.http.get(API_URL + url, {
            headers: header
          });
        }
      }, {
        key: "getAddFromGST",
        value: function getAddFromGST(url) {
          var header = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
            "Content-Type": "application/json"
          });
          return this.http.get(API_URL + url, {
            headers: header
          });
        }
      }, {
        key: "post",
        value: function post(url, data) {
          var header = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
            "Content-Type": "application/json"
          });
          return this.http.post(API_URL + url, data, {
            headers: header
          });
        }
      }, {
        key: "postwithFormData",
        value: function postwithFormData(url, data) {
          var header = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
            "Authorization": localStorage.getItem('token')
          });
          return this.http.post(API_URL + url, data, {
            headers: header
          });
        }
      }, {
        key: "put",
        value: function put(url, data) {
          var header = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
            "Content-Type": "application/json",
            "Authorization": localStorage.getItem('token')
          });
          return this.http.put(API_URL + url, data, {
            headers: header
          });
        }
      }, {
        key: "delete",
        value: function _delete(url) {
          var header = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
            "Content-Type": "application/json",
            "Authorization": localStorage.getItem('token')
          });
          return this.http["delete"](API_URL + url, {
            headers: header
          });
        }
      }, {
        key: "url",
        value: function url() {
          return {
            'API_URL': API_URL,
            'file_url': file_url
          };
        }
      }]);

      return CommonService;
    }();

    CommonService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    CommonService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()], CommonService);
    /***/
  },

  /***/
  "./src/app/global-foo-service.service.ts":
  /*!***********************************************!*\
    !*** ./src/app/global-foo-service.service.ts ***!
    \***********************************************/

  /*! exports provided: GlobalFooServiceService */

  /***/
  function srcAppGlobalFooServiceServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "GlobalFooServiceService", function () {
      return GlobalFooServiceService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");

    var GlobalFooServiceService = /*#__PURE__*/function () {
      function GlobalFooServiceService() {
        _classCallCheck(this, GlobalFooServiceService);

        this.fooSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
      }

      _createClass(GlobalFooServiceService, [{
        key: "publishSomeData",
        value: function publishSomeData(data) {
          this.fooSubject.next(data);
        }
      }, {
        key: "getObservable",
        value: function getObservable() {
          return this.fooSubject;
        }
      }]);

      return GlobalFooServiceService;
    }();

    GlobalFooServiceService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], GlobalFooServiceService);
    /***/
  },

  /***/
  "./src/app/modal-popup/modal-popup.page.scss":
  /*!***************************************************!*\
    !*** ./src/app/modal-popup/modal-popup.page.scss ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function srcAppModalPopupModalPopupPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".close_btn {\n  float: right;\n  color: #000;\n  font-size: 24px;\n  margin-top: 5px;\n  margin-right: 5px;\n}\n\n.btnCloseContainer {\n  justify-content: flex-end !important;\n}\n\n.slide-text {\n  font-family: inherit;\n  color: #E4322E;\n  font-size: 20px;\n  text-align: center;\n  margin-top: 10px;\n  font-weight: 600;\n}\n\n.slide-price {\n  font-family: inherit;\n  color: #E4322E;\n  font-size: 1.4rem;\n  float: left;\n  margin-top: 3px;\n  margin-bottom: 0px;\n  font-weight: 600;\n}\n\n.slide-count {\n  color: #010944;\n  font-size: 1.4rem;\n  float: right;\n  margin-top: 3px;\n  margin-bottom: 0px;\n  font-family: open sans;\n}\n\n.product {\n  margin-top: 5px;\n  margin-bottom: 0px;\n  color: #010944;\n  font-size: 14px;\n  font-family: open sans;\n}\n\n.Description {\n  margin-top: 10px;\n  color: #E4322E;\n  font-size: 18px;\n  font-family: inherit;\n}\n\n.AddToCart_btn {\n  background-color: #E4322E;\n  color: #fff;\n  font-size: 16px;\n  height: 40px;\n  width: 95%;\n  border-radius: 8px;\n  display: block;\n  margin: auto;\n  border: 1px solid #fff;\n  margin-top: 12px;\n  font-family: open sans;\n  font-weight: 700;\n}\n\n.img_slide {\n  width: 60%;\n  height: 88px;\n}\n\nion-note {\n  color: #E4322E;\n  font-size: 1.3rem;\n  font-weight: 600;\n  color: #2e2e2e;\n  margin-top: 0px;\n  width: 80px;\n  margin-right: 0;\n  text-align: center;\n  margin-left: 0;\n  display: flex;\n  float: right;\n  align-items: center;\n}\n\nion-note.price {\n  width: 50px;\n}\n\nion-note ion-icon {\n  font-size: 2.5rem;\n  color: #E4322E;\n}\n\nion-note span {\n  font-size: 1.2rem;\n  text-align: center;\n  width: 35px;\n  font-weight: 600;\n}\n\n.add-rm-btn {\n  font-size: 2rem;\n  color: #E4322E;\n  float: right;\n  display: flex;\n}\n\n.card-width {\n  width: 95%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9tb2RhbC1wb3B1cC9tb2RhbC1wb3B1cC5wYWdlLnNjc3MiLCJzcmMvYXBwL21vZGFsLXBvcHVwL21vZGFsLXBvcHVwLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQ0NKOztBRENBO0VBQ0ksb0NBQUE7QUNFSjs7QURBQTtFQUNJLG9CQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7QUNHSjs7QUREQTtFQUNJLG9CQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FDSUo7O0FEREE7RUFDSSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7QUNJSjs7QURGQTtFQUNJLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0Esc0JBQUE7QUNLSjs7QURIQTtFQUNJLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxvQkFBQTtBQ01KOztBREpBO0VBQ0kseUJBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxzQkFBQTtFQUNBLGdCQUFBO0FDT0o7O0FETEE7RUFDSSxVQUFBO0VBQ0EsWUFBQTtBQ1FKOztBRE5BO0VBQ0ksY0FBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtBQ1NKOztBRFJJO0VBQ0ksV0FBQTtBQ1VSOztBRFJJO0VBQ0ksaUJBQUE7RUFDQSxjQUFBO0FDVVI7O0FEUkk7RUFDSSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0FDVVI7O0FETkE7RUFDSSxlQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0FDU0o7O0FEUEE7RUFDSSxVQUFBO0FDVUoiLCJmaWxlIjoic3JjL2FwcC9tb2RhbC1wb3B1cC9tb2RhbC1wb3B1cC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2xvc2VfYnRue1xuICAgIGZsb2F0OiByaWdodDtcbiAgICBjb2xvcjogIzAwMDtcbiAgICBmb250LXNpemU6IDI0cHg7XG4gICAgbWFyZ2luLXRvcDogNXB4O1xuICAgIG1hcmdpbi1yaWdodDogNXB4O1xufVxuLmJ0bkNsb3NlQ29udGFpbmVye1xuICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQgIWltcG9ydGFudDtcbn1cbi5zbGlkZS10ZXh0e1xuICAgIGZvbnQtZmFtaWx5OiBpbmhlcml0O1xuICAgIGNvbG9yOiAjRTQzMjJFO1xuICAgIGZvbnQtc2l6ZTogMjBweDsgXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIG1hcmdpbi10b3A6MTBweDtcbiAgICBmb250LXdlaWdodDogNjAwO1xufVxuLnNsaWRlLXByaWNle1xuICAgIGZvbnQtZmFtaWx5OiBpbmhlcml0O1xuICAgIGNvbG9yOiAjRTQzMjJFO1xuICAgIGZvbnQtc2l6ZTogMS40cmVtOyBcbiAgICBmbG9hdDogbGVmdDtcbiAgICBtYXJnaW4tdG9wOjNweDtcbiAgICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcblxufVxuLnNsaWRlLWNvdW50e1xuICAgIGNvbG9yOiAjMDEwOTQ0O1xuICAgIGZvbnQtc2l6ZTogMS40cmVtOyBcbiAgICBmbG9hdDogcmlnaHQ7XG4gICAgbWFyZ2luLXRvcDozcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICAgIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG59XG4ucHJvZHVjdHtcbiAgICBtYXJnaW4tdG9wOjVweDtcbiAgICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gICAgY29sb3I6ICMwMTA5NDQ7XG4gICAgZm9udC1zaXplOiAxNHB4OyBcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuLkRlc2NyaXB0aW9ue1xuICAgIG1hcmdpbi10b3A6IDEwcHg7XG4gICAgY29sb3I6ICNFNDMyMkU7XG4gICAgZm9udC1zaXplOiAxOHB4OyBcbiAgICBmb250LWZhbWlseTogaW5oZXJpdDsgXG59XG4uQWRkVG9DYXJ0X2J0bntcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTQzMjJFO1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICBoZWlnaHQ6IDQwcHg7XG4gICAgd2lkdGg6IDk1JTtcbiAgICBib3JkZXItcmFkaXVzOiA4cHg7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgbWFyZ2luOiBhdXRvO1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICNmZmY7XG4gICAgbWFyZ2luLXRvcDogMTJweDtcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XG59XG4uaW1nX3NsaWRle1xuICAgIHdpZHRoOjYwJTtcbiAgICBoZWlnaHQ6IDg4cHg7XG59XG5pb24tbm90ZSB7XG4gICAgY29sb3I6ICNFNDMyMkU7XG4gICAgZm9udC1zaXplOiAxLjNyZW07XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBjb2xvcjogIzJlMmUyZTtcbiAgICBtYXJnaW4tdG9wOiAwcHg7XG4gICAgd2lkdGg6IDgwcHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAwO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBtYXJnaW4tbGVmdDogMDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsb2F0OiByaWdodDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICYucHJpY2Uge1xuICAgICAgICB3aWR0aDogNTBweDtcbiAgICB9XG4gICAgaW9uLWljb24ge1xuICAgICAgICBmb250LXNpemU6IDIuNXJlbTtcbiAgICAgICAgY29sb3I6ICNFNDMyMkU7XG4gICAgfVxuICAgIHNwYW4ge1xuICAgICAgICBmb250LXNpemU6IDEuMnJlbTtcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICB3aWR0aDogMzVweDtcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICB9XG4gICAgXG59XG4uYWRkLXJtLWJ0bntcbiAgICBmb250LXNpemU6IDJyZW07XG4gICAgY29sb3I6ICNFNDMyMkU7XG4gICAgZmxvYXQ6IHJpZ2h0O1xuICAgIGRpc3BsYXk6IGZsZXg7XG59XG4uY2FyZC13aWR0aHtcbiAgICB3aWR0aDogOTUlO1xufSIsIi5jbG9zZV9idG4ge1xuICBmbG9hdDogcmlnaHQ7XG4gIGNvbG9yOiAjMDAwO1xuICBmb250LXNpemU6IDI0cHg7XG4gIG1hcmdpbi10b3A6IDVweDtcbiAgbWFyZ2luLXJpZ2h0OiA1cHg7XG59XG5cbi5idG5DbG9zZUNvbnRhaW5lciB7XG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQgIWltcG9ydGFudDtcbn1cblxuLnNsaWRlLXRleHQge1xuICBmb250LWZhbWlseTogaW5oZXJpdDtcbiAgY29sb3I6ICNFNDMyMkU7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBmb250LXdlaWdodDogNjAwO1xufVxuXG4uc2xpZGUtcHJpY2Uge1xuICBmb250LWZhbWlseTogaW5oZXJpdDtcbiAgY29sb3I6ICNFNDMyMkU7XG4gIGZvbnQtc2l6ZTogMS40cmVtO1xuICBmbG9hdDogbGVmdDtcbiAgbWFyZ2luLXRvcDogM3B4O1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG5cbi5zbGlkZS1jb3VudCB7XG4gIGNvbG9yOiAjMDEwOTQ0O1xuICBmb250LXNpemU6IDEuNHJlbTtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBtYXJnaW4tdG9wOiAzcHg7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cblxuLnByb2R1Y3Qge1xuICBtYXJnaW4tdG9wOiA1cHg7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgY29sb3I6ICMwMTA5NDQ7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cblxuLkRlc2NyaXB0aW9uIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgY29sb3I6ICNFNDMyMkU7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgZm9udC1mYW1pbHk6IGluaGVyaXQ7XG59XG5cbi5BZGRUb0NhcnRfYnRuIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0U0MzIyRTtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgaGVpZ2h0OiA0MHB4O1xuICB3aWR0aDogOTUlO1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW46IGF1dG87XG4gIGJvcmRlcjogMXB4IHNvbGlkICNmZmY7XG4gIG1hcmdpbi10b3A6IDEycHg7XG4gIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG59XG5cbi5pbWdfc2xpZGUge1xuICB3aWR0aDogNjAlO1xuICBoZWlnaHQ6IDg4cHg7XG59XG5cbmlvbi1ub3RlIHtcbiAgY29sb3I6ICNFNDMyMkU7XG4gIGZvbnQtc2l6ZTogMS4zcmVtO1xuICBmb250LXdlaWdodDogNjAwO1xuICBjb2xvcjogIzJlMmUyZTtcbiAgbWFyZ2luLXRvcDogMHB4O1xuICB3aWR0aDogODBweDtcbiAgbWFyZ2luLXJpZ2h0OiAwO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbi1sZWZ0OiAwO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbG9hdDogcmlnaHQ7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5pb24tbm90ZS5wcmljZSB7XG4gIHdpZHRoOiA1MHB4O1xufVxuaW9uLW5vdGUgaW9uLWljb24ge1xuICBmb250LXNpemU6IDIuNXJlbTtcbiAgY29sb3I6ICNFNDMyMkU7XG59XG5pb24tbm90ZSBzcGFuIHtcbiAgZm9udC1zaXplOiAxLjJyZW07XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgd2lkdGg6IDM1cHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG5cbi5hZGQtcm0tYnRuIHtcbiAgZm9udC1zaXplOiAycmVtO1xuICBjb2xvcjogI0U0MzIyRTtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBkaXNwbGF5OiBmbGV4O1xufVxuXG4uY2FyZC13aWR0aCB7XG4gIHdpZHRoOiA5NSU7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/modal-popup/modal-popup.page.ts":
  /*!*************************************************!*\
    !*** ./src/app/modal-popup/modal-popup.page.ts ***!
    \*************************************************/

  /*! exports provided: ModalPopupPage */

  /***/
  function srcAppModalPopupModalPopupPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ModalPopupPage", function () {
      return ModalPopupPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../common.service */
    "./src/app/common.service.ts");

    var ModalPopupPage = /*#__PURE__*/function () {
      function ModalPopupPage(commonService, navParams, modalCtrl, navCtrl) {
        _classCallCheck(this, ModalPopupPage);

        this.commonService = commonService;
        this.navParams = navParams;
        this.modalCtrl = modalCtrl;
        this.navCtrl = navCtrl;
        this.cartData = [];
        this.item_qty = 0;
        this.baseIncrement = 0;
        this.slideOpts = {
          initialSlide: 1,
          loop: true,
          centeredSlides: true
        };
        this.item_qty = this.navParams.data.name.product_minimum_qty;
        this.baseIncrement = parseInt(this.navParams.data.name.product_minimum_qty);
      }

      _createClass(ModalPopupPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.url = this.commonService.url();
        }
      }, {
        key: "closeModal",
        value: function closeModal() {
          this.modalCtrl.dismiss({
            'dismissed': true
          });
        }
      }, {
        key: "fnAddToCart",
        value: function fnAddToCart(id, name, weight, price, qty, images) {
          this.cartData = [];

          if (localStorage.getItem("cartData")) {
            this.cartData = JSON.parse(localStorage.getItem("cartData"));
            var product_exits = false;
            this.cartData.forEach(function (element) {
              if (element.id == id) {
                element.qty = parseInt(element.qty) + parseInt(qty);
                product_exits = true;
              }
            });

            if (product_exits == false) {
              this.cartData.push({
                id: id,
                name: name,
                weight: weight,
                price: price,
                qty: qty,
                images: images
              });
            }

            localStorage.setItem("cartData", JSON.stringify(this.cartData));
          } else {
            this.cartData.push({
              id: id,
              name: name,
              weight: weight,
              price: price,
              qty: qty,
              images: images
            });
            localStorage.setItem("cartData", JSON.stringify(this.cartData));
          }

          console.log(this.cartData);
          this.navCtrl.navigateForward('your-cart');
        }
      }, {
        key: "fnremove",
        value: function fnremove() {
          if (this.item_qty - this.baseIncrement < this.baseIncrement) {
            this.item_qty = this.baseIncrement;
          } else {
            this.item_qty -= this.baseIncrement;
          }
        }
      }, {
        key: "fnadd",
        value: function fnadd() {
          var a = parseInt(this.item_qty.toString());
          this.item_qty = a += this.baseIncrement;
        }
      }]);

      return ModalPopupPage;
    }();

    ModalPopupPage.ctorParameters = function () {
      return [{
        type: _common_service__WEBPACK_IMPORTED_MODULE_3__["CommonService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], ModalPopupPage.prototype, "name", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('slideWithNav', {
      "static": false
    })], ModalPopupPage.prototype, "slideWithNav", void 0);
    ModalPopupPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-modal-popup',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./modal-popup.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/modal-popup/modal-popup.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./modal-popup.page.scss */
      "./src/app/modal-popup/modal-popup.page.scss"))["default"]]
    })], ModalPopupPage);
    /***/
  },

  /***/
  "./src/environments/environment.ts":
  /*!*****************************************!*\
    !*** ./src/environments/environment.ts ***!
    \*****************************************/

  /*! exports provided: environment */

  /***/
  function srcEnvironmentsEnvironmentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "environment", function () {
      return environment;
    }); // This file can be replaced during build by using the `fileReplacements` array.
    // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
    // The list of file replacements can be found in `angular.json`.


    var environment = {
      production: false,
      API_URL: 'http://laxmiatta.bi-team.in/api/',
      file_url: 'http://laxmiatta.bi-team.in/'
    };
    /*
     * For easier debugging in development mode, you can import the following file
     * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
     *
     * This import should be commented out in production mode because it will have a negative impact
     * on performance if an error is thrown.
     */
    // import 'zone.js/dist/zone-error';  // Included with Angular CLI.

    /***/
  },

  /***/
  "./src/main.ts":
  /*!*********************!*\
    !*** ./src/main.ts ***!
    \*********************/

  /*! no exports provided */

  /***/
  function srcMainTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/platform-browser-dynamic */
    "./node_modules/@angular/platform-browser-dynamic/__ivy_ngcc__/fesm2015/platform-browser-dynamic.js");
    /* harmony import */


    var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./app/app.module */
    "./src/app/app.module.ts");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./environments/environment */
    "./src/environments/environment.ts");

    if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
      Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
    }

    Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])["catch"](function (err) {
      return console.log(err);
    });
    /***/
  },

  /***/
  0:
  /*!***************************!*\
    !*** multi ./src/main.ts ***!
    \***************************/

  /*! no static exports found */

  /***/
  function _(module, exports, __webpack_require__) {
    module.exports = __webpack_require__(
    /*! /Users/yashcomputers/Desktop/Arshad Workspace/IonicWorkSpace/lakshmi-food/src/main.ts */
    "./src/main.ts");
    /***/
  }
}, [[0, "runtime", "vendor"]]]);
//# sourceMappingURL=main-es5.js.map