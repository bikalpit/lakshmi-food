(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["success-order-success-order-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/success-order/success-order.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/success-order/success-order.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title class=\"main-title\">Success Order</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"circle\">  \n  <div class=\"right-img\">\n    <img src=\"../../assets/imgs/correct.png\" style=\"padding: 26%;\">\n  </div>\n  </div>\n\n  <h4 class=\"msg-success\"><b>Your Order Placed Successfully!</b></h4>\n  <h5 class=\"msg-orderId\"><b>Order Id: #{{OrderNumber}}</b></h5>\n\n  <button ion-button class=\"ViewProduct_btn\" (click)=\"fnViewProduct()\">View Order</button>\n</ion-content>");

/***/ }),

/***/ "./src/app/success-order/success-order-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/success-order/success-order-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: SuccessOrderPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SuccessOrderPageRoutingModule", function() { return SuccessOrderPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _success_order_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./success-order.page */ "./src/app/success-order/success-order.page.ts");




const routes = [
    {
        path: '',
        component: _success_order_page__WEBPACK_IMPORTED_MODULE_3__["SuccessOrderPage"]
    }
];
let SuccessOrderPageRoutingModule = class SuccessOrderPageRoutingModule {
};
SuccessOrderPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SuccessOrderPageRoutingModule);



/***/ }),

/***/ "./src/app/success-order/success-order.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/success-order/success-order.module.ts ***!
  \*******************************************************/
/*! exports provided: SuccessOrderPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SuccessOrderPageModule", function() { return SuccessOrderPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _success_order_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./success-order-routing.module */ "./src/app/success-order/success-order-routing.module.ts");
/* harmony import */ var _success_order_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./success-order.page */ "./src/app/success-order/success-order.page.ts");







let SuccessOrderPageModule = class SuccessOrderPageModule {
};
SuccessOrderPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _success_order_routing_module__WEBPACK_IMPORTED_MODULE_5__["SuccessOrderPageRoutingModule"]
        ],
        declarations: [_success_order_page__WEBPACK_IMPORTED_MODULE_6__["SuccessOrderPage"]]
    })
], SuccessOrderPageModule);



/***/ }),

/***/ "./src/app/success-order/success-order.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/success-order/success-order.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".main-title {\n  text-align: center;\n  color: #E4322E;\n}\n\n.right-img {\n  width: 100%;\n  text-align: center;\n  margin-top: 20%;\n}\n\n.circle {\n  background-color: #f5f0f0;\n  width: 205px;\n  height: 205px;\n  border-radius: 50%;\n  margin: auto;\n}\n\n.msg-success {\n  text-align: center;\n  margin-top: 15%;\n  color: #000;\n  font-family: open sans;\n}\n\n.msg-orderId {\n  text-align: center;\n  color: #000;\n  font-family: open sans;\n}\n\n.ViewProduct_btn {\n  background-color: #E4322E;\n  color: #fff;\n  font-size: 20px;\n  height: 40px;\n  width: 90%;\n  border-radius: 8px;\n  display: block;\n  margin: auto;\n  border: 1px solid #fff;\n  margin-right: 12px;\n  margin-left: 18px;\n  margin-top: 25%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9zdWNjZXNzLW9yZGVyL3N1Y2Nlc3Mtb3JkZXIucGFnZS5zY3NzIiwic3JjL2FwcC9zdWNjZXNzLW9yZGVyL3N1Y2Nlc3Mtb3JkZXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FEQ0E7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FDRUo7O0FEQUE7RUFDSSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FDR0o7O0FEREE7RUFDSSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0Esc0JBQUE7QUNJSjs7QURGQTtFQUNJLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLHNCQUFBO0FDS0o7O0FESEE7RUFDSSx5QkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtBQ01KIiwiZmlsZSI6InNyYy9hcHAvc3VjY2Vzcy1vcmRlci9zdWNjZXNzLW9yZGVyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYWluLXRpdGxle1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogI0U0MzIyRTtcbn1cbi5yaWdodC1pbWd7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIG1hcmdpbi10b3A6IDIwJTs7XG59XG4uY2lyY2xle1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmNWYwZjA7XG4gICAgd2lkdGg6IDIwNXB4O1xuICAgIGhlaWdodDogMjA1cHg7XG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgIG1hcmdpbjogYXV0bztcbn1cbi5tc2ctc3VjY2Vzc3tcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgbWFyZ2luLXRvcDogMTUlO1xuICAgIGNvbG9yOiAjMDAwO1xuICAgIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG59XG4ubXNnLW9yZGVySWR7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjMDAwO1xuICAgIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG59XG4uVmlld1Byb2R1Y3RfYnRue1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNFNDMyMkU7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGhlaWdodDogNDBweDtcbiAgICB3aWR0aDogOTAlO1xuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBtYXJnaW46IGF1dG87XG4gICAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbiAgICBtYXJnaW4tcmlnaHQ6IDEycHg7XG4gICAgbWFyZ2luLWxlZnQ6IDE4cHg7XG4gICAgbWFyZ2luLXRvcDogMjUlO1xufVxuIiwiLm1haW4tdGl0bGUge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjRTQzMjJFO1xufVxuXG4ucmlnaHQtaW1nIHtcbiAgd2lkdGg6IDEwMCU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luLXRvcDogMjAlO1xufVxuXG4uY2lyY2xlIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjBmMDtcbiAgd2lkdGg6IDIwNXB4O1xuICBoZWlnaHQ6IDIwNXB4O1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIG1hcmdpbjogYXV0bztcbn1cblxuLm1zZy1zdWNjZXNzIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW4tdG9wOiAxNSU7XG4gIGNvbG9yOiAjMDAwO1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuXG4ubXNnLW9yZGVySWQge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjMDAwO1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuXG4uVmlld1Byb2R1Y3RfYnRuIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0U0MzIyRTtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgaGVpZ2h0OiA0MHB4O1xuICB3aWR0aDogOTAlO1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW46IGF1dG87XG4gIGJvcmRlcjogMXB4IHNvbGlkICNmZmY7XG4gIG1hcmdpbi1yaWdodDogMTJweDtcbiAgbWFyZ2luLWxlZnQ6IDE4cHg7XG4gIG1hcmdpbi10b3A6IDI1JTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/success-order/success-order.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/success-order/success-order.page.ts ***!
  \*****************************************************/
/*! exports provided: SuccessOrderPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SuccessOrderPage", function() { return SuccessOrderPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");



let SuccessOrderPage = class SuccessOrderPage {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
    }
    ngOnInit() {
        this.OrderNumber = localStorage.getItem('OrderNumber');
    }
    fnViewProduct() {
        this.navCtrl.navigateForward('customer-orders');
    }
};
SuccessOrderPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] }
];
SuccessOrderPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-success-order',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./success-order.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/success-order/success-order.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./success-order.page.scss */ "./src/app/success-order/success-order.page.scss")).default]
    })
], SuccessOrderPage);



/***/ })

}]);
//# sourceMappingURL=success-order-success-order-module-es2015.js.map