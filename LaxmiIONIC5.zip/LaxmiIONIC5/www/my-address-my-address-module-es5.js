function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["my-address-my-address-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/my-address/my-address.page.html":
  /*!***************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/my-address/my-address.page.html ***!
    \***************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppMyAddressMyAddressPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\" >\n      <ion-icon name=\"arrow-back-outline\" class=\"backarrow1\" (click)=\" fnBack()\"></ion-icon>\n    </ion-buttons>\n\n    <ion-buttons slot=\"end\">\n      <ion-button>\n\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"main-title\">My Address</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-card class=\"add_card_shadow\" *ngFor=\"let item of addressList;let i = index\">\n    <ion-row style=\"margin-top: 5px;\" >\n      <ion-col size=\"2\">\n        <ion-icon *ngIf=\"item.address_type == 'Home' || item.address_type == null\" name=\"home-outline\" class=\"icon-address\"></ion-icon>\n        <ion-icon *ngIf=\"item.address_type == 'Office'\" name=\"business-outline\" class=\"icon-address\"></ion-icon>\n        <ion-icon *ngIf=\"item.address_type == 'Other'\" name=\"location-outline\" class=\"icon-address\"></ion-icon>\n      </ion-col>\n\n      <ion-col size=\"8.5\">\n\n        <p class=\"p-name\">{{item.name}}</p>\n        <p class=\"p-address\" *ngIf=\"item.address_house_no && item.address_area!==null && item.address_landmark!==''\">{{item.address_house_no}},{{item.address_area}},{{item.address_landmark}}</p>\n        <p class=\"p-address\" *ngIf=\"item.address_house_no && item.address_area===null && item.address_landmark===''\">{{item.address_house_no}}</p>\n        <p class=\"p-address\" *ngIf=\"item.address_house_no && item.address_area!==null && item.address_landmark===''\">{{item.address_house_no}}, {{item.address_area}}</p>\n        <p class=\"p-address\">{{item.address_city}},{{item.address_state}},{{item.address_zipcode}}</p>\n        <p class=\"p-address\">{{item.address_mobile_no}}</p>\n      </ion-col>\n      <ion-col size=\"1.5\" style=\"text-align: end !important;\">\n        <ion-icon name=\"create-outline\" color=\"danger\" class=\"p-check-icons float-r\" (click)=\"updateAddress(item)\">\n        </ion-icon>\n      </ion-col>\n\n    </ion-row>\n\n  </ion-card>\n\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/my-address/my-address-routing.module.ts":
  /*!*********************************************************!*\
    !*** ./src/app/my-address/my-address-routing.module.ts ***!
    \*********************************************************/

  /*! exports provided: MyAddressPageRoutingModule */

  /***/
  function srcAppMyAddressMyAddressRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MyAddressPageRoutingModule", function () {
      return MyAddressPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _my_address_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./my-address.page */
    "./src/app/my-address/my-address.page.ts");

    var routes = [{
      path: '',
      component: _my_address_page__WEBPACK_IMPORTED_MODULE_3__["MyAddressPage"]
    }];

    var MyAddressPageRoutingModule = function MyAddressPageRoutingModule() {
      _classCallCheck(this, MyAddressPageRoutingModule);
    };

    MyAddressPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MyAddressPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/my-address/my-address.module.ts":
  /*!*************************************************!*\
    !*** ./src/app/my-address/my-address.module.ts ***!
    \*************************************************/

  /*! exports provided: MyAddressPageModule */

  /***/
  function srcAppMyAddressMyAddressModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MyAddressPageModule", function () {
      return MyAddressPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _my_address_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./my-address-routing.module */
    "./src/app/my-address/my-address-routing.module.ts");
    /* harmony import */


    var _my_address_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./my-address.page */
    "./src/app/my-address/my-address.page.ts");

    var MyAddressPageModule = function MyAddressPageModule() {
      _classCallCheck(this, MyAddressPageModule);
    };

    MyAddressPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _my_address_routing_module__WEBPACK_IMPORTED_MODULE_5__["MyAddressPageRoutingModule"]],
      declarations: [_my_address_page__WEBPACK_IMPORTED_MODULE_6__["MyAddressPage"]]
    })], MyAddressPageModule);
    /***/
  },

  /***/
  "./src/app/my-address/my-address.page.scss":
  /*!*************************************************!*\
    !*** ./src/app/my-address/my-address.page.scss ***!
    \*************************************************/

  /*! exports provided: default */

  /***/
  function srcAppMyAddressMyAddressPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".backarrow1 {\n  margin-left: 10px;\n  color: #E4322E;\n  font-size: 26px;\n}\n\n.main-title {\n  text-align: center;\n  color: #E4322E;\n}\n\n.add_card_shadow {\n  background-color: #fff;\n}\n\n.p-name {\n  color: #E4322E;\n  margin: 0;\n  font-size: 18px;\n  margin-bottom: 5px;\n  font-family: open sans;\n}\n\n.p-address {\n  color: #010944;\n  margin: 0;\n  margin-left: 2px;\n  font-size: 1rem;\n  margin-top: 6px;\n  font-family: open sans;\n}\n\n.p-icon {\n  font-size: 1.2rem;\n  color: #E4322E;\n  float: right;\n}\n\n.icon-address {\n  font-size: 1.2rem;\n  color: red;\n  margin-top: 0.1rem;\n  margin-left: 0.5rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9teS1hZGRyZXNzL215LWFkZHJlc3MucGFnZS5zY3NzIiwic3JjL2FwcC9teS1hZGRyZXNzL215LWFkZHJlc3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksaUJBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBQ0NKOztBRENBO0VBQ0ksa0JBQUE7RUFDQSxjQUFBO0FDRUo7O0FEQUE7RUFDSSxzQkFBQTtBQ0dKOztBRERBO0VBQ0ksY0FBQTtFQUNBLFNBQUE7RUFFQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtBQ0dKOztBRERBO0VBQ0ksY0FBQTtFQUNBLFNBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0VBQ0Esc0JBQUE7QUNJSjs7QURGQTtFQUNJLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUNLSjs7QURIQTtFQUNJLGlCQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUNNSiIsImZpbGUiOiJzcmMvYXBwL215LWFkZHJlc3MvbXktYWRkcmVzcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYmFja2Fycm93MXtcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICBjb2xvcjogI0U0MzIyRTtcbiAgICBmb250LXNpemU6IDI2cHg7XG59XG4ubWFpbi10aXRsZXtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICNFNDMyMkU7XG59XG4uYWRkX2NhcmRfc2hhZG93e1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG59XG4ucC1uYW1le1xuICAgIGNvbG9yOiAjRTQzMjJFO1xuICAgIG1hcmdpbjogMDtcbiAgICAvLyBtYXJnaW4tbGVmdDogMTBweDtcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICAgIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG59XG4ucC1hZGRyZXNze1xuICAgIGNvbG9yOiAjMDEwOTQ0O1xuICAgIG1hcmdpbjogMDtcbiAgICBtYXJnaW4tbGVmdDogMnB4O1xuICAgIGZvbnQtc2l6ZTogMXJlbTtcbiAgICBtYXJnaW4tdG9wOiA2cHg7XG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cbi5wLWljb257XG4gICAgZm9udC1zaXplOiAxLjJyZW07XG4gICAgY29sb3I6ICNFNDMyMkU7XG4gICAgZmxvYXQ6IHJpZ2h0O1xufVxuLmljb24tYWRkcmVzc3tcbiAgICBmb250LXNpemU6IDEuMnJlbTtcbiAgICBjb2xvcjogcmVkO1xuICAgIG1hcmdpbi10b3A6IDAuMXJlbTtcbiAgICBtYXJnaW4tbGVmdDogMC41cmVtO1xufSIsIi5iYWNrYXJyb3cxIHtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIGNvbG9yOiAjRTQzMjJFO1xuICBmb250LXNpemU6IDI2cHg7XG59XG5cbi5tYWluLXRpdGxlIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI0U0MzIyRTtcbn1cblxuLmFkZF9jYXJkX3NoYWRvdyB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG59XG5cbi5wLW5hbWUge1xuICBjb2xvcjogI0U0MzIyRTtcbiAgbWFyZ2luOiAwO1xuICBmb250LXNpemU6IDE4cHg7XG4gIG1hcmdpbi1ib3R0b206IDVweDtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cblxuLnAtYWRkcmVzcyB7XG4gIGNvbG9yOiAjMDEwOTQ0O1xuICBtYXJnaW46IDA7XG4gIG1hcmdpbi1sZWZ0OiAycHg7XG4gIGZvbnQtc2l6ZTogMXJlbTtcbiAgbWFyZ2luLXRvcDogNnB4O1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuXG4ucC1pY29uIHtcbiAgZm9udC1zaXplOiAxLjJyZW07XG4gIGNvbG9yOiAjRTQzMjJFO1xuICBmbG9hdDogcmlnaHQ7XG59XG5cbi5pY29uLWFkZHJlc3Mge1xuICBmb250LXNpemU6IDEuMnJlbTtcbiAgY29sb3I6IHJlZDtcbiAgbWFyZ2luLXRvcDogMC4xcmVtO1xuICBtYXJnaW4tbGVmdDogMC41cmVtO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/my-address/my-address.page.ts":
  /*!***********************************************!*\
    !*** ./src/app/my-address/my-address.page.ts ***!
    \***********************************************/

  /*! exports provided: MyAddressPage */

  /***/
  function srcAppMyAddressMyAddressPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MyAddressPage", function () {
      return MyAddressPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../auth.service */
    "./src/app/auth.service.ts");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");

    var MyAddressPage = /*#__PURE__*/function () {
      function MyAddressPage(location, auth, navCtrl, menu) {
        _classCallCheck(this, MyAddressPage);

        this.location = location;
        this.auth = auth;
        this.navCtrl = navCtrl;
        this.menu = menu;
        this.addressList = [];
        this.menu.enable(true);
        this.role = localStorage.getItem("role");
        this.user_id = localStorage.getItem("id");
        console.log(this.role);
      }

      _createClass(MyAddressPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.fngetAddressDetails();
        }
      }, {
        key: "fnBack",
        value: function fnBack() {
          if (this.role == 'Customer') {
            this.navCtrl.navigateRoot('/dashboard');
          } else if (this.role == 'Salesman') {
            this.navCtrl.navigateRoot('/sales-dashboard');
          } else {
            this.navCtrl.navigateRoot('/my-account');
          } // this.location.back();

        }
      }, {
        key: "fngetAddressDetails",
        value: function fngetAddressDetails() {
          var _this = this;

          var requestObject = {
            "user_id": this.user_id
          };
          this.auth.showLoader();
          this.auth.getAddressList(requestObject).subscribe(function (data) {
            _this.auth.hideLoader();

            _this.dataResponse = data.data;
            _this.addressList = _this.dataResponse;
            console.log('addressList - > ', _this.addressList);
          }, function (err) {
            console.log("Error=>", err);

            _this.auth.hideLoader();
          });
        }
      }, {
        key: "updateAddress",
        value: function updateAddress(data) {
          console.log(data);
          this.navCtrl.navigateForward('edit-address', {
            state: {
              data: data,
              from: '0'
            }
          });
        }
      }]);

      return MyAddressPage;
    }();

    MyAddressPage.ctorParameters = function () {
      return [{
        type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["Location"]
      }, {
        type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"]
      }];
    };

    MyAddressPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-my-address',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./my-address.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/my-address/my-address.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./my-address.page.scss */
      "./src/app/my-address/my-address.page.scss"))["default"]]
    })], MyAddressPage);
    /***/
  }
}]);
//# sourceMappingURL=my-address-my-address-module-es5.js.map