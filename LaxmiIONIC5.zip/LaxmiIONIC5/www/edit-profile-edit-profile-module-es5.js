function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["edit-profile-edit-profile-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/edit-profile/edit-profile.page.html":
  /*!*******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/edit-profile/edit-profile.page.html ***!
    \*******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppEditProfileEditProfilePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header> \n  <ion-toolbar>\n    <ion-buttons slot=\"start\" >\n      <ion-icon name=\"arrow-back-outline\" class=\"backarrow1\" (click)=\" goBack()\"></ion-icon>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-button>\n\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"main-title\">Edit Profile</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content> \n  <div class=\"avtar\">\n    <img *ngIf=\"photos\" [src]=\"photos\" class=\"img\">\n    <img *ngIf=\"!photos\" src=\"../../assets/imgs/1945870586Image.png\" class=\"img\">\n    <p class=\"profile-txt\" (click)=\"presentActionSheet()\"><b>Change Profile Photo</b></p>\n    <div *ngIf=\"AllUserArray\">\n      <form [formGroup]=\"ionicForm\">\n        <div class=\"order-no-bg\">\n          <ion-input placeholder=\"Full Name\" formControlName=\"Name\" [formControl]=\"ionicForm.controls['Name']\" type=\"text\" name=\"Name\"\n            class=\"order_no_txt\">\n          </ion-input>\n          <span class=\"error-wrap\" *ngIf=\"ionicForm.get('Name').touched || ionicForm.get('Name').dirty\">\n            <small *ngIf=\"ionicForm.get('Name').hasError('required')\" class=\"error\">Name is required.</small>\n          </span>\n        </div>\n\n        <div class=\"order-no-bg\">\n          <ion-input placeholder=\"Email Id\" formControlName=\"Email\" type=\"text\" name=\"Email\"\n          [formControl]=\"ionicForm.controls['Email']\" class=\"order_no_txt\"></ion-input>\n          <span class=\"error-wrap\" *ngIf=\"ionicForm.get('Email').touched || ionicForm.get('Email').dirty\">\n            <small *ngIf=\"ionicForm.get('Email').hasError('required')\" class=\"error\">Email is required.</small>\n            <small *ngIf=\"ionicForm.get('Email').hasError('pattern')\" class=\"error\">Enter valid email.</small>\n          </span>\n        </div>\n\n        <div class=\"order-no-bg\" *ngIf=\"role==='Customer'\">\n          <ion-input placeholder=\"Firm Name\" formControlName=\"UserName\" type=\"text\" name=\"UserName\"\n          [formControl]=\"ionicForm.controls['UserName']\" class=\"order_no_txt\"></ion-input>\n          <span class=\"error-wrap\" *ngIf=\"ionicForm.get('UserName').touched || ionicForm.get('UserName').dirty\">\n            <small *ngIf=\"ionicForm.get('UserName').hasError('required')\" class=\"error\">Firm Name is required.</small>\n          </span>\n        </div>\n      </form>\n    </div>\n    <ion-row class=\"cancel_save_btn\">\n      <ion-col>\n        <button ion-button class=\"cancelOrder_btn\" (click)=\"fnCancelOrder()\">Cancel</button>\n\n      </ion-col>\n\n      <ion-col>\n        <button ion-button class=\"download_btn\" (click)=\"fnSave()\">Save</button>\n      </ion-col>\n    </ion-row>\n  </div>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/edit-profile/edit-profile-routing.module.ts":
  /*!*************************************************************!*\
    !*** ./src/app/edit-profile/edit-profile-routing.module.ts ***!
    \*************************************************************/

  /*! exports provided: EditProfilePageRoutingModule */

  /***/
  function srcAppEditProfileEditProfileRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EditProfilePageRoutingModule", function () {
      return EditProfilePageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _edit_profile_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./edit-profile.page */
    "./src/app/edit-profile/edit-profile.page.ts");

    var routes = [{
      path: '',
      component: _edit_profile_page__WEBPACK_IMPORTED_MODULE_3__["EditProfilePage"]
    }];

    var EditProfilePageRoutingModule = function EditProfilePageRoutingModule() {
      _classCallCheck(this, EditProfilePageRoutingModule);
    };

    EditProfilePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], EditProfilePageRoutingModule);
    /***/
  },

  /***/
  "./src/app/edit-profile/edit-profile.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/edit-profile/edit-profile.module.ts ***!
    \*****************************************************/

  /*! exports provided: EditProfilePageModule */

  /***/
  function srcAppEditProfileEditProfileModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EditProfilePageModule", function () {
      return EditProfilePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _edit_profile_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./edit-profile-routing.module */
    "./src/app/edit-profile/edit-profile-routing.module.ts");
    /* harmony import */


    var _edit_profile_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./edit-profile.page */
    "./src/app/edit-profile/edit-profile.page.ts");

    var EditProfilePageModule = function EditProfilePageModule() {
      _classCallCheck(this, EditProfilePageModule);
    };

    EditProfilePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _edit_profile_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditProfilePageRoutingModule"]],
      declarations: [_edit_profile_page__WEBPACK_IMPORTED_MODULE_6__["EditProfilePage"]]
    })], EditProfilePageModule);
    /***/
  },

  /***/
  "./src/app/edit-profile/edit-profile.page.scss":
  /*!*****************************************************!*\
    !*** ./src/app/edit-profile/edit-profile.page.scss ***!
    \*****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppEditProfileEditProfilePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".menu_btn {\n  color: #E4322E;\n}\n\n.main-title {\n  text-align: center;\n  color: #E4322E;\n}\n\n.avtar {\n  text-align: center;\n}\n\n.error-wrap {\n  color: red;\n  font-size: 16px;\n  float: left;\n  margin-top: 3px;\n}\n\n.img {\n  vertical-align: middle;\n  width: 9rem;\n  height: 9rem;\n  border-radius: 50%;\n  margin-top: 15px;\n}\n\n.profile-txt {\n  color: #E4322E;\n}\n\n.order-no-bg {\n  background-color: #f5f0f0;\n  width: 90%;\n  height: 45px;\n  margin-left: 20px;\n  border-radius: 7px;\n  margin-top: 20px;\n}\n\n.order_no_txt {\n  text-align: start;\n  color: #010944;\n  margin-left: 10px;\n}\n\n.cancel_save_btn {\n  margin-top: 8%;\n  margin-bottom: 8px;\n}\n\n.cancel_save_btn .cancelOrder_btn {\n  background-color: transparent;\n  color: #E4322E;\n  font-size: 20px;\n  height: 40px;\n  width: 85%;\n  border-radius: 10px;\n  display: block;\n  margin: auto;\n  border: 1px solid #E4322E;\n  margin-left: 16px;\n  margin-top: 3px;\n}\n\n.cancel_save_btn .download_btn {\n  background-color: #E4322E;\n  color: #fff;\n  font-size: 20px;\n  height: 40px;\n  width: 85%;\n  border-radius: 10px;\n  display: block;\n  margin: auto;\n  border: 1px solid #fff;\n  margin-left: 12px;\n  margin-top: 3px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9lZGl0LXByb2ZpbGUvZWRpdC1wcm9maWxlLnBhZ2Uuc2NzcyIsInNyYy9hcHAvZWRpdC1wcm9maWxlL2VkaXQtcHJvZmlsZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxjQUFBO0FDQ0Y7O0FEQ0E7RUFDRyxrQkFBQTtFQUNBLGNBQUE7QUNFSDs7QURBQztFQUNFLGtCQUFBO0FDR0g7O0FEREM7RUFDQyxVQUFBO0VBQ0UsZUFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0FDSUo7O0FERkM7RUFDQyxzQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQyxnQkFBQTtBQ0tIOztBREhDO0VBQ0UsY0FBQTtBQ01IOztBREhDO0VBQ0UseUJBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQ01IOztBREpBO0VBQ0csaUJBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUNPSDs7QURMQTtFQUNFLGNBQUE7RUFDQSxrQkFBQTtBQ1FGOztBRFBJO0VBQ0UsNkJBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLHlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0FDU047O0FEUEk7RUFDRSx5QkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUNTTiIsImZpbGUiOiJzcmMvYXBwL2VkaXQtcHJvZmlsZS9lZGl0LXByb2ZpbGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1lbnVfYnRue1xuICBjb2xvcjogI0U0MzIyRTtcbn1cbi5tYWluLXRpdGxle1xuICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgY29sb3I6ICNFNDMyMkU7XG4gfVxuIC5hdnRhcntcbiAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiB9XG4gLmVycm9yLXdyYXB7XG4gIGNvbG9yOiByZWQ7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIGZsb2F0OiBsZWZ0O1xuICAgIG1hcmdpbi10b3A6IDNweDsgIFxufVxuIC5pbWd7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIHdpZHRoOiA5cmVtO1xuICBoZWlnaHQ6IDlyZW07XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgIG1hcmdpbi10b3A6IDE1cHg7ICBcbiB9XG4gLnByb2ZpbGUtdHh0e1xuICAgY29sb3I6ICNFNDMyMkU7XG5cbiB9XG4gLm9yZGVyLW5vLWJne1xuICAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjBmMDtcbiAgIHdpZHRoOiA5MCU7XG4gICBoZWlnaHQ6IDQ1cHg7XG4gICBtYXJnaW4tbGVmdDogMjBweDtcbiAgIGJvcmRlci1yYWRpdXM6IDdweDtcbiAgIG1hcmdpbi10b3A6IDIwcHg7XG59XG4ub3JkZXJfbm9fdHh0e1xuICAgdGV4dC1hbGlnbjogc3RhcnQ7XG4gICBjb2xvcjogIzAxMDk0NDtcbiAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuLmNhbmNlbF9zYXZlX2J0bntcbiAgbWFyZ2luLXRvcDogOCU7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbiAgICAuY2FuY2VsT3JkZXJfYnRue1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjp0cmFuc3BhcmVudDtcbiAgICAgIGNvbG9yOiAjRTQzMjJFO1xuICAgICAgZm9udC1zaXplOiAyMHB4O1xuICAgICAgaGVpZ2h0OiA0MHB4O1xuICAgICAgd2lkdGg6IDg1JTtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgIG1hcmdpbjogYXV0bztcbiAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNFNDMyMkU7XG4gICAgICBtYXJnaW4tbGVmdDogMTZweDtcbiAgICAgIG1hcmdpbi10b3A6IDNweDtcbiAgICB9XG4gICAgLmRvd25sb2FkX2J0bntcbiAgICAgIGJhY2tncm91bmQtY29sb3I6ICNFNDMyMkU7XG4gICAgICBjb2xvcjogI2ZmZjtcbiAgICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICAgIGhlaWdodDogNDBweDtcbiAgICAgIHdpZHRoOiA4NSU7XG4gICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgICBtYXJnaW46IGF1dG87XG4gICAgICBib3JkZXI6IDFweCBzb2xpZCAjZmZmO1xuICAgICAgbWFyZ2luLWxlZnQ6IDEycHg7XG4gICAgICBtYXJnaW4tdG9wOiAzcHg7XG4gICAgfVxufSIsIi5tZW51X2J0biB7XG4gIGNvbG9yOiAjRTQzMjJFO1xufVxuXG4ubWFpbi10aXRsZSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICNFNDMyMkU7XG59XG5cbi5hdnRhciB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmVycm9yLXdyYXAge1xuICBjb2xvcjogcmVkO1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZsb2F0OiBsZWZ0O1xuICBtYXJnaW4tdG9wOiAzcHg7XG59XG5cbi5pbWcge1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICB3aWR0aDogOXJlbTtcbiAgaGVpZ2h0OiA5cmVtO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIG1hcmdpbi10b3A6IDE1cHg7XG59XG5cbi5wcm9maWxlLXR4dCB7XG4gIGNvbG9yOiAjRTQzMjJFO1xufVxuXG4ub3JkZXItbm8tYmcge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmMGYwO1xuICB3aWR0aDogOTAlO1xuICBoZWlnaHQ6IDQ1cHg7XG4gIG1hcmdpbi1sZWZ0OiAyMHB4O1xuICBib3JkZXItcmFkaXVzOiA3cHg7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG59XG5cbi5vcmRlcl9ub190eHQge1xuICB0ZXh0LWFsaWduOiBzdGFydDtcbiAgY29sb3I6ICMwMTA5NDQ7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuXG4uY2FuY2VsX3NhdmVfYnRuIHtcbiAgbWFyZ2luLXRvcDogOCU7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn1cbi5jYW5jZWxfc2F2ZV9idG4gLmNhbmNlbE9yZGVyX2J0biB7XG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xuICBjb2xvcjogI0U0MzIyRTtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBoZWlnaHQ6IDQwcHg7XG4gIHdpZHRoOiA4NSU7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW46IGF1dG87XG4gIGJvcmRlcjogMXB4IHNvbGlkICNFNDMyMkU7XG4gIG1hcmdpbi1sZWZ0OiAxNnB4O1xuICBtYXJnaW4tdG9wOiAzcHg7XG59XG4uY2FuY2VsX3NhdmVfYnRuIC5kb3dubG9hZF9idG4ge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTQzMjJFO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBoZWlnaHQ6IDQwcHg7XG4gIHdpZHRoOiA4NSU7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW46IGF1dG87XG4gIGJvcmRlcjogMXB4IHNvbGlkICNmZmY7XG4gIG1hcmdpbi1sZWZ0OiAxMnB4O1xuICBtYXJnaW4tdG9wOiAzcHg7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/edit-profile/edit-profile.page.ts":
  /*!***************************************************!*\
    !*** ./src/app/edit-profile/edit-profile.page.ts ***!
    \***************************************************/

  /*! exports provided: EditProfilePage */

  /***/
  function srcAppEditProfileEditProfilePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EditProfilePage", function () {
      return EditProfilePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../auth.service */
    "./src/app/auth.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic-native/camera/ngx */
    "./node_modules/@ionic-native/camera/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../../environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _global_foo_service_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../global-foo-service.service */
    "./src/app/global-foo-service.service.ts");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");

    var EditProfilePage = /*#__PURE__*/function () {
      function EditProfilePage(location, globalFooService, camera, platform, actionsheetCtrl, formbulider, navCtrl, menu, auth, toast) {
        _classCallCheck(this, EditProfilePage);

        this.location = location;
        this.globalFooService = globalFooService;
        this.camera = camera;
        this.platform = platform;
        this.actionsheetCtrl = actionsheetCtrl;
        this.formbulider = formbulider;
        this.navCtrl = navCtrl;
        this.menu = menu;
        this.auth = auth;
        this.toast = toast;
        this.selectImage = false;
        this.menu.enable(true);
        this.user_id = localStorage.getItem("id");
        console.log(this.user_id);
        this.user_id1 = localStorage.getItem("user_id");
        console.log(this.user_id1);
        this.role = localStorage.getItem("role");
        console.log(this.role);
        this.ionicForm = this.formbulider.group({
          Name: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]],
          Email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$')]],
          UserName: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]]
        });
      }

      _createClass(EditProfilePage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.getDetails();
        }
      }, {
        key: "getDetails",
        value: function getDetails() {
          var _this = this;

          this.requestObject = {
            "user_id": this.user_id
          };
          console.log(this.requestObject);
          this.auth.showLoader();
          this.auth.getUsersDetails(this.requestObject).subscribe(function (data) {
            _this.auth.hideLoader();

            console.log(data);
            _this.AllUserArray = data.data;

            if (_this.AllUserArray.photo === null) {
              _this.photos = '';
            } else {
              _this.photos = _environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].file_url + "assets/uploads/users/" + _this.AllUserArray.photo;
            }

            _this.ionicForm.controls.Name.setValue(_this.AllUserArray.name);

            _this.ionicForm.controls.Email.setValue(_this.AllUserArray.email);

            _this.ionicForm.controls.UserName.setValue(_this.AllUserArray.firm_name);
          }, function (err) {
            _this.auth.hideLoader();

            console.log("Error=>", err);
          });
        }
      }, {
        key: "fnSave",
        value: function fnSave() {
          var _this2 = this;

          if (this.ionicForm.invalid) {
            console.log('invalid');
            this.ionicForm.get('Name').markAllAsTouched();
            this.ionicForm.get('Email').markAsTouched();
            this.ionicForm.get('UserName').markAsTouched();
            return false;
          }

          console.log('ok');
          this.requestObject = {
            "user_id": this.user_id,
            "name": this.ionicForm.get('Name').value,
            "email": this.ionicForm.get('Email').value,
            "firm_name": this.ionicForm.get('UserName').value,
            "image": this.base64Image !== '' ? this.base64Image : ''
          };
          console.log(this.requestObject);
          this.auth.showLoader();
          console.log(this.requestObject);
          this.auth.editProfile(this.requestObject).subscribe(function (data) {
            _this2.auth.hideLoader();

            console.log(data);
            _this2.AllUserArray = data;

            if (_this2.AllUserArray.status == true) {
              if (_this2.AllUserArray.data.photo !== null && _this2.AllUserArray.data.photo !== '') {
                localStorage.setItem("photos", _environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].file_url + "assets/uploads/users/" + _this2.AllUserArray.data.photo);
              } else {
                localStorage.setItem("photos", '');
              }

              _this2.auth.showToast('Profile Updated Successfully');

              if (_this2.role == 'Customer') {
                _this2.navCtrl.navigateRoot('/dashboard');

                _this2.rootPage = '/dashboard';
              } else if (_this2.role == 'DeliveryBoy') {
                _this2.navCtrl.navigateRoot('my-account');

                _this2.rootPage = '/my-account';
              } else if (_this2.role == 'Salesman') {
                _this2.rootPage = '/sales-dashboard';

                _this2.navCtrl.navigateRoot('sales-dashboard');
              } else {
                _this2.auth.showToast('Profile Not update ');
              } // window.location.reload();


              _this2.globalFooService.publishSomeData({
                rootPage: _this2.rootPage,
                name: _this2.ionicForm.get('Name').value,
                role: _this2.role,
                email: _this2.ionicForm.get('Email').value,
                photo: _this2.AllUserArray.data.photo !== null && _this2.AllUserArray.data.photo !== '' ? _environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].file_url + "assets/uploads/users/" + _this2.AllUserArray.data.photo : ''
              });
            } else {
              _this2.auth.showToast('Profile Not update ');
            }
          }, function (err) {
            _this2.auth.hideLoader();

            console.log("Error=>", err);
          });
        }
      }, {
        key: "fnCancelOrder",
        value: function fnCancelOrder() {
          if (this.role == 'Customer') {
            this.navCtrl.navigateRoot('/dashboard');
          } else if (this.role == 'Salesman') {
            this.navCtrl.navigateRoot('/sales-dashboard');
          } else {
            this.navCtrl.navigateRoot('/my-account');
          }
        }
      }, {
        key: "fnBackToYourCart",
        value: function fnBackToYourCart() {
          if (this.role == 'Customer') {
            this.navCtrl.navigateRoot('/dashboard');
          } else if (this.role == 'Salesman') {
            this.navCtrl.navigateRoot('/sales-dashboard');
          } else {
            this.navCtrl.navigateRoot('/my-account');
          }
        }
      }, {
        key: "presentActionSheet",
        value: function presentActionSheet() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this3 = this;

            var actionSheet;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.actionsheetCtrl.create({
                      header: 'Please Select',
                      cssClass: 'my-custom-class',
                      buttons: [{
                        text: 'Take photo',
                        role: 'destructive',
                        icon: !this.platform.is('ios') ? 'camera-outline' : 'camera-outline',
                        handler: function handler() {
                          _this3.captureImage(false);
                        }
                      }, {
                        text: 'Choose photo from Gallery',
                        icon: !this.platform.is('ios') ? 'images-outline' : 'mages-outline',
                        handler: function handler() {
                          _this3.captureImage(true);
                        }
                      }, {
                        text: 'Cancel',
                        icon: 'close',
                        role: 'cancel',
                        handler: function handler() {
                          console.log('Cancel clicked');
                        }
                      }]
                    });

                  case 2:
                    actionSheet = _context.sent;
                    _context.next = 5;
                    return actionSheet.present();

                  case 5:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "captureImage",
        value: function captureImage(useAlbum) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var options, imageData;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    options = Object.assign({
                      quality: 100,
                      destinationType: this.camera.DestinationType.DATA_URL,
                      encodingType: this.camera.EncodingType.JPEG,
                      mediaType: this.camera.MediaType.PICTURE
                    }, useAlbum ? {
                      sourceType: this.camera.PictureSourceType.SAVEDPHOTOALBUM
                    } : {});
                    _context2.next = 3;
                    return this.camera.getPicture(options);

                  case 3:
                    imageData = _context2.sent;
                    this.base64Image = "data:image/jpeg;base64,".concat(imageData);
                    console.log(this.base64Image);
                    this.photos = this.base64Image;

                    if (this.base64Image) {
                      this.selectImage = true;
                    } else {
                      this.selectImage = false;
                    }

                  case 8:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.location.back();
        }
      }]);

      return EditProfilePage;
    }();

    EditProfilePage.ctorParameters = function () {
      return [{
        type: _angular_common__WEBPACK_IMPORTED_MODULE_8__["Location"]
      }, {
        type: _global_foo_service_service__WEBPACK_IMPORTED_MODULE_7__["GlobalFooServiceService"]
      }, {
        type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_5__["Camera"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ActionSheetController"]
      }, {
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"]
      }, {
        type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }];
    };

    EditProfilePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-edit-profile',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./edit-profile.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/edit-profile/edit-profile.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./edit-profile.page.scss */
      "./src/app/edit-profile/edit-profile.page.scss"))["default"]]
    })], EditProfilePage);
    /***/
  }
}]);
//# sourceMappingURL=edit-profile-edit-profile-module-es5.js.map