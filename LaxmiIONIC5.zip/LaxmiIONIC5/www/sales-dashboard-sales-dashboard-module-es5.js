function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["sales-dashboard-sales-dashboard-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/sales-dashboard/sales-dashboard.page.html":
  /*!*************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sales-dashboard/sales-dashboard.page.html ***!
    \*************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSalesDashboardSalesDashboardPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\" class=\"menu_btn\">\n      <ion-menu-button auto-hide=\"false\"></ion-menu-button>\n    </ion-buttons>\n\n    <ion-title class=\"main-title\">Dashboard</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n  <ion-grid class=\"header-content\">\n    <p class=\"p-label\">Welcome {{userName}}!</p>\n  </ion-grid>\n\n  <ion-row style=\"margin-top: 12px;\">\n    <p class=\"order-status\"><b>Order Status</b></p>\n    <ion-col>\n      <ion-item lines=\"none\" style=\"float: right;\">\n        <ion-select #item class=\"custom-options customer-filter\" [(ngModel)]=\"selecTextStatus.select\"\n          (ionChange)=\"OnChange(item.value)\">\n\n          <ion-select-option value=\"New\">New</ion-select-option>\n          <ion-select-option value=\"Approve\">Approved</ion-select-option>\n          <ion-select-option value=\"Assigned\">Assigned</ion-select-option>\n          <ion-select-option value=\"Pickup\">Pickup</ion-select-option>\n          <ion-select-option value=\"Delivered\">Delivered</ion-select-option>\n          <ion-select-option value=\"Reject\">Rejected</ion-select-option>\n        </ion-select>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n\n\n  <div *ngFor=\"let item of ordersList;\">\n    <ion-card class=\"card-content\">\n      <ion-item *ngIf='item.customer_details!==null'>\n        <ion-avatar slot=\"start\" *ngIf=\"item.customer_details.photo && item.customer_details.photo!==null\">\n          <img src=\"{{url.file_url}}assets/uploads/users/{{item.customer_details.photo}}\">\n        </ion-avatar>\n        <ion-avatar slot=\"start\" *ngIf=\"item.customer_details.photo === null || item.customer_details.photo ===''\">\n          <img src=\"../../assets/imgs/avatar1.png\">\n        </ion-avatar>\n        <ion-label>\n          <h3>{{item.customer_details.name}}</h3>\n          <p>{{item.customer_details.phone}}</p>\n        </ion-label>\n        <ion-label slot=\"end\">\n\n          <div class=\"ion-text-end\" *ngIf=\"item.order_details.status == 'New'\">\n            <ion-icon (click)=\"fnSelectDriver(item.order_details.id,item.order_details.status)\"\n              name=\"ellipsis-vertical\"></ion-icon>\n          </div>\n        </ion-label>\n      </ion-item>\n      <div (click)=\"fnGotoDetails(item)\">\n        <ion-row style=\"margin-top: 15px;\">\n          <p class=\"p-order\"><b>Order #{{item.order_details.order_number}}</b></p>\n          <ion-col>\n            <!-- <button ion-button class=\"Pending_btn\">{{item.status}}</button> -->\n            <button ion-button *ngIf=\"item.order_details.status == 'New'\" class=\"Pending_btn\">Pending</button>\n            <button ion-button *ngIf=\"item.order_details.status == 'Assigned'\" class=\"Pending_btn\">Assigned</button>\n            <button ion-button *ngIf=\"item.order_details.status == 'Approve'\" class=\"Pending_btn\">Approve</button>\n            <button ion-button *ngIf=\"item.order_details.status == 'cancel'\" class=\"Pending_btn\">Cancel</button>\n            <button ion-button *ngIf=\"item.order_details.status == 'Pickup'\" class=\"Pending_btn\">Pickup</button>\n            <button ion-button *ngIf=\"item.order_details.status == 'Delivered'\" class=\"Pending_btn\">Delivered</button>\n            <button ion-button *ngIf=\"item.order_details.status == 'Completed'\" class=\"Pending_btn\">Completed</button>\n            <button ion-button *ngIf=\"item.order_details.status == 'Reject'\" class=\"Pending_btn\">Rejected</button>\n          </ion-col>\n        </ion-row>\n        <p class=\"p-date\"><b>Date: </b>{{item.order_details.create_at | date: 'dd-MM-yyyy'}}</p>\n      </div>\n    </ion-card>\n\n    <ion-card\n      *ngIf=\"item.customer_details!==null && item.customer_details.address!==null && item.customer_details.address!==''\"\n      class=\"card-content-address\">\n      <ion-row style=\"font-size: 16px; font-weight: bold;\">\n        <ion-col size=\"1\">\n          <img src=\"../../assets/imgs/location.png\" class=\"img\">\n        </ion-col>\n        <ion-col size=\"11\">\n          {{item.customer_details.address}}\n        </ion-col>\n      </ion-row>\n    </ion-card>\n\n  </div>\n\n\n\n  <!--  <ion-card *ngFor=\"let item of ordersList;\">\n    <ion-item *ngIf='item.customer_details!==null'>\n      <ion-avatar slot=\"start\">\n        <img src=\"../../assets/imgs/avatar1.png\">\n      </ion-avatar>\n      <ion-label>\n        <h3>{{item.customer_details.name}}</h3>\n        <p>{{item.customer_details.phone}}</p>\n      </ion-label>\n      <ion-label slot=\"end\" *ngIf=\"item.order_details!==null\">\n        <h3>Status: {{item.order_details.status}}</h3>\n      </ion-label>\n    </ion-item>\n\n    <ion-card-header *ngIf=\"item.order_details!==null\">\n      <ion-card-title>Order ID: <span>{{item.order_details.order_number}}</span></ion-card-title>\n    </ion-card-header>\n    <ion-card-content>\n      <ion-row *ngIf=\"item.order_details!==null\">\n        <ion-col size=\"6\">\n          <h4 class=\"p-price\">Amount: ₹{{item.order_details.order_total | number:'1.0-0'}}</h4>\n        </ion-col>\n\n        <ion-col class=\"ion-text-end\">\n          <h6 class=\"p-date\">Date: {{item.order_details.create_at | date: 'dd-MM-yyyy' }}</h6>\n        </ion-col>\n\n      </ion-row>\n\n    </ion-card-content>\n -->\n  <!-- <ion-footer>\n      <ion-row *ngIf=\"item.order_details!==null\">\n        <ion-col size=\"4\" center class=\"ion-text-start\">\n          <ion-button (click)=\"fnAcceptAlert(item.order_details.id,'Approve')\">\n            <ion-icon name=\"pencil\"></ion-icon>\n          </ion-button>\n\n        </ion-col>\n        <ion-col size=\"4\" center class=\"ion-text-center\">\n          <ion-button (click)=\"fnAcceptAlert(item.order_details.id,'Reject')\">\n            <ion-icon name=\"close\"></ion-icon>\n          </ion-button>\n        </ion-col>\n        <ion-col size=\"4\" center class=\"ion-text-end\">\n          <ion-button (click)=\"fnGotoDetails(item)\">\n            <ion-icon name=\"eye\"></ion-icon>\n          </ion-button>\n        </ion-col>\n      </ion-row>\n    </ion-footer> -->\n  <!-- </ion-card> -->\n  <div *ngIf=\"!ordersList?.length > 0\">\n    <p class=\"norecord-label\">No Records Found</p>\n  </div>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/sales-dashboard/sales-dashboard-routing.module.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/sales-dashboard/sales-dashboard-routing.module.ts ***!
    \*******************************************************************/

  /*! exports provided: SalesDashboardPageRoutingModule */

  /***/
  function srcAppSalesDashboardSalesDashboardRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SalesDashboardPageRoutingModule", function () {
      return SalesDashboardPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _sales_dashboard_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./sales-dashboard.page */
    "./src/app/sales-dashboard/sales-dashboard.page.ts");

    var routes = [{
      path: '',
      component: _sales_dashboard_page__WEBPACK_IMPORTED_MODULE_3__["SalesDashboardPage"]
    }];

    var SalesDashboardPageRoutingModule = function SalesDashboardPageRoutingModule() {
      _classCallCheck(this, SalesDashboardPageRoutingModule);
    };

    SalesDashboardPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], SalesDashboardPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/sales-dashboard/sales-dashboard.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/sales-dashboard/sales-dashboard.module.ts ***!
    \***********************************************************/

  /*! exports provided: SalesDashboardPageModule */

  /***/
  function srcAppSalesDashboardSalesDashboardModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SalesDashboardPageModule", function () {
      return SalesDashboardPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _sales_dashboard_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./sales-dashboard-routing.module */
    "./src/app/sales-dashboard/sales-dashboard-routing.module.ts");
    /* harmony import */


    var _sales_dashboard_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./sales-dashboard.page */
    "./src/app/sales-dashboard/sales-dashboard.page.ts");

    var SalesDashboardPageModule = function SalesDashboardPageModule() {
      _classCallCheck(this, SalesDashboardPageModule);
    };

    SalesDashboardPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _sales_dashboard_routing_module__WEBPACK_IMPORTED_MODULE_5__["SalesDashboardPageRoutingModule"]],
      declarations: [_sales_dashboard_page__WEBPACK_IMPORTED_MODULE_6__["SalesDashboardPage"]]
    })], SalesDashboardPageModule);
    /***/
  },

  /***/
  "./src/app/sales-dashboard/sales-dashboard.page.scss":
  /*!***********************************************************!*\
    !*** ./src/app/sales-dashboard/sales-dashboard.page.scss ***!
    \***********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSalesDashboardSalesDashboardPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".menu_btn {\n  color: #E4322E;\n}\n\n.main-title {\n  text-align: center;\n  color: #E4322E;\n  margin-right: 43px;\n}\n\n.header-content {\n  background-color: #E4322E;\n}\n\n.p-label {\n  color: #fff;\n  margin: 30px 0 30px 10px;\n  font-size: 1.3rem;\n}\n\n.card-content {\n  margin-top: 12%;\n  background-color: #fff;\n  height: 17%;\n  margin-bottom: 1px;\n}\n\n.p-order {\n  color: #000;\n  margin-bottom: 0px;\n  margin-left: 10px;\n  font-size: 16px;\n}\n\n.Pending_btn {\n  background-color: #E4322E;\n  float: right;\n  color: #fff;\n  font-size: 16px;\n  height: 33px;\n  width: 80%;\n  border-radius: 8px;\n  display: block;\n  margin: auto;\n  border: 1px solid #fff;\n  margin-right: 6px;\n}\n\n.p-date {\n  margin-top: 0px;\n  margin-left: 10px;\n  color: #000;\n}\n\n.card-content-address {\n  margin-top: 0;\n  background-color: #fff;\n}\n\n.add-txt {\n  text-align: center;\n}\n\n.img {\n  margin-right: 10px;\n}\n\n.order-status {\n  color: black;\n  font-size: 18px;\n  margin-left: 20px;\n  margin-bottom: 5px;\n}\n\nion-select {\n  max-width: 117px;\n  border: 1px solid #E4322E;\n  border-radius: 9px;\n  padding: 9px;\n}\n\n.customer-filter {\n  padding: 0;\n}\n\n.customer-filter .select-icon {\n  width: 30px !important;\n  height: 30px !important;\n  background-color: red !important;\n  display: flex !important;\n  justify-content: center !important;\n}\n\n.customer-filter {\n  width: 160px;\n  max-width: 160px;\n  height: 40px;\n}\n\n.customer-filter::part(text) {\n  padding: 0 10px;\n  font-size: 17px;\n  font-family: open sans;\n}\n\n.customer-filter::part(icon) {\n  width: 45px !important;\n  height: 40px !important;\n  background-color: #E4322E !important;\n  display: flex !important;\n  justify-content: center !important;\n  opacity: 1;\n  align-items: center;\n}\n\n.customer-filter::part(icon) * {\n  display: none;\n}\n\n.customer-filter::part(icon)::after {\n  content: \"\";\n  background-image: url(\"/../../assets/imgs/down-arrow.png\");\n  width: 35px;\n  height: 18px;\n  background-position: center;\n  background-color: #e4322e;\n  z-index: 1;\n  background-size: 70%;\n  background-repeat: no-repeat;\n}\n\n.norecord-label {\n  font-family: open sans;\n  color: #E4322E;\n  font-size: 18px;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9zYWxlcy1kYXNoYm9hcmQvc2FsZXMtZGFzaGJvYXJkLnBhZ2Uuc2NzcyIsInNyYy9hcHAvc2FsZXMtZGFzaGJvYXJkL3NhbGVzLWRhc2hib2FyZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0FDQ0o7O0FEQ0E7RUFDSSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQ0VKOztBREFDO0VBRUcseUJBQUE7QUNFSjs7QURBQztFQUNJLFdBQUE7RUFDQSx3QkFBQTtFQUNBLGlCQUFBO0FDR0w7O0FEREM7RUFFRyxlQUFBO0VBQ0Esc0JBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7QUNHSjs7QUREQztFQUNHLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtBQ0lKOztBREZDO0VBQ0cseUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0FDS0o7O0FESEE7RUFDSSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxXQUFBO0FDTUo7O0FESkE7RUFFSSxhQUFBO0VBQ0Esc0JBQUE7QUNNSjs7QURKQTtFQUNJLGtCQUFBO0FDT0o7O0FETEE7RUFDSSxrQkFBQTtBQ1FKOztBRE5BO0VBQ0ksWUFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FDU0o7O0FEUEE7RUFDSSxnQkFBQTtFQUNBLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FDVUo7O0FEUkE7RUFDSSxVQUFBO0FDV0o7O0FEVkk7RUFDSSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsZ0NBQUE7RUFDQSx3QkFBQTtFQUNBLGtDQUFBO0FDWVI7O0FEVEE7RUFDSSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0FDWUo7O0FEVkE7RUFDSSxlQUFBO0VBQ0EsZUFBQTtFQUNBLHNCQUFBO0FDYUo7O0FEWEE7RUFDUSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0Esb0NBQUE7RUFDQSx3QkFBQTtFQUNBLGtDQUFBO0VBQ0EsVUFBQTtFQUNBLG1CQUFBO0FDY1I7O0FEYlE7RUFDSSxhQUFBO0FDZVo7O0FEYkk7RUFDSSxXQUFBO0VBQ0EsMERBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLDJCQUFBO0VBQ0EseUJBQUE7RUFDQSxVQUFBO0VBQ0Esb0JBQUE7RUFDQSw0QkFBQTtBQ2VSOztBRFhBO0VBQ0ksc0JBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FDY0oiLCJmaWxlIjoic3JjL2FwcC9zYWxlcy1kYXNoYm9hcmQvc2FsZXMtZGFzaGJvYXJkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tZW51X2J0bntcbiAgICBjb2xvcjogI0U0MzIyRTtcbn1cbi5tYWluLXRpdGxle1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogI0U0MzIyRTtcbiAgICBtYXJnaW4tcmlnaHQ6IDQzcHg7XG4gfVxuIC5oZWFkZXItY29udGVudHtcbiAgICAvLyBib3gtc2hhZG93OiA1cHggN3B4IDEwcHggNXB4ICNlOGU4ZTg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0U0MzIyRTtcbiB9XG4gLnAtbGFiZWx7XG4gICAgIGNvbG9yIDojZmZmO1xuICAgICBtYXJnaW46IDMwcHggMCAzMHB4IDEwcHg7XG4gICAgIGZvbnQtc2l6ZTogMS4zcmVtO1xuIH1cbiAuY2FyZC1jb250ZW50e1xuICAgIC8vIGJveC1zaGFkb3c6IDVweCA3cHggMTBweCA1cHggI2U4ZThlODtcbiAgICBtYXJnaW4tdG9wOiAxMiU7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgICBoZWlnaHQ6IDE3JTtcbiAgICBtYXJnaW4tYm90dG9tOiAxcHg7XG4gfVxuIC5wLW9yZGVye1xuICAgIGNvbG9yOiAjMDAwO1xuICAgIG1hcmdpbi1ib3R0b206IDBweDtcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gfVxuIC5QZW5kaW5nX2J0bntcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTQzMjJFO1xuICAgIGZsb2F0OiByaWdodDtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgaGVpZ2h0OiAzM3B4O1xuICAgIHdpZHRoOiA4MCU7XG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIG1hcmdpbjogYXV0bztcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZmZmO1xuICAgIG1hcmdpbi1yaWdodDogNnB4O1xufVxuLnAtZGF0ZXtcbiAgICBtYXJnaW4tdG9wOiAwcHg7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgY29sb3I6ICMwMDA7XG59XG4uY2FyZC1jb250ZW50LWFkZHJlc3N7XG4gICAgLy8gYm94LXNoYWRvdzogNXB4IDdweCAxMHB4IDVweCAjZThlOGU4O1xuICAgIG1hcmdpbi10b3A6IDA7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbn1cbi5hZGQtdHh0e1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5pbWd7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuLm9yZGVyLXN0YXR1c3tcbiAgICBjb2xvcjogYmxhY2s7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDVweDtcbn1cbmlvbi1zZWxlY3R7XG4gICAgbWF4LXdpZHRoOiAxMTdweDtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjRTQzMjJFO1xuICAgIGJvcmRlci1yYWRpdXM6IDlweDtcbiAgICBwYWRkaW5nOiA5cHg7XG59XG4uY3VzdG9tZXItZmlsdGVye1xuICAgIHBhZGRpbmc6IDA7XG4gICAgLnNlbGVjdC1pY29ue1xuICAgICAgICB3aWR0aDogMzBweCAhaW1wb3J0YW50O1xuICAgICAgICBoZWlnaHQ6IDMwcHggIWltcG9ydGFudDtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmVkICFpbXBvcnRhbnQ7XG4gICAgICAgIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXIgIWltcG9ydGFudDtcbiAgICB9XG59XG4uY3VzdG9tZXItZmlsdGVye1xuICAgIHdpZHRoOiAxNjBweDtcbiAgICBtYXgtd2lkdGg6IDE2MHB4O1xuICAgIGhlaWdodDogNDBweDtcbn1cbi5jdXN0b21lci1maWx0ZXI6OnBhcnQodGV4dCl7XG4gICAgcGFkZGluZzogMCAxMHB4O1xuICAgIGZvbnQtc2l6ZTogMTdweDtcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuLmN1c3RvbWVyLWZpbHRlcjo6cGFydChpY29uKSB7XG4gICAgICAgIHdpZHRoOiA0NXB4ICFpbXBvcnRhbnQ7XG4gICAgICAgIGhlaWdodDogNDBweCAhaW1wb3J0YW50O1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTQzMjJFICFpbXBvcnRhbnQ7XG4gICAgICAgIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXIgIWltcG9ydGFudDtcbiAgICAgICAgb3BhY2l0eTogMTtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgKntcbiAgICAgICAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgICAgIH1cbiAgICAmOjphZnRlcntcbiAgICAgICAgY29udGVudDogXCJcIjtcbiAgICAgICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcvLi4vLi4vYXNzZXRzL2ltZ3MvZG93bi1hcnJvdy5wbmcnKTtcbiAgICAgICAgd2lkdGg6IDM1cHg7XG4gICAgICAgIGhlaWdodDogMThweDtcbiAgICAgICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTQzMjJlO1xuICAgICAgICB6LWluZGV4OiAxO1xuICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IDcwJTtcbiAgICAgICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgICB9XG59XG5cbi5ub3JlY29yZC1sYWJlbHtcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICAgIGNvbG9yOiNFNDMyMkU7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuIiwiLm1lbnVfYnRuIHtcbiAgY29sb3I6ICNFNDMyMkU7XG59XG5cbi5tYWluLXRpdGxlIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI0U0MzIyRTtcbiAgbWFyZ2luLXJpZ2h0OiA0M3B4O1xufVxuXG4uaGVhZGVyLWNvbnRlbnQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTQzMjJFO1xufVxuXG4ucC1sYWJlbCB7XG4gIGNvbG9yOiAjZmZmO1xuICBtYXJnaW46IDMwcHggMCAzMHB4IDEwcHg7XG4gIGZvbnQtc2l6ZTogMS4zcmVtO1xufVxuXG4uY2FyZC1jb250ZW50IHtcbiAgbWFyZ2luLXRvcDogMTIlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICBoZWlnaHQ6IDE3JTtcbiAgbWFyZ2luLWJvdHRvbTogMXB4O1xufVxuXG4ucC1vcmRlciB7XG4gIGNvbG9yOiAjMDAwO1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBmb250LXNpemU6IDE2cHg7XG59XG5cbi5QZW5kaW5nX2J0biB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNFNDMyMkU7XG4gIGZsb2F0OiByaWdodDtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgaGVpZ2h0OiAzM3B4O1xuICB3aWR0aDogODAlO1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW46IGF1dG87XG4gIGJvcmRlcjogMXB4IHNvbGlkICNmZmY7XG4gIG1hcmdpbi1yaWdodDogNnB4O1xufVxuXG4ucC1kYXRlIHtcbiAgbWFyZ2luLXRvcDogMHB4O1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgY29sb3I6ICMwMDA7XG59XG5cbi5jYXJkLWNvbnRlbnQtYWRkcmVzcyB7XG4gIG1hcmdpbi10b3A6IDA7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG59XG5cbi5hZGQtdHh0IHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uaW1nIHtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuXG4ub3JkZXItc3RhdHVzIHtcbiAgY29sb3I6IGJsYWNrO1xuICBmb250LXNpemU6IDE4cHg7XG4gIG1hcmdpbi1sZWZ0OiAyMHB4O1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG59XG5cbmlvbi1zZWxlY3Qge1xuICBtYXgtd2lkdGg6IDExN3B4O1xuICBib3JkZXI6IDFweCBzb2xpZCAjRTQzMjJFO1xuICBib3JkZXItcmFkaXVzOiA5cHg7XG4gIHBhZGRpbmc6IDlweDtcbn1cblxuLmN1c3RvbWVyLWZpbHRlciB7XG4gIHBhZGRpbmc6IDA7XG59XG4uY3VzdG9tZXItZmlsdGVyIC5zZWxlY3QtaWNvbiB7XG4gIHdpZHRoOiAzMHB4ICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogMzBweCAhaW1wb3J0YW50O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZWQgIWltcG9ydGFudDtcbiAgZGlzcGxheTogZmxleCAhaW1wb3J0YW50O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlciAhaW1wb3J0YW50O1xufVxuXG4uY3VzdG9tZXItZmlsdGVyIHtcbiAgd2lkdGg6IDE2MHB4O1xuICBtYXgtd2lkdGg6IDE2MHB4O1xuICBoZWlnaHQ6IDQwcHg7XG59XG5cbi5jdXN0b21lci1maWx0ZXI6OnBhcnQodGV4dCkge1xuICBwYWRkaW5nOiAwIDEwcHg7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cblxuLmN1c3RvbWVyLWZpbHRlcjo6cGFydChpY29uKSB7XG4gIHdpZHRoOiA0NXB4ICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogNDBweCAhaW1wb3J0YW50O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTQzMjJFICFpbXBvcnRhbnQ7XG4gIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXIgIWltcG9ydGFudDtcbiAgb3BhY2l0eTogMTtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cbi5jdXN0b21lci1maWx0ZXI6OnBhcnQoaWNvbikgKiB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG4uY3VzdG9tZXItZmlsdGVyOjpwYXJ0KGljb24pOjphZnRlciB7XG4gIGNvbnRlbnQ6IFwiXCI7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi8uLi8uLi9hc3NldHMvaW1ncy9kb3duLWFycm93LnBuZ1wiKTtcbiAgd2lkdGg6IDM1cHg7XG4gIGhlaWdodDogMThweDtcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTQzMjJlO1xuICB6LWluZGV4OiAxO1xuICBiYWNrZ3JvdW5kLXNpemU6IDcwJTtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbn1cblxuLm5vcmVjb3JkLWxhYmVsIHtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgY29sb3I6ICNFNDMyMkU7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/sales-dashboard/sales-dashboard.page.ts":
  /*!*********************************************************!*\
    !*** ./src/app/sales-dashboard/sales-dashboard.page.ts ***!
    \*********************************************************/

  /*! exports provided: SalesDashboardPage */

  /***/
  function srcAppSalesDashboardSalesDashboardPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SalesDashboardPage", function () {
      return SalesDashboardPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../auth.service */
    "./src/app/auth.service.ts");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../common.service */
    "./src/app/common.service.ts");

    var SalesDashboardPage = /*#__PURE__*/function () {
      function SalesDashboardPage(commonService, actionSheetController, auth, alertCtrl, navCtrl, menu) {
        _classCallCheck(this, SalesDashboardPage);

        this.commonService = commonService;
        this.actionSheetController = actionSheetController;
        this.auth = auth;
        this.alertCtrl = alertCtrl;
        this.navCtrl = navCtrl;
        this.menu = menu;
        this.selecTextStatus = {
          select: null
        };
        this.ordersList = [];
        this.order_details = null;
        this.order_item = [];
        this.customer_details = null;
        this.driver_details = null;
        this.menu.enable(true);
        this.user_id = localStorage.getItem("id");
        this.userName = localStorage.getItem("name");
        this.selecTextStatus.select = "New";
      }

      _createClass(SalesDashboardPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.url = this.commonService.url();
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.fnGetAllOrder(this.selecTextStatus.select);
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {}
      }, {
        key: "OnChange",
        value: function OnChange(value) {
          this.status = value;
          console.log(this.status);
          this.fnGetAllOrder(value);
        }
      }, {
        key: "fnGetAllOrder",
        value: function fnGetAllOrder(status) {
          var _this = this;

          this.ordersList = [];
          var requestObject = {
            "status": status,
            "userId": this.user_id
          };
          this.auth.showLoader();
          console.log(requestObject);
          this.auth.getSalesOrders(requestObject).subscribe(function (data) {
            _this.auth.hideLoader();

            _this.ordersList = data.data;
            console.log("sales order list", _this.ordersList);
          }, function (err) {
            _this.auth.hideLoader();

            console.log("Error=>", err);
          });
        }
      }, {
        key: "fnCancelAccept",
        value: function fnCancelAccept(id, status) {
          var _this2 = this;

          var requestObject = {
            "order_id": id,
            "user_id": this.user_id,
            "order_status": status,
            "user_type": localStorage.getItem("role")
          };
          this.auth.showLoader();
          console.log(requestObject);
          this.auth.updateStatusOrder(requestObject).subscribe(function (data) {
            _this2.auth.hideLoader();

            _this2.dataResponse = data;

            _this2.auth.showToast(_this2.dataResponse.message);

            _this2.fnGetAllOrder(_this2.selecTextStatus.select);

            console.log("sales order list", _this2.ordersList);
          }, function (err) {
            _this2.auth.hideLoader();

            console.log("Error=>", err);
          });
        }
      }, {
        key: "fnGotoDetails",
        value: function fnGotoDetails(item) {
          this.navCtrl.navigateForward('sales-order-details', {
            state: item
          });
        }
      }, {
        key: "fnAcceptAlert",
        value: function fnAcceptAlert(id, status) {
          var _this3 = this;

          this.alertCtrl.create({
            header: status + ' Order',
            message: 'Are you sure you want to  ' + status + ' ?',
            backdropDismiss: false,
            buttons: [{
              text: 'Cancel',
              role: 'cancel',
              handler: function handler() {
                console.log('cancel!');
              }
            }, {
              text: 'Yes',
              handler: function handler() {
                _this3.fnCancelAccept(id, status);
              }
            }]
          }).then(function (alert) {
            alert.present();
          });
        }
      }, {
        key: "fnSelectDriver",
        value: function fnSelectDriver(orderId, status) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this4 = this;

            var actionSheet;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.actionSheetController.create({
                      header: 'Select',
                      cssClass: 'my-custom-class',
                      buttons: [{
                        text: 'Accept',
                        icon: 'checkmark',
                        handler: function handler() {
                          console.log('Accept clicked');

                          _this4.fnAcceptAlert(orderId, 'Approve');
                        }
                      }, {
                        text: 'Reject',
                        icon: 'trash',
                        handler: function handler() {
                          _this4.fnAcceptAlert(orderId, 'Reject');

                          console.log('Reject clicked');
                        }
                      }, {
                        text: 'Cancel',
                        icon: 'close',
                        role: 'cancel',
                        handler: function handler() {
                          console.log('Cancel clicked');
                        }
                      }]
                    });

                  case 2:
                    actionSheet = _context.sent;
                    _context.next = 5;
                    return actionSheet.present();

                  case 5:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "doRefresh",
        value: function doRefresh(event) {
          var _this5 = this;

          console.log('Begin async operation', event);
          setTimeout(function () {
            console.log('Async operation has ended');

            _this5.fnGetAllOrder(_this5.selecTextStatus.select);

            event.target.complete();
          }, 2000);
        }
      }]);

      return SalesDashboardPage;
    }();

    SalesDashboardPage.ctorParameters = function () {
      return [{
        type: _common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ActionSheetController"]
      }, {
        type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"]
      }];
    };

    SalesDashboardPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-sales-dashboard',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./sales-dashboard.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/sales-dashboard/sales-dashboard.page.html"))["default"],
      providers: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"]],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./sales-dashboard.page.scss */
      "./src/app/sales-dashboard/sales-dashboard.page.scss"))["default"]]
    })], SalesDashboardPage);
    /***/
  }
}]);
//# sourceMappingURL=sales-dashboard-sales-dashboard-module-es5.js.map