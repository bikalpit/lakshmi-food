(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["sales-order-details-sales-order-details-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sales-order-details/sales-order-details.page.html":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sales-order-details/sales-order-details.page.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <!-- <ion-buttons slot=\"start\" class=\"menu_btn\">\n      <ion-menu-button auto-hide=\"false\"></ion-menu-button>\n    </ion-buttons> -->\n    <ion-buttons slot=\"start\">\n      <!-- <ion-back-button (click)=\"goBack()\" color=\"danger\"></ion-back-button> -->\n      <ion-icon name=\"arrow-back-outline\" (click)=\"goBack()\" class=\"backarrow1\"></ion-icon>\n    </ion-buttons>\n    <ion-buttons slot=\"end\"> \n      <ion-button>\n\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"main-title\">Order Details</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div *ngIf=\"orderInfo\">\n\n    <ion-card class=\"main-card\">\n      <ion-grid>\n        <ion-row>\n          <ion-col>\n            <h4 class=\"p-label2\">Order # {{orderInfo.order_details.order_number}}</h4>\n          </ion-col>\n\n          <ion-col>\n            <h6 class=\"p-label\">Order Date</h6>\n          </ion-col>\n\n        </ion-row>\n      </ion-grid>\n      <ion-grid>\n        <ion-row>\n          <ion-col>\n            <!-- <h4 class=\"p-price\">{{ordersDetails.status}}</h4> -->\n            <h4 class=\"p-price\" *ngIf=\"orderInfo.order_details.status == 'New'\">Pending</h4>\n            <h4 class=\"p-price\" *ngIf=\"orderInfo.order_details.status == 'Pickup'\">Pickup</h4>\n            <h4 class=\"p-price\" *ngIf=\"orderInfo.order_details.status == 'Assigned'\">Assigned</h4>\n            <h4 class=\"p-price\" *ngIf=\"orderInfo.order_details.status == 'Approve'\">Approved</h4>\n            <h4 class=\"p-price\" *ngIf=\"orderInfo.order_details.status == 'cancel'\">Cancel</h4>\n            <h4 class=\"p-price\" *ngIf=\"orderInfo.order_details.status == 'Delivered'\">Delivered</h4>\n            <h4 class=\"p-price\" *ngIf=\"orderInfo.order_details.status == 'Reject'\">Rejected</h4>\n          </ion-col>\n\n          <ion-col>\n            <h6 class=\"p-date\">{{orderInfo.order_details.create_at | date: 'dd-MM-yyyy'}}</h6>\n          </ion-col>\n\n        </ion-row>\n      </ion-grid>\n    </ion-card>\n\n    <ion-card class=\"cust-profile\" *ngIf=\"orderInfo.customer_details!==null\">\n      <p class=\"profile-txt\"><b>Customer Profile</b></p>\n      <ion-row>\n        <ion-col size=\"4\">\n          <h4 class=\"p-label2\">Firm Name</h4>\n        </ion-col>\n\n        <ion-col size=\"8\">\n          <h6 class=\"p-label-nm\">{{orderInfo.customer_details.firm_name}}</h6>\n        </ion-col>\n\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"4\">\n          <h4 class=\"p-label2\">Name</h4>\n        </ion-col>\n\n        <ion-col size=\"8\">\n          <h6 class=\"p-label-nm\">{{orderInfo.customer_details.name}}</h6>\n        </ion-col>\n\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"4\" >\n          <h4 class=\"p-label2\">Email</h4>\n        </ion-col>\n\n        <ion-col size=\"8\">\n          <h6 class=\"p-label-nm\">{{orderInfo.customer_details.email}}</h6>\n        </ion-col>\n\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"4\">\n          <h4 class=\"p-label2\">Contact </h4>\n        </ion-col>\n\n        <ion-col size=\"8\">\n          <h6 class=\"p-label-nm\">{{orderInfo.customer_details.phone}}</h6>\n        </ion-col>\n\n      </ion-row>\n    </ion-card>\n    <ion-card class=\"main-card-item\" *ngIf=\"orderInfo.customer_details!==null\">\n      <p class=\"profile-txt\"><b>Address</b></p>\n     <!--  <h6 class=\"add-txt\"><img src=\"../../assets/imgs/location.png\"\n          class=\"img\">{{ordersDetails.address_house_no}},{{ordersDetails.address_city}}{{ordersDetails.address_state}}\n      </h6> -->\n      <ion-row style=\"font-size: 16px; font-weight: bold;\">\n        <ion-col size=\"1\">\n          <img src=\"../../assets/imgs/location.png\" class=\"img\">\n        </ion-col>\n        <ion-col size=\"11\" *ngIf=\"orderInfo.customer_details.address!==null && orderInfo.customer_details.address!=='' \" >\n            {{orderInfo.customer_details.address}}\n        </ion-col>\n        <ion-col size=\"11\" *ngIf=\"orderInfo.customer_details.address ===''\">\n         Address not available.\n      </ion-col>\n      </ion-row>\n    </ion-card>\n    <!-- <div *ngFor=\"let item of orderItem;\"> -->\n    <ion-card class=\"main-card-item\">\n      <ion-card-content>\n        <h5 class=\"p-label3\"><b>Items</b></h5>\n        <div *ngFor=\"let item of orderInfo.order_item;\" style=\"margin-top: 20px;\">\n          <h6 class=\"p-qty\">{{item.product_name}} {{item.product_weight}}Kg</h6>\n \n          <ion-row>\n            <ion-col>\n              <h6 class=\"p-qty\">Qty {{item.qty}} × ₹{{item.product_price}}</h6>\n            </ion-col>\n\n            <h6 class=\"p-label4\">₹{{item.price}}</h6>\n          </ion-row>\n        </div>\n      </ion-card-content>\n    </ion-card>\n\n    <ion-card class=\"main-card-item\" *ngIf=\"orderInfo.driver_details && orderInfo.driver_details!==null\">\n      <ion-card-header>\n        <ion-card-title>Delivery Boy</ion-card-title>\n      </ion-card-header>\n      <ion-item>\n        <ion-avatar slot=\"start\">\n          <img src=\"../../assets/imgs/avatar1.png\">\n        </ion-avatar>\n        <ion-label>\n          <h3>{{orderInfo.driver_details.name}}</h3>\n          <p>{{orderInfo.driver_details.phone}}</p>\n        </ion-label>\n      </ion-item>\n      <ion-card-content>\n\n      </ion-card-content>\n    </ion-card>\n  </div> \n  <ion-row *ngIf=\"orderInfo.order_details.status==='Approve'\" class=\"cancel_completed_btn\">\n    <!-- <ion-button  (click)=\"fnSelectDriver()\" shape=\"round\" fill=\"outline\">Assign Order</ion-button> -->\n    <ion-col class=\"center\">\n      <button ion-button class=\"cancelOrder_btn\"\n      (click)=\"fnSelectDriver(orderInfo.order_details.id)\">Assign Order</button>\n    </ion-col>\n    \n  </ion-row>\n  \n</ion-content>");

/***/ }),

/***/ "./src/app/sales-order-details/sales-order-details-routing.module.ts":
/*!***************************************************************************!*\
  !*** ./src/app/sales-order-details/sales-order-details-routing.module.ts ***!
  \***************************************************************************/
/*! exports provided: SalesOrderDetailsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SalesOrderDetailsPageRoutingModule", function() { return SalesOrderDetailsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _sales_order_details_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./sales-order-details.page */ "./src/app/sales-order-details/sales-order-details.page.ts");




const routes = [
    {
        path: '',
        component: _sales_order_details_page__WEBPACK_IMPORTED_MODULE_3__["SalesOrderDetailsPage"]
    }
];
let SalesOrderDetailsPageRoutingModule = class SalesOrderDetailsPageRoutingModule {
};
SalesOrderDetailsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SalesOrderDetailsPageRoutingModule);



/***/ }),

/***/ "./src/app/sales-order-details/sales-order-details.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/sales-order-details/sales-order-details.module.ts ***!
  \*******************************************************************/
/*! exports provided: SalesOrderDetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SalesOrderDetailsPageModule", function() { return SalesOrderDetailsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _sales_order_details_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./sales-order-details-routing.module */ "./src/app/sales-order-details/sales-order-details-routing.module.ts");
/* harmony import */ var _sales_order_details_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./sales-order-details.page */ "./src/app/sales-order-details/sales-order-details.page.ts");







let SalesOrderDetailsPageModule = class SalesOrderDetailsPageModule {
};
SalesOrderDetailsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _sales_order_details_routing_module__WEBPACK_IMPORTED_MODULE_5__["SalesOrderDetailsPageRoutingModule"]
        ],
        declarations: [_sales_order_details_page__WEBPACK_IMPORTED_MODULE_6__["SalesOrderDetailsPage"]]
    })
], SalesOrderDetailsPageModule);



/***/ }),

/***/ "./src/app/sales-order-details/sales-order-details.page.scss":
/*!*******************************************************************!*\
  !*** ./src/app/sales-order-details/sales-order-details.page.scss ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".menu_btn {\n  color: #E4322E;\n}\n\n.main-title {\n  color: #E4322E;\n  text-align: center;\n  font-family: open sans;\n}\n\n.main-card {\n  margin-top: 20px;\n  background-color: #fff;\n}\n\n.p-label2 {\n  font-family: open sans;\n  margin-top: 0px;\n  margin-bottom: 5px;\n  margin-right: 10px;\n  color: #000;\n  font-size: 16px;\n}\n\n.p-label {\n  font-family: open sans;\n  margin-top: 0px;\n  margin-bottom: 0px;\n  margin-right: 10px;\n  color: #000;\n  float: right;\n  font-size: 16px;\n}\n\n.p-price {\n  font-size: 22px;\n  margin-top: 0px;\n  margin-bottom: 0px;\n  color: #000;\n  font-family: open sans;\n}\n\n.p-date {\n  margin-top: 0px;\n  margin-bottom: 0px;\n  margin-right: 10px;\n  color: #000;\n  float: right;\n  font-size: 22px;\n  font-family: open sans;\n}\n\n.p-qty {\n  color: #000;\n  margin: 0;\n  margin-left: 10px;\n  font-family: open sans;\n  font-size: 16px;\n}\n\n.cust-profile {\n  background-color: #fff;\n}\n\n.p-label-nm {\n  font-family: open sans;\n  margin-top: 0px;\n  margin-bottom: 0px;\n  margin-right: 10px;\n  color: #000;\n  font-size: 16px;\n}\n\n.profile-txt {\n  font-size: 18px;\n  color: #000;\n  margin-left: 10px;\n  font-family: open sans;\n}\n\n.add-txt {\n  margin-left: 10px;\n  font-family: open sans;\n}\n\n.img {\n  margin-right: 10px;\n}\n\n.p-label3 {\n  margin-bottom: 10px;\n  margin-left: 10px;\n  color: #000;\n  font-family: open sans;\n  font-size: 18px;\n}\n\n.p-label4 {\n  margin-top: 0px;\n  margin-bottom: 0px;\n  margin-right: 10px;\n  color: #000;\n  float: right;\n  font-family: open sans;\n  font-size: 18px;\n}\n\n.p-qty1 {\n  color: #000;\n  margin: 0;\n  margin-left: 10px;\n  margin-top: 14px;\n  font-family: open sans;\n  font-size: 18px;\n}\n\n.main-card-item {\n  margin-top: -7px;\n  height: 30%;\n}\n\n.main-card-item ion-card-content {\n  padding: 0;\n  max-height: calc(125% - 50px);\n  position: relative;\n  overflow: hidden;\n  overflow-y: auto;\n}\n\n.main-card-item ion-card-content ::-webkit-scrollbar {\n  display: none;\n}\n\n.cancel_completed_btn {\n  margin-top: 12%;\n  margin-bottom: 8px;\n}\n\n.cancel_completed_btn .cancelOrder_btn {\n  background-color: #E4322E;\n  color: #fff;\n  font-size: 20px;\n  height: 40px;\n  width: 90%;\n  border-radius: 8px;\n  display: block;\n  margin: auto;\n  border: 1px solid #fff;\n  font-family: open sans;\n}\n\n.cancel_completed_btn .completed_btn {\n  background-color: #E4322E;\n  color: #fff;\n  font-size: 20px;\n  height: 40px;\n  width: 90%;\n  border-radius: 8px;\n  display: block;\n  margin: auto;\n  border: 1px solid #fff;\n  margin-right: 12px;\n  margin-left: 12px;\n  margin-top: 3px;\n  font-family: open sans;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9zYWxlcy1vcmRlci1kZXRhaWxzL3NhbGVzLW9yZGVyLWRldGFpbHMucGFnZS5zY3NzIiwic3JjL2FwcC9zYWxlcy1vcmRlci1kZXRhaWxzL3NhbGVzLW9yZGVyLWRldGFpbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtBQ0NKOztBRENBO0VBQ0ksY0FBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7QUNFSjs7QURBQztFQUVHLGdCQUFBO0VBQ0Esc0JBQUE7QUNFSjs7QURBQTtFQUNJLHNCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtBQ0dKOztBREFBO0VBQ0ksc0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtBQ0dKOztBRERBO0VBQ0ksZUFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxzQkFBQTtBQ0lKOztBREZBO0VBQ0ksZUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxzQkFBQTtBQ0tKOztBREhBO0VBQ0ksV0FBQTtFQUNBLFNBQUE7RUFDQSxpQkFBQTtFQUNBLHNCQUFBO0VBQ0EsZUFBQTtBQ01KOztBREpBO0VBRUksc0JBQUE7QUNNSjs7QURKQTtFQUNJLHNCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBRUEsZUFBQTtBQ01KOztBREpBO0VBQ0ksZUFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLHNCQUFBO0FDT0o7O0FETEE7RUFDSSxpQkFBQTtFQUNBLHNCQUFBO0FDUUo7O0FETkE7RUFDSSxrQkFBQTtBQ1NKOztBRE5BO0VBQ0ksbUJBQUE7RUFDQSxpQkFBQTtFQUNBLFdBQUE7RUFDQSxzQkFBQTtFQUNBLGVBQUE7QUNTSjs7QURQQTtFQUNJLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtFQUNBLGVBQUE7QUNVSjs7QURSQTtFQUNJLFdBQUE7RUFDQSxTQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLHNCQUFBO0VBQ0EsZUFBQTtBQ1dKOztBRFRBO0VBQ0ksZ0JBQUE7RUFFQSxXQUFBO0FDV0o7O0FEVkk7RUFDSSxVQUFBO0VBQ0EsNkJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7QUNZUjs7QURYUTtFQUNFLGFBQUE7QUNhVjs7QURUQTtFQUNJLGVBQUE7RUFDQSxrQkFBQTtBQ1lKOztBRFhJO0VBQ0kseUJBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLHNCQUFBO0VBQ0Esc0JBQUE7QUNhUjs7QURYSTtFQUNJLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0Esc0JBQUE7QUNhUiIsImZpbGUiOiJzcmMvYXBwL3NhbGVzLW9yZGVyLWRldGFpbHMvc2FsZXMtb3JkZXItZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWVudV9idG57XG4gICAgY29sb3I6ICNFNDMyMkU7XG59XG4ubWFpbi10aXRsZXtcbiAgICBjb2xvcjogI0U0MzIyRTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiB9XG4gLm1haW4tY2FyZHtcbiAgICAvLyBib3gtc2hhZG93OiA1cHggN3B4IDEwcHggNXB4ICNlOGU4ZTg7XG4gICAgbWFyZ2luLXRvcDogMjBweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xufVxuLnAtbGFiZWwye1xuICAgIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG4gICAgbWFyZ2luLXRvcDogMHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDVweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgY29sb3I6ICMwMDA7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIC8vZmxvYXQ6IHJpZ2h0O1xufVxuLnAtbGFiZWx7XG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgICBtYXJnaW4tdG9wOiAwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICBjb2xvcjogIzAwMDtcbiAgICBmbG9hdDogcmlnaHQ7XG4gICAgZm9udC1zaXplOiAxNnB4O1xufVxuLnAtcHJpY2V7XG4gICAgZm9udC1zaXplOiAyMnB4O1xuICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gICAgY29sb3I6ICMwMDA7IFxuICAgIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG59XG4ucC1kYXRle1xuICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgIGNvbG9yOiAjMDAwO1xuICAgIGZsb2F0OiByaWdodDtcbiAgICBmb250LXNpemU6IDIycHg7XG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cbi5wLXF0eXtcbiAgICBjb2xvcjogIzAwMDtcbiAgICBtYXJnaW46IDA7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgICBmb250LXNpemU6IDE2cHg7XG59XG4uY3VzdC1wcm9maWxle1xuICAgIC8vIGJveC1zaGFkb3c6IDVweCA3cHggMTBweCA1cHggI2U4ZThlODtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xufVxuLnAtbGFiZWwtbm17XG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgICBtYXJnaW4tdG9wOiAwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICBjb2xvcjogIzAwMDtcbiAgICAvLyBmbG9hdDogbGVmdDtcbiAgICBmb250LXNpemU6IDE2cHg7XG59XG4ucHJvZmlsZS10eHR7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGNvbG9yOiAjMDAwO1xuICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG59XG4uYWRkLXR4dHtcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuLmltZ3tcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG5cbi5wLWxhYmVsM3tcbiAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgIGNvbG9yOiAjMDAwO1xuICAgIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG4gICAgZm9udC1zaXplOiAxOHB4O1xufVxuLnAtbGFiZWw0e1xuICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgIGNvbG9yOiAjMDAwO1xuICAgIGZsb2F0OiByaWdodDtcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbn1cbi5wLXF0eTF7XG4gICAgY29sb3I6ICMwMDA7XG4gICAgbWFyZ2luOiAwO1xuICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgIG1hcmdpbi10b3A6IDE0cHg7XG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgICBmb250LXNpemU6IDE4cHg7XG59XG4ubWFpbi1jYXJkLWl0ZW17XG4gICAgbWFyZ2luLXRvcDogLTdweDtcbiAgICAvLyBib3gtc2hhZG93OiA1cHggN3B4IDEwcHggNXB4ICNlOGU4ZTg7XG4gICAgaGVpZ2h0OiAzMCU7XG4gICAgaW9uLWNhcmQtY29udGVudCB7XG4gICAgICAgIHBhZGRpbmc6IDA7XG4gICAgICAgIG1heC1oZWlnaHQ6IGNhbGMoMTI1JSAtICN7NTBweH0pO1xuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgICAgIG92ZXJmbG93LXk6IGF1dG87XG4gICAgICAgIDo6LXdlYmtpdC1zY3JvbGxiYXIge1xuICAgICAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgICAgIH1cbiAgICAgIH1cbn1cbi5jYW5jZWxfY29tcGxldGVkX2J0bntcbiAgICBtYXJnaW4tdG9wOiAxMiU7XG4gICAgbWFyZ2luLWJvdHRvbTogOHB4OyAgICAgIFxuICAgIC5jYW5jZWxPcmRlcl9idG57XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNFNDMyMkU7XG4gICAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICAgIGhlaWdodDogNDBweDtcbiAgICAgICAgd2lkdGg6IDkwJTtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogOHB4O1xuICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgICAgbWFyZ2luOiBhdXRvO1xuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjZmZmO1xuICAgICAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICAgIH1cbiAgICAuY29tcGxldGVkX2J0bntcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI0U0MzIyRTtcbiAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICAgICAgaGVpZ2h0OiA0MHB4O1xuICAgICAgICB3aWR0aDogOTAlO1xuICAgICAgICBib3JkZXItcmFkaXVzOiA4cHg7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICBtYXJnaW46IGF1dG87XG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNmZmY7XG4gICAgICAgIG1hcmdpbi1yaWdodDogMTJweDtcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDEycHg7XG4gICAgICAgIG1hcmdpbi10b3A6IDNweDsgIFxuICAgICAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuXG4gICAgfVxufVxuIiwiLm1lbnVfYnRuIHtcbiAgY29sb3I6ICNFNDMyMkU7XG59XG5cbi5tYWluLXRpdGxlIHtcbiAgY29sb3I6ICNFNDMyMkU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cblxuLm1haW4tY2FyZCB7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG59XG5cbi5wLWxhYmVsMiB7XG4gIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG4gIG1hcmdpbi10b3A6IDBweDtcbiAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIGNvbG9yOiAjMDAwO1xuICBmb250LXNpemU6IDE2cHg7XG59XG5cbi5wLWxhYmVsIHtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgbWFyZ2luLXRvcDogMHB4O1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbiAgY29sb3I6ICMwMDA7XG4gIGZsb2F0OiByaWdodDtcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG4ucC1wcmljZSB7XG4gIGZvbnQtc2l6ZTogMjJweDtcbiAgbWFyZ2luLXRvcDogMHB4O1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gIGNvbG9yOiAjMDAwO1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuXG4ucC1kYXRlIHtcbiAgbWFyZ2luLXRvcDogMHB4O1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbiAgY29sb3I6ICMwMDA7XG4gIGZsb2F0OiByaWdodDtcbiAgZm9udC1zaXplOiAyMnB4O1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuXG4ucC1xdHkge1xuICBjb2xvcjogIzAwMDtcbiAgbWFyZ2luOiAwO1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG4uY3VzdC1wcm9maWxlIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbn1cblxuLnAtbGFiZWwtbm0ge1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICBtYXJnaW4tdG9wOiAwcHg7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICBjb2xvcjogIzAwMDtcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG4ucHJvZmlsZS10eHQge1xuICBmb250LXNpemU6IDE4cHg7XG4gIGNvbG9yOiAjMDAwO1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cblxuLmFkZC10eHQge1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cblxuLmltZyB7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cblxuLnAtbGFiZWwzIHtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIGNvbG9yOiAjMDAwO1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICBmb250LXNpemU6IDE4cHg7XG59XG5cbi5wLWxhYmVsNCB7XG4gIG1hcmdpbi10b3A6IDBweDtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIGNvbG9yOiAjMDAwO1xuICBmbG9hdDogcmlnaHQ7XG4gIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG4gIGZvbnQtc2l6ZTogMThweDtcbn1cblxuLnAtcXR5MSB7XG4gIGNvbG9yOiAjMDAwO1xuICBtYXJnaW46IDA7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBtYXJnaW4tdG9wOiAxNHB4O1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICBmb250LXNpemU6IDE4cHg7XG59XG5cbi5tYWluLWNhcmQtaXRlbSB7XG4gIG1hcmdpbi10b3A6IC03cHg7XG4gIGhlaWdodDogMzAlO1xufVxuLm1haW4tY2FyZC1pdGVtIGlvbi1jYXJkLWNvbnRlbnQge1xuICBwYWRkaW5nOiAwO1xuICBtYXgtaGVpZ2h0OiBjYWxjKDEyNSUgLSA1MHB4KTtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBvdmVyZmxvdy15OiBhdXRvO1xufVxuLm1haW4tY2FyZC1pdGVtIGlvbi1jYXJkLWNvbnRlbnQgOjotd2Via2l0LXNjcm9sbGJhciB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5cbi5jYW5jZWxfY29tcGxldGVkX2J0biB7XG4gIG1hcmdpbi10b3A6IDEyJTtcbiAgbWFyZ2luLWJvdHRvbTogOHB4O1xufVxuLmNhbmNlbF9jb21wbGV0ZWRfYnRuIC5jYW5jZWxPcmRlcl9idG4ge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTQzMjJFO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBoZWlnaHQ6IDQwcHg7XG4gIHdpZHRoOiA5MCU7XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbjogYXV0bztcbiAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cbi5jYW5jZWxfY29tcGxldGVkX2J0biAuY29tcGxldGVkX2J0biB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNFNDMyMkU7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LXNpemU6IDIwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgd2lkdGg6IDkwJTtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBkaXNwbGF5OiBibG9jaztcbiAgbWFyZ2luOiBhdXRvO1xuICBib3JkZXI6IDFweCBzb2xpZCAjZmZmO1xuICBtYXJnaW4tcmlnaHQ6IDEycHg7XG4gIG1hcmdpbi1sZWZ0OiAxMnB4O1xuICBtYXJnaW4tdG9wOiAzcHg7XG4gIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG59Il19 */");

/***/ }),

/***/ "./src/app/sales-order-details/sales-order-details.page.ts":
/*!*****************************************************************!*\
  !*** ./src/app/sales-order-details/sales-order-details.page.ts ***!
  \*****************************************************************/
/*! exports provided: SalesOrderDetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SalesOrderDetailsPage", function() { return SalesOrderDetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth.service.ts");







let SalesOrderDetailsPage = class SalesOrderDetailsPage {
    constructor(auth, alertCtrl, navCtrl, actionSheetController, location, router) {
        this.auth = auth;
        this.alertCtrl = alertCtrl;
        this.navCtrl = navCtrl;
        this.actionSheetController = actionSheetController;
        this.location = location;
        this.router = router;
        this.staffList = [];
        const state = this.router.getCurrentNavigation().extras.state;
        if (state) {
            this.orderInfo = state;
            console.log("order orderInfo-->", this.orderInfo);
        }
    }
    ngOnInit() {
        this.fnGetAllStaff();
    }
    goBack() {
        this.location.back();
    }
    fnSelectDriver(orderId) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                header: 'All Staff',
                cssClass: 'my-custom-class',
                buttons: this.createButtons(orderId),
            });
            yield actionSheet.present();
        });
    }
    createButtons(orderId) {
        let buttons = [];
        for (let btn of this.staffList) {
            let button = {
                text: btn.name,
                icon: 'person',
                handler: () => {
                    console.log(' id ' + btn.id);
                    this.fnConfirmAlert(btn.id, orderId, btn.name);
                    return true;
                }
            };
            buttons.push(button);
        }
        let button = {
            text: "Cancel",
            icon: 'close',
            handler: () => {
                console.log(' cancel ');
                return true;
            }
        };
        buttons.push(button);
        return buttons;
    }
    fnGetAllStaff() {
        this.staffList = [];
        let requestObject = { "role": "DeliveryBoy" };
        this.auth.showLoader();
        console.log(requestObject);
        this.auth.getAllDriver(requestObject).subscribe((data) => {
            this.auth.hideLoader();
            this.dataResponse = data.data;
            this.staffList = data.data;
            console.log("staffList", this.staffList);
        }, (err) => {
            this.auth.hideLoader();
            console.log("Error=>", err);
        });
    }
    fnSetAssignOrder(id, orderId) {
        let requestObject = {
            "login_id": localStorage.getItem("id"),
            "userId": id,
            "order_id": orderId,
            "order_status": "Assigned",
            "user_type": localStorage.getItem("role")
        };
        this.auth.showLoader();
        console.log(requestObject);
        this.auth.assignDriver(requestObject).subscribe((data) => {
            this.auth.hideLoader();
            this.dataResponse = data.data;
            this.dataResponse = data;
            if (this.dataResponse.status === true) {
                this.location.back();
            }
            this.auth.showToast(this.dataResponse.message);
        }, (err) => {
            this.auth.hideLoader();
            console.log("Error=>", err);
        });
    }
    fnConfirmAlert(id, orderId, name) {
        this.alertCtrl.create({
            header: 'Assign Order',
            message: 'Are you sure you want to assign to ' + name + '?',
            backdropDismiss: false,
            buttons: [{
                    text: 'Cancel',
                    role: 'cancel',
                    handler: () => {
                        console.log('cancel!');
                    }
                }, {
                    text: 'Yes',
                    handler: () => {
                        this.fnSetAssignOrder(id, orderId);
                    }
                }]
        })
            .then(alert => {
            alert.present();
        });
    }
};
SalesOrderDetailsPage.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ActionSheetController"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_3__["Location"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
];
SalesOrderDetailsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-sales-order-details',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./sales-order-details.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sales-order-details/sales-order-details.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./sales-order-details.page.scss */ "./src/app/sales-order-details/sales-order-details.page.scss")).default]
    })
], SalesOrderDetailsPage);



/***/ })

}]);
//# sourceMappingURL=sales-order-details-sales-order-details-module-es2015.js.map