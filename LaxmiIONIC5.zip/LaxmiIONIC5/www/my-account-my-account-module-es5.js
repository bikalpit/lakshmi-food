function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["my-account-my-account-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/my-account/my-account.page.html":
  /*!***************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/my-account/my-account.page.html ***!
    \***************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppMyAccountMyAccountPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\" class=\"menu_btn\">\n      <ion-menu-button auto-hide=\"false\"></ion-menu-button>\n    </ion-buttons>\n    <!--  <ion-buttons slot=\"end\">\n      <ion-button>\n        <img src=\"../../assets/imgs/logout.png\" (click)=presentAlertConfirm()>\n      </ion-button>\n    </ion-buttons> -->\n    <ion-title class=\"main-title\">My Orders</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid class=\"header-content\">\n    <p class=\"p-label\">Welcome {{userName}}!</p>\n  </ion-grid>\n\n  <ion-row style=\"margin-top: 12px;\">\n    <p class=\"order-status\"><b>Order Status</b></p>\n\n    <ion-col>\n      <ion-item lines=\"none\" style=\"float: right;\">\n        <ion-select #item class=\"custom-options customer-filter\" [(ngModel)]=\"selecTextStatus.select\"\n          (ionChange)=\"OnChange(item.value)\">\n          <ion-select-option value=\"Assigned\">Assigned</ion-select-option>\n          <ion-select-option value=\"Pickup\">Pickup</ion-select-option>\n          <!-- <ion-select-option value=\"Completed\">Completed</ion-select-option>  -->\n          <ion-select-option value=\"Delivered\">Delivered</ion-select-option>\n          <ion-select-option value=\"cancel\">Cancel</ion-select-option>\n\n        </ion-select>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n\n  <div *ngFor=\"let item of ordersList;\">\n    <ion-card class=\"card-content\">\n      <ion-item (click)=\"fnOrderDetails(item.id,item.status)\">\n        <ion-avatar slot=\"start\" *ngIf=\"item.photo  && item.photo !==null\">\n          <img src=\"{{url.file_url}}assets/uploads/users/{{item.photo}}\">\n        </ion-avatar>\n        <ion-avatar slot=\"start\" *ngIf=\"item.photo===null  && item.photo ===''\">\n          <img src=\"../../assets/imgs/avatar1.png\">\n        </ion-avatar>\n        <ion-label>\n          <h3>{{item.name}}</h3>\n          <p>{{item.phone}}</p>\n        </ion-label>\n        <ion-label slot=\"end\" style=\"text-align: end;color: #E4322E;\">\n          <p class=\"menu_btn\" *ngIf=\"item.status == 'New'\">Pending</p>\n          <p class=\"menu_btn\" *ngIf=\"item.status == 'Assigned'\">Assigned</p>\n          <p class=\"menu_btn\" *ngIf=\"item.status == 'Approve'\">Approve</p>\n          <p class=\"menu_btn\" *ngIf=\"item.status == 'cancel'\">Cancel</p>\n          <p class=\"menu_btn\" *ngIf=\"item.status == 'Pickup'\">Pickup</p>\n          <p class=\"menu_btn\" *ngIf=\"item.status == 'Delivered'\">Delivered</p>\n          <p class=\"menu_btn\" *ngIf=\"item.status == 'Completed'\">Completed</p>\n\n        </ion-label>\n      </ion-item>\n      <ion-row style=\"margin-top: 15px;\">\n        <p class=\"p-order\"><b>Order #{{item.order_number}}</b></p>\n        <ion-col>\n          <!-- <button ion-button class=\"Pending_btn\">{{item.status}}</button> -->\n          <button (click)=\"fnChangeStatus(item.id,'Pickup')\" ion-button *ngIf=\"item.status == 'Assigned'\"\n            class=\"Pending_btn\">Pickup</button>\n          <button (click)=\"fnChangeStatus(item.id,'Delivered')\" ion-button *ngIf=\"item.status == 'Pickup'\"\n            class=\"Pending_btn\">Deliver</button>\n          <div *ngIf=\"item.status == 'Delivered' && item.delivery_date!==null\" style=\"text-align: end;margin-top: 0.5rem;margin-right: .5rem;\">\n            <ion-labe>\n               <b>Delivery Date</b><br/>\n              {{item.delivery_date}}\n            </ion-labe>\n          \n          </div>\n        </ion-col>\n      </ion-row>\n      <p class=\"p-date\"><b>Date: </b>{{item.create_at}}</p>\n      <ion-item style=\"background-color: lightgrey;\" (click)=\"fnOrderDetails(item.id,item.status)\">\n        <ion-row style=\"font-size: 16px; font-weight: bold;\">\n          <ion-col size=\"1\">\n            <img src=\"../../assets/imgs/location.png\" class=\"img\">\n          </ion-col>\n          <ion-col size=\"11\" *ngIf=\"item.address_house_no!=='' \">\n            {{item.address_house_no}}, {{item.address_landmark}}, {{item.address_city}}, {{item.address_state}},\n            {{item.address_zipcode}}\n          </ion-col>\n          <ion-col size=\"11\" *ngIf=\"item.address_house_no===''\">\n            {{item.address_landmark}}, {{item.address_city}}, {{item.address_state}}, {{item.address_zipcode}}\n          </ion-col>\n        </ion-row>\n      </ion-item>\n\n    </ion-card>\n    <!-- <ion-card class=\"card-content-address\">\n      <ion-row style=\"font-size: 16px; font-weight: bold;\">\n        <ion-col size=\"1\">\n          <img src=\"../../assets/imgs/location.png\" class=\"img\">\n        </ion-col>\n        <ion-col size=\"11\" *ngIf=\"item.address_house_no!=='' \">\n          {{item.address_house_no}}, {{item.address_landmark}}, {{item.address_city}}, {{item.address_state}},\n          {{item.address_zipcode}}\n        </ion-col>\n        <ion-col size=\"11\" *ngIf=\"item.address_house_no===''\">\n          {{item.address_landmark}}, {{item.address_city}}, {{item.address_state}}, {{item.address_zipcode}}\n        </ion-col>\n      </ion-row>\n    </ion-card> -->\n  </div>\n  <div *ngIf=\"!ordersList?.length > 0\">\n    <p class=\"norecord-label\">No Records Found</p>\n  </div>\n\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/my-account/my-account-routing.module.ts":
  /*!*********************************************************!*\
    !*** ./src/app/my-account/my-account-routing.module.ts ***!
    \*********************************************************/

  /*! exports provided: MyAccountPageRoutingModule */

  /***/
  function srcAppMyAccountMyAccountRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MyAccountPageRoutingModule", function () {
      return MyAccountPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _my_account_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./my-account.page */
    "./src/app/my-account/my-account.page.ts");

    var routes = [{
      path: '',
      component: _my_account_page__WEBPACK_IMPORTED_MODULE_3__["MyAccountPage"]
    }];

    var MyAccountPageRoutingModule = function MyAccountPageRoutingModule() {
      _classCallCheck(this, MyAccountPageRoutingModule);
    };

    MyAccountPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MyAccountPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/my-account/my-account.module.ts":
  /*!*************************************************!*\
    !*** ./src/app/my-account/my-account.module.ts ***!
    \*************************************************/

  /*! exports provided: MyAccountPageModule */

  /***/
  function srcAppMyAccountMyAccountModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MyAccountPageModule", function () {
      return MyAccountPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _my_account_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./my-account-routing.module */
    "./src/app/my-account/my-account-routing.module.ts");
    /* harmony import */


    var _my_account_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./my-account.page */
    "./src/app/my-account/my-account.page.ts");

    var MyAccountPageModule = function MyAccountPageModule() {
      _classCallCheck(this, MyAccountPageModule);
    };

    MyAccountPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _my_account_routing_module__WEBPACK_IMPORTED_MODULE_5__["MyAccountPageRoutingModule"]],
      declarations: [_my_account_page__WEBPACK_IMPORTED_MODULE_6__["MyAccountPage"]]
    })], MyAccountPageModule);
    /***/
  },

  /***/
  "./src/app/my-account/my-account.page.scss":
  /*!*************************************************!*\
    !*** ./src/app/my-account/my-account.page.scss ***!
    \*************************************************/

  /*! exports provided: default */

  /***/
  function srcAppMyAccountMyAccountPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".menu_btn {\n  color: #E4322E;\n}\n\n.main-title {\n  text-align: center;\n  color: #E4322E;\n  margin-right: 43px;\n}\n\n.header-content {\n  background-color: #E4322E;\n}\n\n.p-label {\n  color: #fff;\n  margin: 30px 0 30px 10px;\n  font-size: 1.3rem;\n}\n\n.card-content {\n  margin-top: 12%;\n  background-color: #fff;\n  height: 17%;\n  margin-bottom: 1px;\n}\n\n.p-order {\n  color: #000;\n  margin-bottom: 0px;\n  margin-left: 10px;\n  font-size: 16px;\n}\n\n.Pending_btn {\n  background-color: #E4322E;\n  float: right;\n  color: #fff;\n  font-size: 16px;\n  height: 33px;\n  width: 50%;\n  border-radius: 8px;\n  display: block;\n  margin: auto;\n  border: 1px solid #fff;\n  margin-right: 6px;\n}\n\n.p-date {\n  margin-top: 0px;\n  margin-left: 10px;\n  color: #000;\n}\n\n.card-content-address {\n  margin-top: 0;\n  background-color: #fff;\n}\n\n.add-txt {\n  text-align: center;\n}\n\n.img {\n  margin-right: 10px;\n}\n\n.order-status {\n  color: black;\n  font-size: 18px;\n  margin-left: 20px;\n  margin-bottom: 5px;\n}\n\nion-select {\n  max-width: 117px;\n  border: 1px solid #E4322E;\n  border-radius: 9px;\n  padding: 9px;\n}\n\n.customer-filter {\n  padding: 0;\n}\n\n.customer-filter .select-icon {\n  width: 30px !important;\n  height: 30px !important;\n  background-color: red !important;\n  display: flex !important;\n  justify-content: center !important;\n}\n\n.customer-filter {\n  width: 160px;\n  max-width: 160px;\n  height: 40px;\n}\n\n.customer-filter::part(text) {\n  padding: 0 10px;\n  font-size: 17px;\n  font-family: open sans;\n}\n\n.customer-filter::part(icon) {\n  width: 45px !important;\n  height: 40px !important;\n  background-color: #E4322E !important;\n  display: flex !important;\n  justify-content: center !important;\n  opacity: 1;\n  align-items: center;\n}\n\n.customer-filter::part(icon) * {\n  display: none;\n}\n\n.customer-filter::part(icon)::after {\n  content: \"\";\n  background-image: url(\"/../../assets/imgs/down-arrow.png\");\n  width: 35px;\n  height: 18px;\n  background-position: center;\n  background-color: #e4322e;\n  z-index: 1;\n  background-size: 70%;\n  background-repeat: no-repeat;\n}\n\n.norecord-label {\n  font-family: open sans;\n  color: #E4322E;\n  font-size: 18px;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9teS1hY2NvdW50L215LWFjY291bnQucGFnZS5zY3NzIiwic3JjL2FwcC9teS1hY2NvdW50L215LWFjY291bnQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtBQ0NKOztBRENBO0VBQ0ksa0JBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUNFSjs7QURBQztFQUVHLHlCQUFBO0FDRUo7O0FEQUM7RUFDSSxXQUFBO0VBQ0Esd0JBQUE7RUFDQSxpQkFBQTtBQ0dMOztBRERDO0VBRUcsZUFBQTtFQUNBLHNCQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0FDR0o7O0FEREM7RUFDRyxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUNJSjs7QURGQztFQUNHLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxpQkFBQTtBQ0tKOztBREhBO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtBQ01KOztBREpBO0VBRUksYUFBQTtFQUNBLHNCQUFBO0FDTUo7O0FESkE7RUFDSSxrQkFBQTtBQ09KOztBRExBO0VBQ0ksa0JBQUE7QUNRSjs7QUROQTtFQUNJLFlBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQ1NKOztBRFBBO0VBQ0ksZ0JBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtBQ1VKOztBRFJBO0VBQ0ksVUFBQTtBQ1dKOztBRFZJO0VBQ0ksc0JBQUE7RUFDQSx1QkFBQTtFQUNBLGdDQUFBO0VBQ0Esd0JBQUE7RUFDQSxrQ0FBQTtBQ1lSOztBRFRBO0VBQ0ksWUFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtBQ1lKOztBRFZBO0VBQ0ksZUFBQTtFQUNBLGVBQUE7RUFDQSxzQkFBQTtBQ2FKOztBRFhBO0VBQ1Esc0JBQUE7RUFDQSx1QkFBQTtFQUNBLG9DQUFBO0VBQ0Esd0JBQUE7RUFDQSxrQ0FBQTtFQUNBLFVBQUE7RUFDQSxtQkFBQTtBQ2NSOztBRGJRO0VBQ0ksYUFBQTtBQ2VaOztBRGJJO0VBQ0ksV0FBQTtFQUNBLDBEQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSwyQkFBQTtFQUNBLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLG9CQUFBO0VBQ0EsNEJBQUE7QUNlUjs7QURYQTtFQUNJLHNCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQ2NKIiwiZmlsZSI6InNyYy9hcHAvbXktYWNjb3VudC9teS1hY2NvdW50LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tZW51X2J0bntcbiAgICBjb2xvcjogI0U0MzIyRTtcbn1cbi5tYWluLXRpdGxle1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogI0U0MzIyRTtcbiAgICBtYXJnaW4tcmlnaHQ6IDQzcHg7XG4gfVxuIC5oZWFkZXItY29udGVudHtcbiAgICAvLyBib3gtc2hhZG93OiA1cHggN3B4IDEwcHggNXB4ICNlOGU4ZTg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0U0MzIyRTtcbiB9XG4gLnAtbGFiZWx7XG4gICAgIGNvbG9yIDojZmZmO1xuICAgICBtYXJnaW46IDMwcHggMCAzMHB4IDEwcHg7XG4gICAgIGZvbnQtc2l6ZTogMS4zcmVtO1xuIH1cbiAuY2FyZC1jb250ZW50e1xuICAgIC8vIGJveC1zaGFkb3c6IDVweCA3cHggMTBweCA1cHggI2U4ZThlODtcbiAgICBtYXJnaW4tdG9wOiAxMiU7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgICBoZWlnaHQ6IDE3JTtcbiAgICBtYXJnaW4tYm90dG9tOiAxcHg7XG4gfVxuIC5wLW9yZGVye1xuICAgIGNvbG9yOiAjMDAwO1xuICAgIG1hcmdpbi1ib3R0b206IDBweDtcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gfVxuIC5QZW5kaW5nX2J0bntcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTQzMjJFO1xuICAgIGZsb2F0OiByaWdodDtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgaGVpZ2h0OiAzM3B4O1xuICAgIHdpZHRoOiA1MCU7XG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIG1hcmdpbjogYXV0bztcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZmZmO1xuICAgIG1hcmdpbi1yaWdodDogNnB4O1xufVxuLnAtZGF0ZXtcbiAgICBtYXJnaW4tdG9wOiAwcHg7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgY29sb3I6ICMwMDA7XG59XG4uY2FyZC1jb250ZW50LWFkZHJlc3N7XG4gICAgLy8gYm94LXNoYWRvdzogNXB4IDdweCAxMHB4IDVweCAjZThlOGU4O1xuICAgIG1hcmdpbi10b3A6IDA7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbn1cbi5hZGQtdHh0e1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5pbWd7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuLm9yZGVyLXN0YXR1c3tcbiAgICBjb2xvcjogYmxhY2s7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDVweDtcbn1cbmlvbi1zZWxlY3R7XG4gICAgbWF4LXdpZHRoOiAxMTdweDtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjRTQzMjJFO1xuICAgIGJvcmRlci1yYWRpdXM6IDlweDtcbiAgICBwYWRkaW5nOiA5cHg7XG59XG4uY3VzdG9tZXItZmlsdGVye1xuICAgIHBhZGRpbmc6IDA7XG4gICAgLnNlbGVjdC1pY29ue1xuICAgICAgICB3aWR0aDogMzBweCAhaW1wb3J0YW50O1xuICAgICAgICBoZWlnaHQ6IDMwcHggIWltcG9ydGFudDtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmVkICFpbXBvcnRhbnQ7XG4gICAgICAgIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXIgIWltcG9ydGFudDtcbiAgICB9XG59XG4uY3VzdG9tZXItZmlsdGVye1xuICAgIHdpZHRoOiAxNjBweDtcbiAgICBtYXgtd2lkdGg6IDE2MHB4O1xuICAgIGhlaWdodDogNDBweDtcbn1cbi5jdXN0b21lci1maWx0ZXI6OnBhcnQodGV4dCl7XG4gICAgcGFkZGluZzogMCAxMHB4O1xuICAgIGZvbnQtc2l6ZTogMTdweDtcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuLmN1c3RvbWVyLWZpbHRlcjo6cGFydChpY29uKSB7XG4gICAgICAgIHdpZHRoOiA0NXB4ICFpbXBvcnRhbnQ7XG4gICAgICAgIGhlaWdodDogNDBweCAhaW1wb3J0YW50O1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTQzMjJFICFpbXBvcnRhbnQ7XG4gICAgICAgIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXIgIWltcG9ydGFudDtcbiAgICAgICAgb3BhY2l0eTogMTtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgKntcbiAgICAgICAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgICAgIH1cbiAgICAmOjphZnRlcntcbiAgICAgICAgY29udGVudDogXCJcIjtcbiAgICAgICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcvLi4vLi4vYXNzZXRzL2ltZ3MvZG93bi1hcnJvdy5wbmcnKTtcbiAgICAgICAgd2lkdGg6IDM1cHg7XG4gICAgICAgIGhlaWdodDogMThweDtcbiAgICAgICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTQzMjJlO1xuICAgICAgICB6LWluZGV4OiAxO1xuICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IDcwJTtcbiAgICAgICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgICB9XG59XG5cbi5ub3JlY29yZC1sYWJlbHtcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICAgIGNvbG9yOiNFNDMyMkU7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuIiwiLm1lbnVfYnRuIHtcbiAgY29sb3I6ICNFNDMyMkU7XG59XG5cbi5tYWluLXRpdGxlIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI0U0MzIyRTtcbiAgbWFyZ2luLXJpZ2h0OiA0M3B4O1xufVxuXG4uaGVhZGVyLWNvbnRlbnQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTQzMjJFO1xufVxuXG4ucC1sYWJlbCB7XG4gIGNvbG9yOiAjZmZmO1xuICBtYXJnaW46IDMwcHggMCAzMHB4IDEwcHg7XG4gIGZvbnQtc2l6ZTogMS4zcmVtO1xufVxuXG4uY2FyZC1jb250ZW50IHtcbiAgbWFyZ2luLXRvcDogMTIlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICBoZWlnaHQ6IDE3JTtcbiAgbWFyZ2luLWJvdHRvbTogMXB4O1xufVxuXG4ucC1vcmRlciB7XG4gIGNvbG9yOiAjMDAwO1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBmb250LXNpemU6IDE2cHg7XG59XG5cbi5QZW5kaW5nX2J0biB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNFNDMyMkU7XG4gIGZsb2F0OiByaWdodDtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgaGVpZ2h0OiAzM3B4O1xuICB3aWR0aDogNTAlO1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW46IGF1dG87XG4gIGJvcmRlcjogMXB4IHNvbGlkICNmZmY7XG4gIG1hcmdpbi1yaWdodDogNnB4O1xufVxuXG4ucC1kYXRlIHtcbiAgbWFyZ2luLXRvcDogMHB4O1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgY29sb3I6ICMwMDA7XG59XG5cbi5jYXJkLWNvbnRlbnQtYWRkcmVzcyB7XG4gIG1hcmdpbi10b3A6IDA7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG59XG5cbi5hZGQtdHh0IHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uaW1nIHtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuXG4ub3JkZXItc3RhdHVzIHtcbiAgY29sb3I6IGJsYWNrO1xuICBmb250LXNpemU6IDE4cHg7XG4gIG1hcmdpbi1sZWZ0OiAyMHB4O1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG59XG5cbmlvbi1zZWxlY3Qge1xuICBtYXgtd2lkdGg6IDExN3B4O1xuICBib3JkZXI6IDFweCBzb2xpZCAjRTQzMjJFO1xuICBib3JkZXItcmFkaXVzOiA5cHg7XG4gIHBhZGRpbmc6IDlweDtcbn1cblxuLmN1c3RvbWVyLWZpbHRlciB7XG4gIHBhZGRpbmc6IDA7XG59XG4uY3VzdG9tZXItZmlsdGVyIC5zZWxlY3QtaWNvbiB7XG4gIHdpZHRoOiAzMHB4ICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogMzBweCAhaW1wb3J0YW50O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZWQgIWltcG9ydGFudDtcbiAgZGlzcGxheTogZmxleCAhaW1wb3J0YW50O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlciAhaW1wb3J0YW50O1xufVxuXG4uY3VzdG9tZXItZmlsdGVyIHtcbiAgd2lkdGg6IDE2MHB4O1xuICBtYXgtd2lkdGg6IDE2MHB4O1xuICBoZWlnaHQ6IDQwcHg7XG59XG5cbi5jdXN0b21lci1maWx0ZXI6OnBhcnQodGV4dCkge1xuICBwYWRkaW5nOiAwIDEwcHg7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cblxuLmN1c3RvbWVyLWZpbHRlcjo6cGFydChpY29uKSB7XG4gIHdpZHRoOiA0NXB4ICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogNDBweCAhaW1wb3J0YW50O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTQzMjJFICFpbXBvcnRhbnQ7XG4gIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXIgIWltcG9ydGFudDtcbiAgb3BhY2l0eTogMTtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cbi5jdXN0b21lci1maWx0ZXI6OnBhcnQoaWNvbikgKiB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG4uY3VzdG9tZXItZmlsdGVyOjpwYXJ0KGljb24pOjphZnRlciB7XG4gIGNvbnRlbnQ6IFwiXCI7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi8uLi8uLi9hc3NldHMvaW1ncy9kb3duLWFycm93LnBuZ1wiKTtcbiAgd2lkdGg6IDM1cHg7XG4gIGhlaWdodDogMThweDtcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTQzMjJlO1xuICB6LWluZGV4OiAxO1xuICBiYWNrZ3JvdW5kLXNpemU6IDcwJTtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbn1cblxuLm5vcmVjb3JkLWxhYmVsIHtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgY29sb3I6ICNFNDMyMkU7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/my-account/my-account.page.ts":
  /*!***********************************************!*\
    !*** ./src/app/my-account/my-account.page.ts ***!
    \***********************************************/

  /*! exports provided: MyAccountPage */

  /***/
  function srcAppMyAccountMyAccountPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MyAccountPage", function () {
      return MyAccountPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../auth.service */
    "./src/app/auth.service.ts");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../common.service */
    "./src/app/common.service.ts");

    var MyAccountPage = /*#__PURE__*/function () {
      function MyAccountPage(commonService, alertCtrl, datePipe, auth, navCtrl, menu) {
        var _this = this;

        _classCallCheck(this, MyAccountPage);

        this.commonService = commonService;
        this.alertCtrl = alertCtrl;
        this.datePipe = datePipe;
        this.auth = auth;
        this.navCtrl = navCtrl;
        this.menu = menu;
        this.ordersList = [];
        this.selecTextStatus = {
          select: null
        };

        this.fngetDeliveryBoyOrders = function (value) {
          _this.ordersList = [];
          _this.requestObject = {
            "order_status": value,
            "delivery_boy_id": _this.user_id
          };

          _this.auth.showLoader();

          console.log(_this.requestObject);

          _this.auth.getDeliveryBoyOrders(_this.requestObject).subscribe(function (data) {
            console.log(data);

            _this.auth.hideLoader();

            _this.dataResponse = data.data;
            _this.ordersList = _this.dataResponse;

            _this.ordersList.forEach(function (element) {
              element.create_at = _this.datePipe.transform(new Date(element.create_at), "dd-MM-yyyy");
            });

            console.log("order list", _this.ordersList);
          }, function (err) {
            _this.auth.hideLoader();

            console.log("Error=>", err);
          });
        };

        this.menu.enable(true);
        this.user_id = localStorage.getItem("id");
        this.userName = localStorage.getItem("name");
        this.role = localStorage.getItem("role");
        console.log(this.user_id);
        this.selecTextStatus.select = "Assigned";
      }

      _createClass(MyAccountPage, [{
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          this.url = this.commonService.url();
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          this.fngetDeliveryBoyOrders(this.selecTextStatus.select);
        }
      }, {
        key: "OnChange",
        value: function OnChange(value) {
          this.status = value;
          console.log(this.status);
          this.fngetDeliveryBoyOrders(value);
        }
      }, {
        key: "fnOrderDetails",
        value: function fnOrderDetails(id) {
          this.navCtrl.navigateForward('order-details', {
            state: id
          });
        }
      }, {
        key: "presentAlertConfirm",
        value: function presentAlertConfirm() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this2 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.alertCtrl.create({
                      // header: 'Confirm!',
                      // message: "Please enable Your Location",
                      message: "Are you sure want to logout?",
                      buttons: [{
                        text: 'Cancel',
                        role: 'cancel',
                        handler: function handler() {
                          console.log('Cancel clicked');
                        }
                      }, {
                        text: 'Logout',
                        handler: function handler() {
                          _this2.fnLogout();

                          console.log('Logout clicked');
                        }
                      }]
                    });

                  case 2:
                    alert = _context.sent;
                    _context.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "fnLogout",
        value: function fnLogout() {
          localStorage.clear();
          this.navCtrl.navigateForward('home');
        }
      }, {
        key: "fnChangeStatus",
        value: function fnChangeStatus(id, status) {
          var _this3 = this;

          console.log(status);
          this.requestObject = {
            "order_id": id,
            "order_status": status,
            "user_id": this.user_id,
            "user_type": this.role
          };
          this.auth.showLoader();
          console.log(this.requestObject);
          this.auth.updateOrderStatus(this.requestObject).subscribe(function (data) {
            console.log(data);

            _this3.auth.hideLoader();

            _this3.auth.showToast('Order status updated succesfully');

            _this3.ngOnInit();
          }, function (err) {
            console.log("Error=>", err);

            _this3.auth.hideLoader();
          });
        }
      }]);

      return MyAccountPage;
    }();

    MyAccountPage.ctorParameters = function () {
      return [{
        type: _common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"]
      }, {
        type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"]
      }];
    };

    MyAccountPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-my-account',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./my-account.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/my-account/my-account.page.html"))["default"],
      providers: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"]],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./my-account.page.scss */
      "./src/app/my-account/my-account.page.scss"))["default"]]
    })], MyAccountPage);
    /***/
  }
}]);
//# sourceMappingURL=my-account-my-account-module-es5.js.map