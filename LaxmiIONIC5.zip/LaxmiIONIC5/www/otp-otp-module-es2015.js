(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["otp-otp-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/otp/otp.page.html":
/*!*************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/otp/otp.page.html ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <!-- <ion-back-button (click)=\"goBack()\" color=\"danger\"></ion-back-button>  -->\n      <ion-icon name=\"arrow-back-outline\" class=\"backarrow1\" (click)=\" goBack()\"></ion-icon>\n    </ion-buttons>\n    <ion-title class=\"main-title\">Enter OTP</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"background-image\">\n<div class=\"main-tag\">\n\n</div>\n  <p class=\"txt-1\">Let us know One time password (OTP)</p>\n  <p class=\"txt-1\">we'll send you OTP on your registered </p>\n  <p class=\"txt-1\">email address.</p>\n\n  <div class=\"order-no-bg\">\n    <ion-input class=\"order_no_txt\" [(ngModel)]=\"verifyOtp\" type=\"number\" placeholder=\"Enter One Time Password\" text-center>\n    </ion-input>\n  </div>\n\n  <div style=\"margin-top: 12%;\">\n    <button ion-button block class=\"send_btn\" (click)=\"verificationOtp()\">Submit</button>\n  </div>\n</ion-content>");

/***/ }),

/***/ "./src/app/otp/otp-routing.module.ts":
/*!*******************************************!*\
  !*** ./src/app/otp/otp-routing.module.ts ***!
  \*******************************************/
/*! exports provided: OtpPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OtpPageRoutingModule", function() { return OtpPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _otp_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./otp.page */ "./src/app/otp/otp.page.ts");




const routes = [
    {
        path: '',
        component: _otp_page__WEBPACK_IMPORTED_MODULE_3__["OtpPage"]
    }
];
let OtpPageRoutingModule = class OtpPageRoutingModule {
};
OtpPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], OtpPageRoutingModule);



/***/ }),

/***/ "./src/app/otp/otp.module.ts":
/*!***********************************!*\
  !*** ./src/app/otp/otp.module.ts ***!
  \***********************************/
/*! exports provided: OtpPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OtpPageModule", function() { return OtpPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _otp_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./otp-routing.module */ "./src/app/otp/otp-routing.module.ts");
/* harmony import */ var _otp_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./otp.page */ "./src/app/otp/otp.page.ts");







let OtpPageModule = class OtpPageModule {
};
OtpPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _otp_routing_module__WEBPACK_IMPORTED_MODULE_5__["OtpPageRoutingModule"]
        ],
        declarations: [_otp_page__WEBPACK_IMPORTED_MODULE_6__["OtpPage"]]
    })
], OtpPageModule);



/***/ }),

/***/ "./src/app/otp/otp.page.scss":
/*!***********************************!*\
  !*** ./src/app/otp/otp.page.scss ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".main-title {\n  text-align: center;\n  color: #E4322E;\n  margin-right: 42px;\n}\n\n.txt-1 {\n  color: #fff;\n  text-align: center;\n  line-height: 0.5rem;\n}\n\n.main-tag {\n  margin-bottom: 18%;\n  text-align: center;\n  margin-top: 25%;\n}\n\n.background-image {\n  /* In this example we are using a background-image. But the header element could be anything. */\n  --background: #E4322E;\n}\n\n.order_no_txt {\n  color: #010944;\n  font-size: 18px;\n  font-weight: bold;\n  font-family: open sans;\n}\n\n.send_btn {\n  background-color: #fff;\n  width: 90%;\n  border-radius: 8px;\n  display: block;\n  margin-top: 15%;\n  border: 1px solid #fff;\n  color: #E4322E;\n  font-size: 20px;\n  height: 45px;\n  margin: auto;\n}\n\n.order-no-bg {\n  background-color: #fff;\n  width: 90%;\n  height: 45px;\n  margin-left: 20px;\n  border-radius: 7px;\n  margin-top: 20%;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9vdHAvb3RwLnBhZ2Uuc2NzcyIsInNyYy9hcHAvb3RwL290cC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQ0FKOztBREVBO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUNDSjs7QURDQztFQUNHLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FDRUo7O0FEQUE7RUFDSSwrRkFBQTtFQUlBLHFCQUFBO0FDQUo7O0FERUU7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0Esc0JBQUE7QUNDSjs7QURDQTtFQUNJLHNCQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxzQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUNFSjs7QURBRTtFQUNFLHNCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FDR0oiLCJmaWxlIjoic3JjL2FwcC9vdHAvb3RwLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxuLm1haW4tdGl0bGV7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjRTQzMjJFO1xuICAgIG1hcmdpbi1yaWdodDogNDJweDtcbn1cbi50eHQtMXtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgbGluZS1oZWlnaHQ6IDAuNXJlbTtcbiB9XG4gLm1haW4tdGFne1xuICAgIG1hcmdpbi1ib3R0b206IDE4JTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgbWFyZ2luLXRvcDogMjUlO1xuICB9XG4uYmFja2dyb3VuZC1pbWFnZSB7XG4gICAgLyogSW4gdGhpcyBleGFtcGxlIHdlIGFyZSB1c2luZyBhIGJhY2tncm91bmQtaW1hZ2UuIEJ1dCB0aGUgaGVhZGVyIGVsZW1lbnQgY291bGQgYmUgYW55dGhpbmcuICovXG4gICAgLy8gLS1iYWNrZ3JvdW5kOiB1cmwoJy4uLy4uL2Fzc2V0cy9pbWdzL0xvZ2luU2NyZWVuXzEuanBnJykgMCAwLzEwMCUgMTAwJSBuby1yZXBlYXQ7XG4gICAgLy8gLS1iYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICAgIC8vIC0tYmFja2dyb3VuZC1zaXplOiBjb3ZlcjsgIFxuICAgIC0tYmFja2dyb3VuZDogI0U0MzIyRTtcbn1cbiAgLm9yZGVyX25vX3R4dHtcbiAgICBjb2xvcjogIzAxMDk0NDtcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cbi5zZW5kX2J0biB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgICB3aWR0aDogOTAlO1xuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBtYXJnaW4tdG9wOiAxNSU7XG4gICAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbiAgICBjb2xvcjogI0U0MzIyRTtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIG1hcmdpbjogYXV0bztcbiAgfVxuICAub3JkZXItbm8tYmd7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgICB3aWR0aDogOTAlO1xuICAgIGhlaWdodDogNDVweDtcbiAgICBtYXJnaW4tbGVmdDogMjBweDtcbiAgICBib3JkZXItcmFkaXVzOiA3cHg7XG4gICAgbWFyZ2luLXRvcDogMjAlO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbn0iLCIubWFpbi10aXRsZSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICNFNDMyMkU7XG4gIG1hcmdpbi1yaWdodDogNDJweDtcbn1cblxuLnR4dC0xIHtcbiAgY29sb3I6ICNmZmY7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbGluZS1oZWlnaHQ6IDAuNXJlbTtcbn1cblxuLm1haW4tdGFnIHtcbiAgbWFyZ2luLWJvdHRvbTogMTglO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbi10b3A6IDI1JTtcbn1cblxuLmJhY2tncm91bmQtaW1hZ2Uge1xuICAvKiBJbiB0aGlzIGV4YW1wbGUgd2UgYXJlIHVzaW5nIGEgYmFja2dyb3VuZC1pbWFnZS4gQnV0IHRoZSBoZWFkZXIgZWxlbWVudCBjb3VsZCBiZSBhbnl0aGluZy4gKi9cbiAgLS1iYWNrZ3JvdW5kOiAjRTQzMjJFO1xufVxuXG4ub3JkZXJfbm9fdHh0IHtcbiAgY29sb3I6ICMwMTA5NDQ7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG59XG5cbi5zZW5kX2J0biB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gIHdpZHRoOiA5MCU7XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbi10b3A6IDE1JTtcbiAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbiAgY29sb3I6ICNFNDMyMkU7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgaGVpZ2h0OiA0NXB4O1xuICBtYXJnaW46IGF1dG87XG59XG5cbi5vcmRlci1uby1iZyB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gIHdpZHRoOiA5MCU7XG4gIGhlaWdodDogNDVweDtcbiAgbWFyZ2luLWxlZnQ6IDIwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDdweDtcbiAgbWFyZ2luLXRvcDogMjAlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59Il19 */");

/***/ }),

/***/ "./src/app/otp/otp.page.ts":
/*!*********************************!*\
  !*** ./src/app/otp/otp.page.ts ***!
  \*********************************/
/*! exports provided: OtpPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OtpPage", function() { return OtpPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");





let OtpPage = class OtpPage {
    constructor(location, navCtrl, auth, toast) {
        this.location = location;
        this.navCtrl = navCtrl;
        this.auth = auth;
        this.toast = toast;
    }
    ngOnInit() {
        // this.email = localStorage.getItem("email");
        this.verifyOtp = "";
        this.email = localStorage.getItem('email');
        console.log(this.email);
    }
    verificationOtp() {
        if (this.verifyOtp != '') {
            this.requestObject = {
                "email": this.email,
                "otp": this.verifyOtp,
            };
            console.log(this.requestObject);
            //this.navCtrl.navigateForward('/update-password');
            this.auth.showLoader();
            this.auth.checkOtp(this.requestObject).subscribe((data) => {
                this.auth.hideLoader();
                console.log(data);
                this.dataResponse = data;
                if (this.dataResponse.status == true) {
                    this.navCtrl.navigateForward('/update-password');
                }
                else {
                    this.showToast1();
                }
            }, (err) => {
                this.auth.hideLoader();
                console.log("Error=>", err);
                //this.auth.showError(err.error.message);
            });
        }
        else {
            this.showToast();
        }
    }
    goBack() {
        this.location.back();
    }
    showToast() {
        this.myToast = this.toast.create({
            message: 'Enter OTP',
            duration: 2000
        }).then((toastData) => {
            console.log(toastData);
            toastData.present();
        });
    }
    showToast1() {
        this.myToast = this.toast.create({
            message: 'invalid otp',
            duration: 2000
        }).then((toastData) => {
            console.log(toastData);
            toastData.present();
        });
    }
};
OtpPage.ctorParameters = () => [
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["Location"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"] }
];
OtpPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-otp',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./otp.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/otp/otp.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./otp.page.scss */ "./src/app/otp/otp.page.scss")).default]
    })
], OtpPage);



/***/ })

}]);
//# sourceMappingURL=otp-otp-module-es2015.js.map