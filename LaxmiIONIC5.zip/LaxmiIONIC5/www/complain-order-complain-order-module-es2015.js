(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["complain-order-complain-order-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/complain-order/complain-order.page.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/complain-order/complain-order.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-icon name=\"arrow-back-outline\" class=\"backarrow1\" (click)=\"goBack()\"></ion-icon>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-button>\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"main-title\">Complaints</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div  *ngIf=\"DeliveredOrder!==0\">\n    <div class=\"ion-margin\">\n      <ion-item lines=\"none\" class=\"item-background-color\">\n        <ion-label class=\"color\">Order Id</ion-label>\n        <ion-select #item class=\"custom-options customer-filter color\" [(ngModel)]=\"orderId\"\n          (ionChange)=\"fnSelectOrderID(item.id)\">\n          <ion-select-option value=\"{{item.id}}\" *ngFor=\"let item of ordersList; let i = index\">{{item.order_number}}\n          </ion-select-option>\n        </ion-select>\n      </ion-item>\n    </div>\n    <div class=\"ion-margin order-no-bg\">\n      <ion-input placeholder=\"Product Name\" type=\"text\" [(ngModel)]=\"productName\" name=\"Name\" class=\"order_no_txt\">\n      </ion-input>\n    </div>\n\n    <div class=\"ion-margin complainArea\">\n      <ion-textarea placeholder=\"Write your complaint\" type=\"text\" [(ngModel)]=\"complain\" name=\"Name\"\n        class=\"order_no_txt\">\n      </ion-textarea>\n    </div>\n    <div class=\"ion-margin\" style=\"text-align: center;\">\n      <button ion-button class=\"download_btn\" (click)=\"fnSendComplaint()\">Send</button>\n    </div>\n  </div>\n  <div *ngIf=\"DeliveredOrder == 0\">\n    <p class=\"norecord-label\">There is no Deliverd Data found!</p>\n  </div>\n</ion-content>");

/***/ }),

/***/ "./src/app/complain-order/complain-order-routing.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/complain-order/complain-order-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: ComplainOrderPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComplainOrderPageRoutingModule", function() { return ComplainOrderPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _complain_order_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./complain-order.page */ "./src/app/complain-order/complain-order.page.ts");




const routes = [
    {
        path: '',
        component: _complain_order_page__WEBPACK_IMPORTED_MODULE_3__["ComplainOrderPage"]
    }
];
let ComplainOrderPageRoutingModule = class ComplainOrderPageRoutingModule {
};
ComplainOrderPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ComplainOrderPageRoutingModule);



/***/ }),

/***/ "./src/app/complain-order/complain-order.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/complain-order/complain-order.module.ts ***!
  \*********************************************************/
/*! exports provided: ComplainOrderPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComplainOrderPageModule", function() { return ComplainOrderPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _complain_order_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./complain-order-routing.module */ "./src/app/complain-order/complain-order-routing.module.ts");
/* harmony import */ var _complain_order_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./complain-order.page */ "./src/app/complain-order/complain-order.page.ts");







let ComplainOrderPageModule = class ComplainOrderPageModule {
};
ComplainOrderPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _complain_order_routing_module__WEBPACK_IMPORTED_MODULE_5__["ComplainOrderPageRoutingModule"]
        ],
        declarations: [_complain_order_page__WEBPACK_IMPORTED_MODULE_6__["ComplainOrderPage"]]
    })
], ComplainOrderPageModule);



/***/ }),

/***/ "./src/app/complain-order/complain-order.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/complain-order/complain-order.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".main-title {\n  text-align: center;\n  color: #E4322E;\n}\n\n.custom-options {\n  font-family: open sans;\n}\n\n.customer-filter {\n  padding: 0;\n}\n\n.item-background-color {\n  --ion-item-background:#f5f0f0;\n  border-radius: 7px;\n}\n\n.color {\n  color: #999999;\n}\n\n.order_no_txt {\n  text-align: start;\n  color: #010944;\n  margin-left: 5px;\n}\n\n.order-no-bg {\n  background-color: #f5f0f0;\n  /* width: 90%; */\n  height: 45px;\n  /* margin-left: 20px; */\n  border-radius: 7px;\n  /* margin-top: 20px;*/\n}\n\n.complainArea {\n  background-color: #f5f0f0;\n  /* width: 90%; */\n  height: 150px;\n  /* margin-left: 20px; */\n  border-radius: 7px;\n  padding: 5px;\n  /* margin-top: 20px;*/\n}\n\n.download_btn {\n  background-color: #E4322E;\n  color: #fff;\n  font-size: 20px;\n  height: 45px;\n  width: 100%;\n  border-radius: 10px;\n  display: block;\n  margin: auto;\n  border: 1px solid #fff;\n  margin-top: 3rem;\n}\n\n.norecord-label {\n  font-family: open sans;\n  color: #E4322E;\n  font-size: 18px;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9jb21wbGFpbi1vcmRlci9jb21wbGFpbi1vcmRlci5wYWdlLnNjc3MiLCJzcmMvYXBwL2NvbXBsYWluLW9yZGVyL2NvbXBsYWluLW9yZGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtCQUFBO0VBQ0EsY0FBQTtBQ0NKOztBRENDO0VBQ0csc0JBQUE7QUNFSjs7QURBQTtFQUNJLFVBQUE7QUNHSjs7QURERTtFQUNFLDZCQUFBO0VBQ0Esa0JBQUE7QUNJSjs7QURGQTtFQUNJLGNBQUE7QUNLSjs7QURIQTtFQUNJLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FDTUo7O0FESkM7RUFDRyx5QkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQkFBQTtBQ09KOztBRExDO0VBQ0cseUJBQUE7RUFDQSxnQkFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLHFCQUFBO0FDUUo7O0FETkM7RUFDRyx5QkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxnQkFBQTtBQ1NKOztBRFBFO0VBQ0Usc0JBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FDVUoiLCJmaWxlIjoic3JjL2FwcC9jb21wbGFpbi1vcmRlci9jb21wbGFpbi1vcmRlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWFpbi10aXRsZXtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICNFNDMyMkU7XG4gfVxuIC5jdXN0b20tb3B0aW9uc3tcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuLmN1c3RvbWVyLWZpbHRlcntcbiAgICBwYWRkaW5nOiAwO1xufVxuICAuaXRlbS1iYWNrZ3JvdW5kLWNvbG9ye1xuICAgIC0taW9uLWl0ZW0tYmFja2dyb3VuZDojZjVmMGYwO1xuICAgIGJvcmRlci1yYWRpdXM6IDdweDtcbn1cbi5jb2xvcntcbiAgICBjb2xvcjogIzk5OTk5OTtcbn1cbi5vcmRlcl9ub190eHR7XG4gICAgdGV4dC1hbGlnbjogc3RhcnQ7XG4gICAgY29sb3I6ICMwMTA5NDQ7XG4gICAgbWFyZ2luLWxlZnQ6IDVweDtcbiB9XG4gLm9yZGVyLW5vLWJne1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmNWYwZjA7XG4gICAgLyogd2lkdGg6IDkwJTsgKi9cbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgLyogbWFyZ2luLWxlZnQ6IDIwcHg7ICovXG4gICAgYm9yZGVyLXJhZGl1czogN3B4O1xuICAgIC8qIG1hcmdpbi10b3A6IDIwcHg7Ki9cbiB9XG4gLmNvbXBsYWluQXJlYXtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmMGYwO1xuICAgIC8qIHdpZHRoOiA5MCU7ICovXG4gICAgaGVpZ2h0OiAxNTBweDtcbiAgICAvKiBtYXJnaW4tbGVmdDogMjBweDsgKi9cbiAgICBib3JkZXItcmFkaXVzOiA3cHg7XG4gICAgcGFkZGluZzogNXB4O1xuICAgIC8qIG1hcmdpbi10b3A6IDIwcHg7Ki9cbiB9XG4gLmRvd25sb2FkX2J0bntcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTQzMjJFO1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBtYXJnaW46IGF1dG87XG4gICAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbiAgICBtYXJnaW4tdG9wOiAzcmVtO1xuICB9XG4gIC5ub3JlY29yZC1sYWJlbHtcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICAgIGNvbG9yOiNFNDMyMkU7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbn0iLCIubWFpbi10aXRsZSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICNFNDMyMkU7XG59XG5cbi5jdXN0b20tb3B0aW9ucyB7XG4gIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG59XG5cbi5jdXN0b21lci1maWx0ZXIge1xuICBwYWRkaW5nOiAwO1xufVxuXG4uaXRlbS1iYWNrZ3JvdW5kLWNvbG9yIHtcbiAgLS1pb24taXRlbS1iYWNrZ3JvdW5kOiNmNWYwZjA7XG4gIGJvcmRlci1yYWRpdXM6IDdweDtcbn1cblxuLmNvbG9yIHtcbiAgY29sb3I6ICM5OTk5OTk7XG59XG5cbi5vcmRlcl9ub190eHQge1xuICB0ZXh0LWFsaWduOiBzdGFydDtcbiAgY29sb3I6ICMwMTA5NDQ7XG4gIG1hcmdpbi1sZWZ0OiA1cHg7XG59XG5cbi5vcmRlci1uby1iZyB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmNWYwZjA7XG4gIC8qIHdpZHRoOiA5MCU7ICovXG4gIGhlaWdodDogNDVweDtcbiAgLyogbWFyZ2luLWxlZnQ6IDIwcHg7ICovXG4gIGJvcmRlci1yYWRpdXM6IDdweDtcbiAgLyogbWFyZ2luLXRvcDogMjBweDsqL1xufVxuXG4uY29tcGxhaW5BcmVhIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjBmMDtcbiAgLyogd2lkdGg6IDkwJTsgKi9cbiAgaGVpZ2h0OiAxNTBweDtcbiAgLyogbWFyZ2luLWxlZnQ6IDIwcHg7ICovXG4gIGJvcmRlci1yYWRpdXM6IDdweDtcbiAgcGFkZGluZzogNXB4O1xuICAvKiBtYXJnaW4tdG9wOiAyMHB4OyovXG59XG5cbi5kb3dubG9hZF9idG4ge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTQzMjJFO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBoZWlnaHQ6IDQ1cHg7XG4gIHdpZHRoOiAxMDAlO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBkaXNwbGF5OiBibG9jaztcbiAgbWFyZ2luOiBhdXRvO1xuICBib3JkZXI6IDFweCBzb2xpZCAjZmZmO1xuICBtYXJnaW4tdG9wOiAzcmVtO1xufVxuXG4ubm9yZWNvcmQtbGFiZWwge1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICBjb2xvcjogI0U0MzIyRTtcbiAgZm9udC1zaXplOiAxOHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59Il19 */");

/***/ }),

/***/ "./src/app/complain-order/complain-order.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/complain-order/complain-order.page.ts ***!
  \*******************************************************/
/*! exports provided: ComplainOrderPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComplainOrderPage", function() { return ComplainOrderPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth.service.ts");





let ComplainOrderPage = class ComplainOrderPage {
    constructor(location, menu, auth) {
        this.location = location;
        this.menu = menu;
        this.auth = auth;
        this.ordersList = [];
        this.orderId = '';
        this.complain = '';
        this.productName = '';
        this.DeliveredOrder = 0;
        this.dataOrder = false;
        this.menu.enable(true);
        this.user_id = localStorage.getItem("id");
    }
    ngOnInit() {
        this.fngetOrderList();
    }
    goBack() {
        this.location.back();
    }
    fngetOrderList() {
        let requestObject = {
            "order_status": "Delivered",
            "user_id": this.user_id
        };
        this.auth.showLoader();
        console.log(requestObject);
        this.auth.getOrderList(requestObject).subscribe((data) => {
            console.log(data);
            this.auth.hideLoader();
            this.dataResponse = data.data;
            this.ordersList = this.dataResponse;
            this.DeliveredOrder = this.ordersList.length;
            console.log("order DeliveredOrder-->", this.DeliveredOrder);
        }, (err) => {
            console.log("Error=>", err);
            this.auth.hideLoader();
        });
    }
    fnSelectOrderID(id) {
        console.log(id);
    }
    fnSendComplaint() {
        if (this.complain !== '' && this.user_id !== '') {
            let requestObject = {
                "complain": this.complain,
                "order_id": this.orderId,
                "user_id": this.user_id
            };
            this.auth.showLoader();
            console.log(requestObject);
            this.auth.complainOrder(requestObject).subscribe((data) => {
                console.log(data);
                this.auth.hideLoader();
                if (data.status === true) {
                    this.auth.showToast(data.message);
                    this.complain = '';
                    this.productName = '';
                    this.orderId = '';
                }
            }, (err) => {
                console.log("Error=>", err);
                this.auth.hideLoader();
            });
        }
        else {
            this.auth.showToast("Please Enter Order id and complain!");
        }
    }
};
ComplainOrderPage.ctorParameters = () => [
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_2__["Location"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] }
];
ComplainOrderPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-complain-order',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./complain-order.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/complain-order/complain-order.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./complain-order.page.scss */ "./src/app/complain-order/complain-order.page.scss")).default]
    })
], ComplainOrderPage);



/***/ })

}]);
//# sourceMappingURL=complain-order-complain-order-module-es2015.js.map