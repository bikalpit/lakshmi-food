(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["cancel-order-cancel-order-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/cancel-order/cancel-order.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cancel-order/cancel-order.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <!-- <ion-back-button (click)=\"goBack()\" color=\"danger\"></ion-back-button> -->\n      <ion-icon name=\"arrow-back-outline\" (click)=\"goBack()\" class=\"backarrow1\"></ion-icon>\n    </ion-buttons>\n\n    <ion-buttons slot=\"end\">\n      <ion-button>\n\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"main-title\">Cancel Order</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <h4 class=\"cancel-label\"><b>Cancel Order</b></h4>\n\n  <div class=\"order-no-bg\">\n   \n    <ion-input disabled placeholder=\"Order No\" [(ngModel)]=\"orderNum\" class=\"order_no_txt\"></ion-input>\n  </div>\n\n  <!-- <div class=\"order-Cancel-bg\">\n    <textarea placeholder=\"Reason For Cancel Order\"  [(ngModel)]=\"reason\" class=\"order_Cancel_txt\"></textarea>\n  </div> -->\n  <form [formGroup]=\"ionicForm\">\n  <div class=\"txt_bg_area\">\n\n    <ion-textarea formControlName=\"reason\" placeholder=\"Reason For Cancel Order\" class=\"area-txt\"></ion-textarea>\n    <span class=\"error-wrap\"\n    *ngIf=\"ionicForm.get('reason').touched || ionicForm.get('reason').dirty || formSubmitclicked\">\n    <small *ngIf=\"ionicForm.get('reason').hasError('required')\" class=\"error\">Reason is required.</small>\n   \n  </span>\n  </div>\n</form>\n  <button ion-button class=\"CancelOrder_btn\" (click)=\"fnCancelOrder()\"><b>Cancel Order</b></button>\n</ion-content>");

/***/ }),

/***/ "./src/app/cancel-order/cancel-order-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/cancel-order/cancel-order-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: CancelOrderPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CancelOrderPageRoutingModule", function() { return CancelOrderPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _cancel_order_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./cancel-order.page */ "./src/app/cancel-order/cancel-order.page.ts");




const routes = [
    {
        path: '',
        component: _cancel_order_page__WEBPACK_IMPORTED_MODULE_3__["CancelOrderPage"]
    }
];
let CancelOrderPageRoutingModule = class CancelOrderPageRoutingModule {
};
CancelOrderPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CancelOrderPageRoutingModule);



/***/ }),

/***/ "./src/app/cancel-order/cancel-order.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/cancel-order/cancel-order.module.ts ***!
  \*****************************************************/
/*! exports provided: CancelOrderPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CancelOrderPageModule", function() { return CancelOrderPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _cancel_order_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./cancel-order-routing.module */ "./src/app/cancel-order/cancel-order-routing.module.ts");
/* harmony import */ var _cancel_order_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./cancel-order.page */ "./src/app/cancel-order/cancel-order.page.ts");







let CancelOrderPageModule = class CancelOrderPageModule {
};
CancelOrderPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _cancel_order_routing_module__WEBPACK_IMPORTED_MODULE_5__["CancelOrderPageRoutingModule"]
        ],
        declarations: [_cancel_order_page__WEBPACK_IMPORTED_MODULE_6__["CancelOrderPage"]]
    })
], CancelOrderPageModule);



/***/ }),

/***/ "./src/app/cancel-order/cancel-order.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/cancel-order/cancel-order.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".menu_btn {\n  color: #E4322E;\n}\n\n.main-title {\n  text-align: center;\n  color: #E4322E;\n}\n\n.cancel-label {\n  color: #E4322E;\n  margin-left: 22px;\n  margin-bottom: 25px;\n  margin-top: 25px;\n}\n\n.order-no-bg {\n  background-color: #f5f0f0;\n  width: 90%;\n  height: 70px;\n  margin-left: 20px;\n  border-radius: 7px;\n}\n\n.order_no_txt {\n  color: #010944;\n}\n\n.order_Cancel_txt {\n  margin-top: 10%;\n  color: #010944;\n  height: 85%;\n}\n\n.order-Cancel-bg {\n  background-color: #f5f0f0;\n  width: 90%;\n  height: 140px;\n  margin-left: 20px;\n  border-radius: 7px;\n}\n\n.CancelOrder_btn {\n  background-color: #E4322E;\n  color: #fff;\n  font-size: 20px;\n  height: 40px;\n  width: 90%;\n  border-radius: 8px;\n  display: block;\n  margin: auto;\n  border: 1px solid #fff;\n  margin-top: 10%;\n}\n\n.area-txt {\n  margin: 20px 0px 0px 0px;\n  height: 120px;\n  color: #010944;\n  padding: 10px;\n}\n\n.txt_bg_area {\n  background: #f5f0f0;\n  margin-top: 18px;\n  margin-left: 20px;\n  width: 90%;\n  height: 120px;\n  border-radius: 6px;\n}\n\n.error-wrap {\n  color: #E4322E;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9jYW5jZWwtb3JkZXIvY2FuY2VsLW9yZGVyLnBhZ2Uuc2NzcyIsInNyYy9hcHAvY2FuY2VsLW9yZGVyL2NhbmNlbC1vcmRlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0FDQ0o7O0FEQ0E7RUFDSSxrQkFBQTtFQUNBLGNBQUE7QUNFSjs7QURBQTtFQUNJLGNBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUNHSjs7QUREQTtFQUNJLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FDSUo7O0FERkE7RUFDSSxjQUFBO0FDS0o7O0FESEE7RUFDSSxlQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QUNNSjs7QURKQTtFQUNJLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FDT0o7O0FETEE7RUFDSSx5QkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxlQUFBO0FDUUo7O0FETkE7RUFDSSx3QkFBQTtFQUVBLGFBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtBQ1FKOztBRE5BO0VBQ0ksbUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsVUFBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtBQ1NKOztBRFBBO0VBQ0ksY0FBQTtBQ1VKIiwiZmlsZSI6InNyYy9hcHAvY2FuY2VsLW9yZGVyL2NhbmNlbC1vcmRlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWVudV9idG57XG4gICAgY29sb3I6ICNFNDMyMkU7XG59XG4ubWFpbi10aXRsZXtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICNFNDMyMkU7XG59XG4uY2FuY2VsLWxhYmVse1xuICAgIGNvbG9yOiAjRTQzMjJFO1xuICAgIG1hcmdpbi1sZWZ0OiAyMnB4O1xuICAgIG1hcmdpbi1ib3R0b206IDI1cHg7XG4gICAgbWFyZ2luLXRvcDogMjVweDtcbn1cbi5vcmRlci1uby1iZ3tcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmMGYwO1xuICAgIHdpZHRoOiA5MCU7XG4gICAgaGVpZ2h0OiA3MHB4O1xuICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDdweDtcbn1cbi5vcmRlcl9ub190eHR7XG4gICAgY29sb3I6ICMwMTA5NDQ7XG59XG4ub3JkZXJfQ2FuY2VsX3R4dHtcbiAgICBtYXJnaW4tdG9wOiAxMCU7XG4gICAgY29sb3I6ICMwMTA5NDQ7XG4gICAgaGVpZ2h0OiA4NSU7XG59XG4ub3JkZXItQ2FuY2VsLWJne1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmNWYwZjA7XG4gICAgd2lkdGg6IDkwJTtcbiAgICBoZWlnaHQ6IDE0MHB4O1xuICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDdweDtcbn1cbi5DYW5jZWxPcmRlcl9idG57XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0U0MzIyRTtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgaGVpZ2h0OiA0MHB4O1xuICAgIHdpZHRoOiA5MCU7XG4gICAgYm9yZGVyLXJhZGl1czogOHB4O1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIG1hcmdpbjogYXV0bztcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZmZmO1xuICAgIG1hcmdpbi10b3A6IDEwJTtcbn1cbi5hcmVhLXR4dHtcbiAgICBtYXJnaW46IDIwcHggMHB4IDBweCAwcHg7XG4gICAgLy8gd2lkdGg6IDI5M3B4O1xuICAgIGhlaWdodDogMTIwcHg7XG4gICAgY29sb3I6ICMwMTA5NDQ7XG4gICAgcGFkZGluZzogMTBweDtcbn1cbi50eHRfYmdfYXJlYXtcbiAgICBiYWNrZ3JvdW5kOiAjZjVmMGYwO1xuICAgIG1hcmdpbi10b3A6IDE4cHg7XG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XG4gICAgd2lkdGg6IDkwJTtcbiAgICBoZWlnaHQ6IDEyMHB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDZweDtcbn1cbi5lcnJvci13cmFwe1xuICAgIGNvbG9yOiNFNDMyMkU7XG4gIH1cbiIsIi5tZW51X2J0biB7XG4gIGNvbG9yOiAjRTQzMjJFO1xufVxuXG4ubWFpbi10aXRsZSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICNFNDMyMkU7XG59XG5cbi5jYW5jZWwtbGFiZWwge1xuICBjb2xvcjogI0U0MzIyRTtcbiAgbWFyZ2luLWxlZnQ6IDIycHg7XG4gIG1hcmdpbi1ib3R0b206IDI1cHg7XG4gIG1hcmdpbi10b3A6IDI1cHg7XG59XG5cbi5vcmRlci1uby1iZyB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmNWYwZjA7XG4gIHdpZHRoOiA5MCU7XG4gIGhlaWdodDogNzBweDtcbiAgbWFyZ2luLWxlZnQ6IDIwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDdweDtcbn1cblxuLm9yZGVyX25vX3R4dCB7XG4gIGNvbG9yOiAjMDEwOTQ0O1xufVxuXG4ub3JkZXJfQ2FuY2VsX3R4dCB7XG4gIG1hcmdpbi10b3A6IDEwJTtcbiAgY29sb3I6ICMwMTA5NDQ7XG4gIGhlaWdodDogODUlO1xufVxuXG4ub3JkZXItQ2FuY2VsLWJnIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjBmMDtcbiAgd2lkdGg6IDkwJTtcbiAgaGVpZ2h0OiAxNDBweDtcbiAgbWFyZ2luLWxlZnQ6IDIwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDdweDtcbn1cblxuLkNhbmNlbE9yZGVyX2J0biB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNFNDMyMkU7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LXNpemU6IDIwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgd2lkdGg6IDkwJTtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBkaXNwbGF5OiBibG9jaztcbiAgbWFyZ2luOiBhdXRvO1xuICBib3JkZXI6IDFweCBzb2xpZCAjZmZmO1xuICBtYXJnaW4tdG9wOiAxMCU7XG59XG5cbi5hcmVhLXR4dCB7XG4gIG1hcmdpbjogMjBweCAwcHggMHB4IDBweDtcbiAgaGVpZ2h0OiAxMjBweDtcbiAgY29sb3I6ICMwMTA5NDQ7XG4gIHBhZGRpbmc6IDEwcHg7XG59XG5cbi50eHRfYmdfYXJlYSB7XG4gIGJhY2tncm91bmQ6ICNmNWYwZjA7XG4gIG1hcmdpbi10b3A6IDE4cHg7XG4gIG1hcmdpbi1sZWZ0OiAyMHB4O1xuICB3aWR0aDogOTAlO1xuICBoZWlnaHQ6IDEyMHB4O1xuICBib3JkZXItcmFkaXVzOiA2cHg7XG59XG5cbi5lcnJvci13cmFwIHtcbiAgY29sb3I6ICNFNDMyMkU7XG59Il19 */");

/***/ }),

/***/ "./src/app/cancel-order/cancel-order.page.ts":
/*!***************************************************!*\
  !*** ./src/app/cancel-order/cancel-order.page.ts ***!
  \***************************************************/
/*! exports provided: CancelOrderPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CancelOrderPage", function() { return CancelOrderPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");







let CancelOrderPage = class CancelOrderPage {
    constructor(formbulider, router, location, navCtrl, auth) {
        this.formbulider = formbulider;
        this.router = router;
        this.location = location;
        this.navCtrl = navCtrl;
        this.auth = auth;
        const state = this.router.getCurrentNavigation().extras.state;
        if (state) {
            console.log(state);
            this.id = state.id;
            this.orderNum = '# Order Number : ' + state.order_number;
            this.cancel_by = state.cancel_by;
        }
        this.ionicForm = this.formbulider.group({
            reason: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].required]],
        });
    }
    ngOnInit() {
    }
    fnCancelOrder() {
        if (this.ionicForm.value.reason) {
            let requestObject = {
                "order_id": this.id,
                "cancel_reason": this.ionicForm.value.reason,
                "cancel_by": this.cancel_by
            };
            this.auth.showLoader();
            this.auth.cancelOrder(requestObject).subscribe((data) => {
                this.auth.hideLoader();
                this.auth.showToast('Your order has been cancelled.');
                console.log("cancel order-->", data);
                if (this.cancel_by == "CC") {
                    this.navCtrl.navigateForward('customer-orders');
                }
                else {
                    this.navCtrl.navigateRoot('/my-account');
                }
            }, (err) => {
                this.auth.hideLoader();
                console.log("Error=>", err);
            });
        }
        else {
            this.auth.showToast('Enter reason!');
        }
    }
    goBack() {
        this.location.back();
    }
};
CancelOrderPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormBuilder"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["Location"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] }
];
CancelOrderPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-cancel-order',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./cancel-order.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/cancel-order/cancel-order.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./cancel-order.page.scss */ "./src/app/cancel-order/cancel-order.page.scss")).default]
    })
], CancelOrderPage);



/***/ })

}]);
//# sourceMappingURL=cancel-order-cancel-order-module-es2015.js.map