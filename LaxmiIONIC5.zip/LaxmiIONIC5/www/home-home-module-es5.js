function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html":
  /*!***************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
    \***************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppHomeHomePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content class=\"background-image\" scroll=\"true\" overflow-scroll=\"false\">\n\n    <div class=\"center\">\n      <div style=\"width: 100%;margin: 20px;\">\n      <img src=\"../../assets/imgs/logo.png\" class=\"logo\">\n      <h3 class=\"ion-text-center\">Sign in</h3>\n      <ion-list no-lines class=\"form\" id=\"register_form\">\n          <ion-item style=\"align-items: flex-end;\">\n              <ion-icon color=\"primary\"  name=\"call-sharp\" slot=\"start\"></ion-icon>\n              <ion-label position=\"floating\">Phone Number</ion-label>\n              <ion-input maxlength=\"10\" [(ngModel)]=\"login.phone\" type=\"tel\" name=\"phone\"></ion-input>\n          </ion-item>\n          <ion-item style=\"align-items: flex-end;\">\n              <ion-icon color=\"primary\"  name=\"lock-closed\" slot=\"start\"></ion-icon>\n              <ion-label position=\"floating\">Password</ion-label>\n              <ion-input  [(ngModel)]=\"login.password\" name=\"password\"  type=\"{{showPass==false?'password':'text'}}\"></ion-input>\n              <ion-icon  name=\"{{showPass==false?'eye-off':'eye'}}\" slot=\"end\"  (click)=\"fnShowPass()\"></ion-icon>\n          </ion-item>\n          <div class=\"ion-text-end ion-margin-top\">Forgot?</div>\n      </ion-list>\n      \n      <ion-button small expand=\"full\" (click)=\"fnLogin()\">Sign in</ion-button>\n      <p class=\"ion-text-center\">Oh! Not Registered yet?</p>\n      <ion-button small expand=\"block\" fill=\"outline\" (click)=\"fnSignUp()\">Register Now</ion-button>\n      </div>\n  </div>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/home/home-routing.module.ts":
  /*!*********************************************!*\
    !*** ./src/app/home/home-routing.module.ts ***!
    \*********************************************/

  /*! exports provided: HomePageRoutingModule */

  /***/
  function srcAppHomeHomeRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function () {
      return HomePageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./home.page */
    "./src/app/home/home.page.ts");

    var routes = [{
      path: '',
      component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"]
    }];

    var HomePageRoutingModule = function HomePageRoutingModule() {
      _classCallCheck(this, HomePageRoutingModule);
    };

    HomePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], HomePageRoutingModule);
    /***/
  },

  /***/
  "./src/app/home/home.module.ts":
  /*!*************************************!*\
    !*** ./src/app/home/home.module.ts ***!
    \*************************************/

  /*! exports provided: HomePageModule */

  /***/
  function srcAppHomeHomeModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePageModule", function () {
      return HomePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _home_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./home.page */
    "./src/app/home/home.page.ts");
    /* harmony import */


    var _home_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./home-routing.module */
    "./src/app/home/home-routing.module.ts");

    var HomePageModule = function HomePageModule() {
      _classCallCheck(this, HomePageModule);
    };

    HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"], _home_routing_module__WEBPACK_IMPORTED_MODULE_6__["HomePageRoutingModule"]],
      declarations: [_home_page__WEBPACK_IMPORTED_MODULE_5__["HomePage"]]
    })], HomePageModule);
    /***/
  },

  /***/
  "./src/app/home/home.page.scss":
  /*!*************************************!*\
    !*** ./src/app/home/home.page.scss ***!
    \*************************************/

  /*! exports provided: default */

  /***/
  function srcAppHomeHomePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "/* #container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\n.background-image {\n  --background: url(\"../../assets/imgs/LoginScreen_1.jpg\") 0 0/100% 100% no-repeat;\n  position: relative;\n  display: inline-block;\n\n}\n.scroll-content {\n  padding-bottom: 0px !important;\n}\n.main-class {\n  width: 100%;\n  margin: 18% 11% 0;\n}\n\n.sign-label {\n  color: #ffffff;\n  font-size: 28px;\n  font-family: open sans;\n}\n\n.login_text {\n  background-color: #fff;\n  width: 77%;\n  margin-top: 16px;\n  color: #000;\n  padding-left: 2px;\n  font-family: open sans;\n  border-radius: 8px;\n}\n\n.forgot-label {\n  float: right;\n  margin-right: 22%;\n  margin-top: 8%;\n  font-family: open sans;\n  color: #fff;\n}\n\n.login_btn {\n  background-color: #fff;\n  width: 77%;\n  border-radius: 8px;\n  display: block;\n  margin-top: 7rem;\n  border: 1px solid #fff;\n  color: #e4322e;\n  font-size: 20px;\n  height: 35px;\n  position: fixed;\n}\n\n.signup-label {\n  margin-top: 70%;\n  color: #e4322e;\n  font-family: open sans;\n}\n\n.my-custom-class {\n  background: #ffdb22;\n  color: #ff3f22;\n  border-style: solid;\n  border-width: 5px;\n  border-color: #ff3f22;\n}\n\n.login_signup {\n  position: fixed;\n  bottom: 0;\n  width: 100%;\n  font-size: 18px;\n  color: #ff3f22;\n  text-align: center;\n}\nbody.hide-on-keyboard-open .scroll-content {\n  margin-bottom: 0px !important;\n}\nbody.hide-on-keyboard-open .footer {\n  display: none;\n}\nion-footer {\n  display: contents !important;\n}\nion-content{\n  --ion-background-color:#e4322e;\n} */\n.logo {\n  width: 130px;\n  margin: auto;\n  margin-bottom: 20px;\n  display: block;\n}\n.form {\n  margin-bottom: 40px;\n}\np {\n  line-height: 30px;\n  padding-top: 10px;\n  font-size: 1rem;\n  font-weight: 600;\n}\n.center {\n  height: 100%;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n.reg-button {\n  height: 90% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9ob21lL2hvbWUucGFnZS5zY3NzIiwic3JjL2FwcC9ob21lL2hvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBQUE7QUFpSEE7RUFDRSxZQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtBQ0ZGO0FESUE7RUFDRSxtQkFBQTtBQ0RGO0FER0E7RUFDRSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FDQUY7QURFQTtFQUNFLFlBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQ0NGO0FEQ0E7RUFDRSxzQkFBQTtBQ0VGIiwiZmlsZSI6InNyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8qICNjb250YWluZXIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMDtcbiAgcmlnaHQ6IDA7XG4gIHRvcDogNTAlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XG59XG5cbiNjb250YWluZXIgc3Ryb25nIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBsaW5lLWhlaWdodDogMjZweDtcbn1cblxuI2NvbnRhaW5lciBwIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBsaW5lLWhlaWdodDogMjJweDtcbiAgY29sb3I6ICM4YzhjOGM7XG4gIG1hcmdpbjogMDtcbn1cblxuI2NvbnRhaW5lciBhIHtcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xufVxuXG4uYmFja2dyb3VuZC1pbWFnZSB7XG4gIC0tYmFja2dyb3VuZDogdXJsKFwiLi4vLi4vYXNzZXRzL2ltZ3MvTG9naW5TY3JlZW5fMS5qcGdcIikgMCAwLzEwMCUgMTAwJSBuby1yZXBlYXQ7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuIFxufVxuLnNjcm9sbC1jb250ZW50IHtcbiAgcGFkZGluZy1ib3R0b206IDBweCAhaW1wb3J0YW50O1xufVxuLm1haW4tY2xhc3Mge1xuICB3aWR0aDogMTAwJTtcbiAgbWFyZ2luOiAxOCUgMTElIDA7XG59XG5cbi5zaWduLWxhYmVsIHtcbiAgY29sb3I6ICNmZmZmZmY7XG4gIGZvbnQtc2l6ZTogMjhweDtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cblxuLmxvZ2luX3RleHQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICB3aWR0aDogNzclO1xuICBtYXJnaW4tdG9wOiAxNnB4O1xuICBjb2xvcjogIzAwMDtcbiAgcGFkZGluZy1sZWZ0OiAycHg7XG4gIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbn1cblxuLmZvcmdvdC1sYWJlbCB7XG4gIGZsb2F0OiByaWdodDtcbiAgbWFyZ2luLXJpZ2h0OiAyMiU7XG4gIG1hcmdpbi10b3A6IDglO1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICBjb2xvcjogI2ZmZjtcbn1cblxuLmxvZ2luX2J0biB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gIHdpZHRoOiA3NyU7XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbi10b3A6IDdyZW07XG4gIGJvcmRlcjogMXB4IHNvbGlkICNmZmY7XG4gIGNvbG9yOiAjZTQzMjJlO1xuICBmb250LXNpemU6IDIwcHg7XG4gIGhlaWdodDogMzVweDtcbiAgcG9zaXRpb246IGZpeGVkO1xufVxuXG4uc2lnbnVwLWxhYmVsIHtcbiAgbWFyZ2luLXRvcDogNzAlO1xuICBjb2xvcjogI2U0MzIyZTtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cblxuLm15LWN1c3RvbS1jbGFzcyB7XG4gIGJhY2tncm91bmQ6ICNmZmRiMjI7XG4gIGNvbG9yOiAjZmYzZjIyO1xuICBib3JkZXItc3R5bGU6IHNvbGlkO1xuICBib3JkZXItd2lkdGg6IDVweDtcbiAgYm9yZGVyLWNvbG9yOiAjZmYzZjIyO1xufVxuXG4ubG9naW5fc2lnbnVwIHtcbiAgcG9zaXRpb246IGZpeGVkO1xuICBib3R0b206IDA7XG4gIHdpZHRoOiAxMDAlO1xuICBmb250LXNpemU6IDE4cHg7XG4gIGNvbG9yOiAjZmYzZjIyO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5ib2R5LmhpZGUtb24ta2V5Ym9hcmQtb3BlbiAuc2Nyb2xsLWNvbnRlbnQge1xuICBtYXJnaW4tYm90dG9tOiAwcHggIWltcG9ydGFudDtcbn1cbmJvZHkuaGlkZS1vbi1rZXlib2FyZC1vcGVuIC5mb290ZXIge1xuICBkaXNwbGF5OiBub25lO1xufVxuaW9uLWZvb3RlciB7XG4gIGRpc3BsYXk6IGNvbnRlbnRzICFpbXBvcnRhbnQ7XG59XG5pb24tY29udGVudHtcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjojZTQzMjJlO1xufSAqL1xuXG4vL2J5IGFyc2hhZFxuXG4ubG9nbyB7XG4gIHdpZHRoOiAxMzBweDtcbiAgbWFyZ2luOiBhdXRvO1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICBkaXNwbGF5OiBibG9jaztcbn1cbi5mb3JtIHtcbiAgbWFyZ2luLWJvdHRvbTogNDBweDtcbn1cbnAge1xuICBsaW5lLWhlaWdodDogMzBweDtcbiAgcGFkZGluZy10b3A6IDEwcHg7XG4gIGZvbnQtc2l6ZTogMXJlbTtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbn1cbi5jZW50ZXJ7XG4gIGhlaWdodDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG4ucmVnLWJ1dHRvbntcbiAgaGVpZ2h0OiA5MCUgIWltcG9ydGFudDtcbn1cbiIsIi8qICNjb250YWluZXIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMDtcbiAgcmlnaHQ6IDA7XG4gIHRvcDogNTAlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XG59XG5cbiNjb250YWluZXIgc3Ryb25nIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBsaW5lLWhlaWdodDogMjZweDtcbn1cblxuI2NvbnRhaW5lciBwIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBsaW5lLWhlaWdodDogMjJweDtcbiAgY29sb3I6ICM4YzhjOGM7XG4gIG1hcmdpbjogMDtcbn1cblxuI2NvbnRhaW5lciBhIHtcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xufVxuXG4uYmFja2dyb3VuZC1pbWFnZSB7XG4gIC0tYmFja2dyb3VuZDogdXJsKFwiLi4vLi4vYXNzZXRzL2ltZ3MvTG9naW5TY3JlZW5fMS5qcGdcIikgMCAwLzEwMCUgMTAwJSBuby1yZXBlYXQ7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuXG59XG4uc2Nyb2xsLWNvbnRlbnQge1xuICBwYWRkaW5nLWJvdHRvbTogMHB4ICFpbXBvcnRhbnQ7XG59XG4ubWFpbi1jbGFzcyB7XG4gIHdpZHRoOiAxMDAlO1xuICBtYXJnaW46IDE4JSAxMSUgMDtcbn1cblxuLnNpZ24tbGFiZWwge1xuICBjb2xvcjogI2ZmZmZmZjtcbiAgZm9udC1zaXplOiAyOHB4O1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuXG4ubG9naW5fdGV4dCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gIHdpZHRoOiA3NyU7XG4gIG1hcmdpbi10b3A6IDE2cHg7XG4gIGNvbG9yOiAjMDAwO1xuICBwYWRkaW5nLWxlZnQ6IDJweDtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xufVxuXG4uZm9yZ290LWxhYmVsIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBtYXJnaW4tcmlnaHQ6IDIyJTtcbiAgbWFyZ2luLXRvcDogOCU7XG4gIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG4gIGNvbG9yOiAjZmZmO1xufVxuXG4ubG9naW5fYnRuIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgd2lkdGg6IDc3JTtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBkaXNwbGF5OiBibG9jaztcbiAgbWFyZ2luLXRvcDogN3JlbTtcbiAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbiAgY29sb3I6ICNlNDMyMmU7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgaGVpZ2h0OiAzNXB4O1xuICBwb3NpdGlvbjogZml4ZWQ7XG59XG5cbi5zaWdudXAtbGFiZWwge1xuICBtYXJnaW4tdG9wOiA3MCU7XG4gIGNvbG9yOiAjZTQzMjJlO1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuXG4ubXktY3VzdG9tLWNsYXNzIHtcbiAgYmFja2dyb3VuZDogI2ZmZGIyMjtcbiAgY29sb3I6ICNmZjNmMjI7XG4gIGJvcmRlci1zdHlsZTogc29saWQ7XG4gIGJvcmRlci13aWR0aDogNXB4O1xuICBib3JkZXItY29sb3I6ICNmZjNmMjI7XG59XG5cbi5sb2dpbl9zaWdudXAge1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIGJvdHRvbTogMDtcbiAgd2lkdGg6IDEwMCU7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgY29sb3I6ICNmZjNmMjI7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbmJvZHkuaGlkZS1vbi1rZXlib2FyZC1vcGVuIC5zY3JvbGwtY29udGVudCB7XG4gIG1hcmdpbi1ib3R0b206IDBweCAhaW1wb3J0YW50O1xufVxuYm9keS5oaWRlLW9uLWtleWJvYXJkLW9wZW4gLmZvb3RlciB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5pb24tZm9vdGVyIHtcbiAgZGlzcGxheTogY29udGVudHMgIWltcG9ydGFudDtcbn1cbmlvbi1jb250ZW50e1xuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiNlNDMyMmU7XG59ICovXG4ubG9nbyB7XG4gIHdpZHRoOiAxMzBweDtcbiAgbWFyZ2luOiBhdXRvO1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICBkaXNwbGF5OiBibG9jaztcbn1cblxuLmZvcm0ge1xuICBtYXJnaW4tYm90dG9tOiA0MHB4O1xufVxuXG5wIHtcbiAgbGluZS1oZWlnaHQ6IDMwcHg7XG4gIHBhZGRpbmctdG9wOiAxMHB4O1xuICBmb250LXNpemU6IDFyZW07XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG5cbi5jZW50ZXIge1xuICBoZWlnaHQ6IDEwMCU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4ucmVnLWJ1dHRvbiB7XG4gIGhlaWdodDogOTAlICFpbXBvcnRhbnQ7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/home/home.page.ts":
  /*!***********************************!*\
    !*** ./src/app/home/home.page.ts ***!
    \***********************************/

  /*! exports provided: HomePage */

  /***/
  function srcAppHomeHomePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePage", function () {
      return HomePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../auth.service */
    "./src/app/auth.service.ts");
    /* harmony import */


    var _ionic_native_keyboard_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic-native/keyboard/ngx */
    "./node_modules/@ionic-native/keyboard/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../../environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _global_foo_service_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../global-foo-service.service */
    "./src/app/global-foo-service.service.ts");

    var HomePage = /*#__PURE__*/function () {
      function HomePage(navCtrl, globalFooService, auth, toast, loadingCtrl, keyboard) {
        var _this = this;

        _classCallCheck(this, HomePage);

        /*
            if(localStorage.getItem('id')){
                this.navCtrl.navigateRoot('/dashboard');
                return;
            } */
        this.navCtrl = navCtrl;
        this.globalFooService = globalFooService;
        this.auth = auth;
        this.toast = toast;
        this.loadingCtrl = loadingCtrl;
        this.keyboard = keyboard;
        this.login = {
          phone: "",
          password: ""
        };
        this.isKeyboardHide = true;
        this.showPass = false;
        window.addEventListener('keyboardDidShow', function () {
          console.log("Keyboard is Shown");
          _this.isKeyboardHide = false;

          _this.keyboard.onKeyboardShow().subscribe(function (value) {
            document.body.classList.add('hide-on-keyboard-open');
          });
        });
        window.addEventListener('keyboardDidHide', function () {
          _this.isKeyboardHide = true;

          _this.keyboard.onKeyboardHide().subscribe(function (value) {
            document.body.classList.remove('hide-on-keyboard-open');
          });
        });
      }

      _createClass(HomePage, [{
        key: "fnLogin",
        value: function fnLogin() {
          var _this2 = this;

          if (this.login.phone != '') {
            if (this.login.password != '') {
              this.requestObject = {
                "phone": this.login.phone,
                "password": this.login.password,
                "device_token": localStorage.getItem("device_token")
              };
              this.showLoader();
              this.auth.login(this.requestObject).subscribe(function (data) {
                _this2.dataResponse = data;

                _this2.hideLoader();

                if (_this2.dataResponse.status == true) {
                  localStorage.setItem("id", _this2.dataResponse.data.id);
                  localStorage.setItem("email", _this2.dataResponse.data.email);
                  localStorage.setItem("firm_name", _this2.dataResponse.data.firm_name);
                  localStorage.setItem("name", _this2.dataResponse.data.name);
                  localStorage.setItem("role", _this2.dataResponse.data.role);
                  localStorage.setItem("phone", _this2.dataResponse.data.phone);
                  localStorage.setItem("address_id", _this2.dataResponse.data.address_id);
                  localStorage.setItem("area_master_id", _this2.dataResponse.data.area_master_id);

                  if (_this2.dataResponse.data.photo) {
                    localStorage.setItem("photos", _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].file_url + "assets/uploads/users/" + _this2.dataResponse.data.photo);
                  } else {
                    localStorage.setItem("photos", '');
                  }

                  if (_this2.dataResponse.data.role == 'DeliveryBoy') {
                    _this2.rootPage = '/my-account';

                    _this2.navCtrl.navigateRoot('my-account');
                  } else if (_this2.dataResponse.data.role == 'Salesman') {
                    _this2.rootPage = '/sales-dashboard';

                    _this2.navCtrl.navigateRoot('sales-dashboard');
                  } else {
                    _this2.navCtrl.navigateRoot('dashboard');

                    _this2.rootPage = '/dashboard';
                  } // window.location.reload();


                  _this2.globalFooService.publishSomeData({
                    rootPage: _this2.rootPage,
                    name: _this2.dataResponse.data.name,
                    role: _this2.dataResponse.data.role,
                    email: _this2.dataResponse.data.email,
                    photo: _this2.dataResponse.data.photo ? _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].file_url + "assets/uploads/users/" + _this2.dataResponse.data.photo : ''
                  });
                } else {
                  _this2.hideLoader();

                  _this2.auth.showToastLong(_this2.dataResponse.message);
                }
              }, function (err) {
                console.log("Error=>", err);

                _this2.hideLoader();
              });
            } else {
              this.auth.showToast('Please enter password!');
            }
          } else {
            this.auth.showToast('Enter Phone Number!');
          }
        }
      }, {
        key: "fnSignUp",
        value: function fnSignUp() {
          this.navCtrl.navigateForward('/register');
        }
      }, {
        key: "fnForgotPassword",
        value: function fnForgotPassword() {
          this.navCtrl.navigateForward('/forgot-password');
        }
      }, {
        key: "showLoader",
        value: function showLoader() {
          this.loadingCtrl.create({
            message: 'Please wait...'
          }).then(function (res) {
            res.present();
          });
        }
      }, {
        key: "fnShowPass",
        value: function fnShowPass() {
          this.showPass = !this.showPass;
        }
      }, {
        key: "hideLoader",
        value: function hideLoader() {
          this.loadingCtrl.dismiss().then(function (res) {
            console.log('Loading dismissed!', res);
          })["catch"](function (error) {
            console.log('error', error);
          });
        }
      }]);

      return HomePage;
    }();

    HomePage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _global_foo_service_service__WEBPACK_IMPORTED_MODULE_6__["GlobalFooServiceService"]
      }, {
        type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]
      }, {
        type: _ionic_native_keyboard_ngx__WEBPACK_IMPORTED_MODULE_4__["Keyboard"]
      }];
    };

    HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-home',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./home.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./home.page.scss */
      "./src/app/home/home.page.scss"))["default"]]
    })], HomePage);
    /***/
  }
}]);
//# sourceMappingURL=home-home-module-es5.js.map