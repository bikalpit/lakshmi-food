(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["register-register-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar> \n    <ion-buttons slot=\"start\">\n      <!-- <ion-back-button (click)=\"goBack()\" color=\"danger\"></ion-back-button> -->\n      <ion-icon name=\"arrow-back-outline\" class=\"backarrow1\" (click)=\"goBack()\"></ion-icon>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-button> \n\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"main-title\">Register now</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content class=\"ion-padding\">\n\n  <ion-col class=\"center-left\">\n    <div class=\"text-center\">\n      <img src=\"../../assets/imgs/logo.png\" width=\"80\" height=\"80\">\n    </div>\n  </ion-col>\n  <ion-list class=\"form\" id=\"register_form\">\n\n    <div class=\"input-wrap\">\n      <ion-item style=\"align-items: flex-end;\">  \n        <ion-icon name=\"document-text\" color=\"primary\" slot=\"start\"></ion-icon>\n        <ion-label position=\"floating\">GST No. (Optional)</ion-label>\n        <ion-input type=\"text\" name=\"fullname\" [(ngModel)]=\"gstText\" (ionChange)=\"GSTFetch()\"></ion-input>\n      </ion-item>\n    </div>\n    <form [formGroup]=\"ionicForm\">\n      <div class=\"input-wrap\">\n        <ion-item style=\"align-items: flex-end;\">  \n          <ion-icon name=\"person\" color=\"primary\" slot=\"start\"></ion-icon>\n          <ion-label position=\"floating\">Full Name</ion-label>\n          <ion-input type=\"text\" name=\"fullname\" formControlName=\"fullname\" [(ngModel)]=\"register.fullname\"></ion-input>\n        </ion-item>\n        <span class=\"error-wrap\"\n          *ngIf=\"ionicForm.get('fullname').touched || ionicForm.get('fullname').dirty || formSubmitclicked\">\n          <small *ngIf=\"ionicForm.get('fullname').hasError('required')\" class=\"error\">Full Name is required.</small>\n          <small *ngIf=\"ionicForm.get('fullname').hasError('minlength')\" class=\"error\">Full Name should be of minimum 3\n            Character.</small>\n          <small *ngIf=\"ionicForm.get('fullname').hasError('pattern')\" class=\"error\">Only character allowed.</small>\n        </span>\n      </div>\n\n      <div class=\"input-wrap\">\n        <ion-item style=\"align-items: flex-end;\">  \n          <ion-icon name=\"home\" color=\"primary\" slot=\"start\"></ion-icon>\n          <ion-label position=\"floating\">Firm Name</ion-label>\n          <ion-input type=\"text\" name=\"username\" formControlName=\"username\" [(ngModel)]=\"register.username\"></ion-input>\n        </ion-item>\n        <span class=\"error-wrap\"\n          *ngIf=\"ionicForm.get('username').touched || ionicForm.get('username').dirty || formSubmitclicked\">\n          <small *ngIf=\"ionicForm.get('username').hasError('required')\" class=\"error\">Firm is required.</small>\n          <small *ngIf=\"ionicForm.get('username').hasError('minlength')\" class=\"error\">Firm Name should be of minimum 3\n            Character.</small>\n          <small *ngIf=\"ionicForm.get('username').hasError('pattern')\" class=\"error\">Only character allowed.</small>\n        </span>\n      </div>\n\n      <div class=\"input-wrap\">\n        <ion-item style=\"align-items: flex-end;\">  \n          <ion-icon name=\"mail\" color=\"primary\" slot=\"start\"></ion-icon>\n          <ion-label position=\"floating\">Email</ion-label>\n          <ion-input type=\"email\" name=\"email\" formControlName=\"email\" [(ngModel)]=\"register.email\"></ion-input>\n        </ion-item>\n        <span class=\"error-wrap\"\n          *ngIf=\"ionicForm.get('email').touched || ionicForm.get('email').dirty || formSubmitclicked\">\n          <small *ngIf=\"ionicForm.get('email').hasError('required')\" class=\"error\">Email is required.</small>\n          <small *ngIf=\"ionicForm.get('email').hasError('pattern')\" class=\"error\">Enter valid email.</small>\n        </span>\n      </div>\n      <div class=\"input-wrap\">\n        <ion-item style=\"align-items: flex-end;\">  \n          <ion-icon name=\"call\" color=\"primary\" slot=\"start\"></ion-icon>\n          <ion-label position=\"floating\">Phone Number</ion-label>\n          <ion-input type=\"tel\" maxlength=\"10\" name=\"phone\" formControlName=\"phone\" [(ngModel)]=\"register.phone\">\n          </ion-input>\n        </ion-item>\n        <span class=\"error-wrap\"\n          *ngIf=\"ionicForm.get('phone').touched || ionicForm.get('phone').dirty || formSubmitclicked\">\n          <small *ngIf=\"ionicForm.get('phone').hasError('required')\" class=\"error\">Contact details required.</small>\n          <small *ngIf=\"ionicForm.get('phone').hasError('minlength') || ionicForm.get('phone').hasError('maxlength')\"\n            class=\"error\">Contact details should be 10\n            digits.</small>\n\n        </span>\n      </div>\n      <div class=\"input-wrap\">\n        <ion-item style=\"align-items: flex-end;\">  \n          <ion-icon name=\"lock-closed\" color=\"primary\" slot=\"start\"></ion-icon>\n          <ion-label position=\"floating\">Password</ion-label>\n          <ion-input type=\"password\" name=\"password\" formControlName=\"password\" [(ngModel)]=\"register.password\">\n          </ion-input>\n        </ion-item>\n        <span class=\"error-wrap\"\n          *ngIf=\"ionicForm.get('password').touched || ionicForm.get('password').dirty || formSubmitclicked\">\n          <small *ngIf=\"ionicForm.get('password').hasError('required')\" class=\"error\">Password is required.</small>\n          <small *ngIf=\"ionicForm.get('password').hasError('minlength')\" class=\"error\">Password should be of minimum 6\n            Character.</small>\n        </span>\n      </div>\n      <div class=\"input-wrap\">\n        <ion-item style=\"align-items: flex-end;\">  \n          <ion-icon name=\"lock-closed\" color=\"primary\" slot=\"start\"></ion-icon>\n          <ion-label position=\"floating\">Confirm Password</ion-label>\n          <ion-input type=\"password\" name=\"confirm_password\" formControlName=\"confirm_password\"\n            [(ngModel)]=\"register.confirm_password\"></ion-input>\n        </ion-item>\n        <span class=\"error-wrap\"\n          *ngIf=\"ionicForm.get('confirm_password').touched || ionicForm.get('confirm_password').dirty || formSubmitclicked\">\n          <small *ngIf=\"ionicForm.get('confirm_password').hasError('required')\" class=\"error\">Confirm Password is\n            required.</small>\n        </span>\n      </div>\n\n      <!-------- Address------>\n\n      <div class=\"input-wrap\">\n        <ion-item style=\"align-items: flex-end;\">  \n          <ion-icon name=\"location\" color=\"primary\" slot=\"start\"></ion-icon>\n          <ion-label position=\"floating\">House No.</ion-label>\n          <ion-input type=\"text\" name=\"houseNo\" formControlName=\"houseNo\" [(ngModel)]=\"register.houseNo\"\n            class=\"houseNo\"></ion-input>\n        </ion-item>\n        <span class=\"error-wrap\"\n          *ngIf=\"ionicForm.get('houseNo').touched || ionicForm.get('houseNo').dirty || formSubmitclicked\">\n          <small *ngIf=\"ionicForm.get('houseNo').hasError('required')\" class=\"error\">House number is\n            required.</small>\n        </span>\n      </div>\n      <div class=\"input-wrap\">\n        <ion-item style=\"align-items: flex-end;\">  \n          <ion-icon name=\"location\" color=\"primary\" slot=\"start\"></ion-icon>\n          <ion-label position=\"floating\">Address</ion-label>\n          <ion-input type=\"text\" name=\"AreaColony\" formControlName=\"AreaColony\" [(ngModel)]=\"register.AreaColony\"\n            class=\"AreaColony\"></ion-input>\n        </ion-item>\n        <span class=\"error-wrap\"\n          *ngIf=\"ionicForm.get('AreaColony').touched || ionicForm.get('AreaColony').dirty || formSubmitclicked\">\n          <small *ngIf=\"ionicForm.get('AreaColony').hasError('required')\" class=\"error\">Adress is\n            required.</small>\n        </span>\n      </div>\n      <div class=\"input-wrap\">\n        <ion-item style=\"align-items: flex-end;\">  \n          <ion-icon name=\"location\" color=\"primary\" slot=\"start\"></ion-icon>\n          <ion-label position=\"floating\">Landmark</ion-label>\n          <ion-input type=\"text\" name=\"Landmark\" formControlName=\"Landmark\" [(ngModel)]=\"register.Landmark\"\n            class=\"Landmark\"></ion-input>\n        </ion-item>\n        <span class=\"error-wrap\"\n          *ngIf=\"ionicForm.get('Landmark').touched || ionicForm.get('Landmark').dirty || formSubmitclicked\">\n          <small *ngIf=\"ionicForm.get('Landmark').hasError('required')\" class=\"error\">Landmark is\n            required.</small>\n        </span>\n      </div>\n      <div class=\"input-wrap\">\n        <ion-item style=\"align-items: flex-end;\">  \n          <ion-icon name=\"location\" color=\"primary\" slot=\"start\"></ion-icon>\n          <ion-label position=\"floating\">City</ion-label>\n          <ion-input type=\"text\" name=\"City\" formControlName=\"City\" [(ngModel)]=\"register.City\" class=\"City\">\n          </ion-input>\n        </ion-item>\n        <span class=\"error-wrap\"\n          *ngIf=\"ionicForm.get('City').touched || ionicForm.get('City').dirty || formSubmitclicked\">\n          <small *ngIf=\"ionicForm.get('City').hasError('required')\" class=\"error\">City is\n            required.</small>\n          <small *ngIf=\"ionicForm.get('City').hasError('pattern')\" class=\"error\">Only character allowed.</small>\n        </span>\n      </div>\n      <div class=\"input-wrap\">\n        <ion-item style=\"align-items: flex-end;\">  \n          <ion-icon name=\"location\" color=\"primary\" slot=\"start\"></ion-icon>\n          <ion-label position=\"floating\">State</ion-label>\n          <ion-input type=\"text\" name=\"State\" formControlName=\"State\" [(ngModel)]=\"register.State\" class=\"State\">\n          </ion-input>\n        </ion-item>\n        <span class=\"error-wrap\"\n          *ngIf=\"ionicForm.get('State').touched || ionicForm.get('State').dirty || formSubmitclicked\">\n          <small *ngIf=\"ionicForm.get('State').hasError('required')\" class=\"error\">State is\n            required.</small>\n          <small *ngIf=\"ionicForm.get('State').hasError('pattern')\" class=\"error\">Only character allowed.</small>\n        </span>\n      </div>\n\n      <div class=\"input-wrap\">\n        <ion-item style=\"align-items: flex-end;\">  \n          <ion-icon name=\"location\" color=\"primary\" slot=\"start\"></ion-icon>\n          <ion-label position=\"floating\">Zipcode</ion-label>\n          <ion-input type=\"text\" name=\"City\" formControlName=\"Zipcode\" [(ngModel)]=\"register.Zipcode\" class=\"Zipcode\">\n          </ion-input>\n        </ion-item>\n        <span class=\"error-wrap\"\n          *ngIf=\"ionicForm.get('Zipcode').touched || ionicForm.get('Zipcode').dirty || formSubmitclicked\">\n          <small *ngIf=\"ionicForm.get('Zipcode').hasError('required')\" class=\"error\">Zipcode is required.</small>\n          <small *ngIf=\"ionicForm.get('Zipcode').hasError('pattern')\" class=\"error\">Enter valid Zipcode.</small>\n          <small\n            *ngIf=\"ionicForm.get('Zipcode').hasError('minlength') || ionicForm.get('Zipcode').hasError('maxlength')\"\n            class=\"error\">Zipcode should be of minimum 6\n            Character.</small>\n        </span>\n      </div>\n\n    </form>\n\n    <!-- <div class=\"input-wrap\">\n      <ion-item>\n        <ion-icon name=\"document-text\" color=\"primary\" slot=\"start\"></ion-icon>\n        <ion-label position=\"floating\">House No. (Optional)</ion-label>\n        <ion-input type=\"text\" name=\"houseNo\" [(ngModel)]=\"register.houseNo\"></ion-input>\n      </ion-item>\n    </div>\n    <div class=\"input-wrap\">\n      <ion-item>\n        <ion-icon name=\"location\" color=\"primary\" slot=\"start\"></ion-icon>\n        <ion-label position=\"floating\">Address. (Optional)</ion-label>\n        <ion-input type=\"text\" name=\"AreaColony\" [(ngModel)]=\"register.AreaColony\" class=\"AreaColony\"></ion-input>\n      </ion-item>\n    </div>\n      <form [formGroup]=\"ionicForm\">\n        <div class=\"input-wrap\">\n          <ion-item >\n            <ion-icon name=\"location\" color=\"primary\" slot=\"start\"></ion-icon>\n            <ion-label position=\"floating\">City</ion-label>\n            <ion-input type=\"text\" name=\"City\" formControlName=\"City\" \n            [(ngModel)]=\"register.City\" class=\"City\"></ion-input>\n          </ion-item>\n          <span class=\"error-wrap\"\n            *ngIf=\"ionicForm.get('City').touched || ionicForm.get('City').dirty || formSubmitclicked\">\n            <small *ngIf=\"ionicForm.get('City').hasError('required')\" class=\"error\">City is\n              required.</small>\n              <small *ngIf=\"ionicForm.get('City').hasError('pattern')\" class=\"error\">Only character allowed.</small>\n          </span>\n        </div>\n      </form> -->\n  </ion-list>\n\n  <ion-button small expand=\"full\" (click)=\"fnLogin()\">Register Now</ion-button>\n</ion-content>");

/***/ }),

/***/ "./src/app/register/register-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/register/register-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: RegisterPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPageRoutingModule", function() { return RegisterPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./register.page */ "./src/app/register/register.page.ts");




const routes = [
    {
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_3__["RegisterPage"]
    }
];
let RegisterPageRoutingModule = class RegisterPageRoutingModule {
};
RegisterPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], RegisterPageRoutingModule);



/***/ }),

/***/ "./src/app/register/register.module.ts":
/*!*********************************************!*\
  !*** ./src/app/register/register.module.ts ***!
  \*********************************************/
/*! exports provided: RegisterPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPageModule", function() { return RegisterPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _register_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./register-routing.module */ "./src/app/register/register-routing.module.ts");
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./register.page */ "./src/app/register/register.page.ts");







let RegisterPageModule = class RegisterPageModule {
};
RegisterPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _register_routing_module__WEBPACK_IMPORTED_MODULE_5__["RegisterPageRoutingModule"]
        ],
        declarations: [_register_page__WEBPACK_IMPORTED_MODULE_6__["RegisterPage"]]
    })
], RegisterPageModule);



/***/ }),

/***/ "./src/app/register/register.page.scss":
/*!*********************************************!*\
  !*** ./src/app/register/register.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".main-title {\n  text-align: center;\n  color: #E4322E;\n  margin-right: 35px;\n}\n\n.text-center {\n  text-align: center;\n  width: -webkit-fill-available;\n}\n\n.center-left {\n  display: flex;\n  align-items: center;\n}\n\n.cam-icon {\n  width: 75px;\n  height: 75px;\n  font-size: 2.6rem;\n  background-color: #f5f5f5;\n  text-align: center;\n  line-height: 75px;\n  color: #ffffff;\n  border-radius: 50%;\n  display: block;\n  margin: auto;\n  margin-bottom: 20px;\n}\n\n.form {\n  margin-bottom: 35px;\n}\n\n.title-center {\n  text-align: center !important;\n  margin-right: 44px;\n}\n\n.input-wrap {\n  position: relative;\n}\n\n.input-wrap .login_text {\n  margin-bottom: 15px;\n}\n\n.input-wrap .error-wrap {\n  bottom: -15px;\n}\n\n.error-wrap {\n  color: #E4322E;\n  font-size: 1rem;\n  margin-left: 4.4rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9yZWdpc3Rlci9yZWdpc3Rlci5wYWdlLnNjc3MiLCJzcmMvYXBwL3JlZ2lzdGVyL3JlZ2lzdGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQTtFQUNFLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FDREY7O0FER0E7RUFDRSxrQkFBQTtFQUNBLDZCQUFBO0FDQUY7O0FERUE7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7QUNDRjs7QURDQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0FDRUY7O0FEQ0E7RUFDRSxtQkFBQTtBQ0VGOztBREFBO0VBQ0UsNkJBQUE7RUFDQSxrQkFBQTtBQ0dGOztBRERBO0VBQ0Usa0JBQUE7QUNJRjs7QURIRTtFQUNFLG1CQUFBO0FDS0o7O0FESEU7RUFDRSxhQUFBO0FDS0o7O0FERkE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0FDS0YiLCJmaWxlIjoic3JjL2FwcC9yZWdpc3Rlci9yZWdpc3Rlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbi8vYnkgQXJzaGRhXG4ubWFpbi10aXRsZXtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI0U0MzIyRTtcbiAgbWFyZ2luLXJpZ2h0OiAzNXB4O1xufVxuLnRleHQtY2VudGVye1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHdpZHRoOiAtd2Via2l0LWZpbGwtYXZhaWxhYmxlO1xufVxuLmNlbnRlci1sZWZ0e1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLmNhbS1pY29uIHtcbiAgd2lkdGg6IDc1cHg7XG4gIGhlaWdodDogNzVweDtcbiAgZm9udC1zaXplOiAyLjZyZW07XG4gIGJhY2tncm91bmQtY29sb3I6ICNmNWY1ZjU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbGluZS1oZWlnaHQ6IDc1cHg7XG4gIGNvbG9yOiAjZmZmZmZmO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW46IGF1dG87XG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XG59XG5cbi5mb3JtIHtcbiAgbWFyZ2luLWJvdHRvbTogMzVweDtcbn1cbi50aXRsZS1jZW50ZXJ7XG4gIHRleHQtYWxpZ246IGNlbnRlciAhaW1wb3J0YW50O1xuICBtYXJnaW4tcmlnaHQ6IDQ0cHg7XG59XG4uaW5wdXQtd3JhcHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAubG9naW5fdGV4dHtcbiAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xuICB9XG4gIC5lcnJvci13cmFwe1xuICAgIGJvdHRvbTogLTE1cHg7XG4gIH1cbn1cbi5lcnJvci13cmFwe1xuICBjb2xvcjojRTQzMjJFO1xuICBmb250LXNpemU6MXJlbTtcbiAgbWFyZ2luLWxlZnQ6IDQuNHJlbTtcbn1cbiIsIi5tYWluLXRpdGxlIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI0U0MzIyRTtcbiAgbWFyZ2luLXJpZ2h0OiAzNXB4O1xufVxuXG4udGV4dC1jZW50ZXIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHdpZHRoOiAtd2Via2l0LWZpbGwtYXZhaWxhYmxlO1xufVxuXG4uY2VudGVyLWxlZnQge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4uY2FtLWljb24ge1xuICB3aWR0aDogNzVweDtcbiAgaGVpZ2h0OiA3NXB4O1xuICBmb250LXNpemU6IDIuNnJlbTtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjVmNTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBsaW5lLWhlaWdodDogNzVweDtcbiAgY29sb3I6ICNmZmZmZmY7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbjogYXV0bztcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcbn1cblxuLmZvcm0ge1xuICBtYXJnaW4tYm90dG9tOiAzNXB4O1xufVxuXG4udGl0bGUtY2VudGVyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1yaWdodDogNDRweDtcbn1cblxuLmlucHV0LXdyYXAge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4uaW5wdXQtd3JhcCAubG9naW5fdGV4dCB7XG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XG59XG4uaW5wdXQtd3JhcCAuZXJyb3Itd3JhcCB7XG4gIGJvdHRvbTogLTE1cHg7XG59XG5cbi5lcnJvci13cmFwIHtcbiAgY29sb3I6ICNFNDMyMkU7XG4gIGZvbnQtc2l6ZTogMXJlbTtcbiAgbWFyZ2luLWxlZnQ6IDQuNHJlbTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/register/register.page.ts":
/*!*******************************************!*\
  !*** ./src/app/register/register.page.ts ***!
  \*******************************************/
/*! exports provided: RegisterPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPage", function() { return RegisterPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth.service.ts");
/* harmony import */ var _ionic_native_keyboard_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/keyboard/ngx */ "./node_modules/@ionic-native/keyboard/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");



//import { ApiService } from '../api.service';




const RES_DATA = {
    taxpayerInfo: {
        ctjCd: 'ZD1102',
        stj: 'Mukatsar - Ward No.5',
        pradr: {
            addr: {
                city: '',
                bno: '1915',
                flno: '',
                loc: 'GIDDERBAHA',
                st: 'STREET NO. 02',
                lg: '',
                dst: 'Muktsar',
                stcd: 'Punjab',
                lt: '',
                bnm: 'SHAHEED BHAGAT SINGH NAGAR',
                pncd: '152101',
            },
            ntr: 'Export',
        },
        dty: 'Regular',
        frequencyType: null,
        errorMsg: null,
        tradeNam: 'BROADVIEW INNOVATIONS PRIVATE LIMITED',
        rgdt: '02/11/2018',
        adadr: [],
        nba: ['Export'],
        cxdt: '',
        ctj: 'GIDDERBAHA',
        sts: 'Active',
        stjCd: 'PB165',
        ctb: 'Private Limited Company',
        gstin: '03AAFCB3420K1Z3',
        lgnm: 'BROADVIEW INNOVATIONS PRIAVATE LIMITED',
        panNo: 'AAFCB3420K',
    },
    filing: [],
    compliance: {
        filingFrequency: null,
    },
};
let RegisterPage = class RegisterPage {
    constructor(navCtrl, auth, keyboard, formbulider, toast, location) {
        this.navCtrl = navCtrl;
        this.auth = auth;
        this.keyboard = keyboard;
        this.formbulider = formbulider;
        this.toast = toast;
        this.location = location;
        this.register = { fullname: "", username: "", email: "", phone: "", password: "", confirm_password: "", houseNo: "", AreaColony: "", State: "", City: "", Landmark: "", Zipcode: "" };
        this.onlynumeric = /^-?(0|[1-9]\d*)?$/;
        this.isSubmitted = false;
        this.isKeyboardHide = true;
        this.emailFormat = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;
        window.addEventListener('keyboardDidShow', () => {
            console.log("Keyboard is Shown");
            this.isKeyboardHide = false;
            // document.body.classList.add('hide-on-keyboard-open');
            this.keyboard.onKeyboardShow().subscribe((value) => {
                document.body.classList.add('hide-on-keyboard-open');
            });
        });
        window.addEventListener('keyboardDidHide', () => {
            // document.body.classList.remove('hide-on-keyboard-open');
            this.isKeyboardHide = true;
            this.keyboard.onKeyboardHide().subscribe((value) => {
                document.body.classList.remove('hide-on-keyboard-open');
            });
        });
        this.ionicForm = this.formbulider.group({
            username: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].pattern('[a-zA-Z ]*')]],
            fullname: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].pattern('[a-zA-Z ]*')]],
            email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$')]],
            password: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].minLength(6)]],
            confirm_password: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].minLength(6)]],
            phone: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].minLength(10), _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].maxLength(10)]],
            houseNo: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]],
            AreaColony: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]],
            State: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].pattern('[a-zA-Z ]*')]],
            City: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].pattern('[a-zA-Z ]*')]],
            Landmark: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]],
            Zipcode: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].minLength(6), _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].maxLength(6), _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].pattern(this.onlynumeric)]]
        });
    }
    ngOnInit() { }
    fnLogin() {
        if (this.ionicForm.invalid) {
            console.log('invalid');
            this.ionicForm.get('fullname').markAllAsTouched();
            this.ionicForm.get('email').markAsTouched();
            this.ionicForm.get('phone').markAsTouched();
            this.ionicForm.get('username').markAsTouched();
            this.ionicForm.get('password').markAsTouched();
            this.ionicForm.get('confirm_password').markAsTouched();
            this.ionicForm.get('houseNo').markAsTouched();
            this.ionicForm.get('AreaColony').markAsTouched();
            this.ionicForm.get('Landmark').markAsTouched();
            this.ionicForm.get('City').markAsTouched();
            this.ionicForm.get('State').markAsTouched();
            this.ionicForm.get('Zipcode').markAsTouched();
            return false;
        }
        console.log('ok');
        this.requestObject = {
            "fullname": this.register.fullname,
            "firm_name": this.register.username,
            "email": this.register.email,
            "phone": this.register.phone,
            "password": this.register.password,
            "address": this.register.houseNo,
            "area": this.register.AreaColony,
            "landmark": this.register.Landmark,
            "city": this.register.City,
            "state": this.register.State,
            "zipcode": this.register.Zipcode,
            "role": "Customer"
        };
        console.log(this.requestObject);
        if (this.register.password === this.register.confirm_password) {
            console.log('ok');
            this.auth.showLoader();
            this.auth.signup(this.requestObject).subscribe((data) => {
                this.auth.hideLoader();
                console.log(data);
                this.dataResponse = data;
                if (this.dataResponse.status == true) {
                    this.auth.showToast('Registration Successfully');
                    this.navCtrl.navigateForward('/home');
                }
                else {
                    this.auth.showToast(this.dataResponse.message);
                }
            }, (err) => {
                this.auth.hideLoader();
                console.log("Error=>", err);
            });
        }
        else {
            this.auth.showToast('Enter confirm password same as password!');
        }
    }
    showToast() {
        this.myToast = this.toast.create({
            message: 'Please fillup all fields',
            duration: 2000
        }).then((toastData) => {
            console.log(toastData);
            toastData.present();
        });
    }
    fnSignIn() {
        this.navCtrl.navigateRoot('home');
    }
    GSTFetch() {
        // let dd = this.ionicForm.get('GSTNo').value
        let dd = this.gstText;
        if (this.fetchGst)
            clearTimeout(this.fetchGst);
        this.fetchGst = setTimeout(() => {
            console.log(dd);
            this.fnGetGST(dd);
            /*  this.register.houseNo=RES_DATA.taxpayerInfo.pradr.addr.bnm;
             this.register.AreaColony=RES_DATA.taxpayerInfo.pradr.addr.flno;
             this.register.City=RES_DATA.taxpayerInfo.pradr.addr.dst;
             this.register.fullname=RES_DATA.taxpayerInfo.lgnm;
             this.register.username=RES_DATA.taxpayerInfo.tradeNam;
        */
        }, 1000);
    }
    fnGetGST(gst) {
        if (gst.length < 14) {
            return false;
        }
        this.auth.showLoader();
        this.auth.getAddressFromGst(gst).subscribe((data) => {
            this.auth.hideLoader();
            if (data.error === true) {
                this.auth.showToast(data.message);
            }
            else {
                /*  this.ionicForm.setValue({
                   GSTNo: gst,
                   houseNo: data.taxpayerInfo.pradr.addr.bnm,
                   AreaColony: data.taxpayerInfo.pradr.addr.flno,
                   Landmark: data.taxpayerInfo.pradr.addr.st,
                   Zipcode: data.taxpayerInfo.pradr.addr.pncd,
                   City: data.taxpayerInfo.pradr.addr.dst,
                   State: data.taxpayerInfo.pradr.addr.stcd,
                   phone: '',
                 }); */
                this.register.fullname = data.taxpayerInfo.lgnm;
                this.register.username = data.taxpayerInfo.tradeNam;
                this.register.houseNo = data.taxpayerInfo.pradr.addr.bnm;
                this.register.AreaColony = data.taxpayerInfo.pradr.addr.flno;
                this.register.City = data.taxpayerInfo.pradr.addr.dst;
                this.register.Landmark = data.taxpayerInfo.pradr.addr.st;
                this.register.Zipcode = data.taxpayerInfo.pradr.addr.pncd;
                this.register.State = data.taxpayerInfo.pradr.addr.stcd;
            }
        }, (err) => {
            this.auth.hideLoader();
            console.log("Error=>", err);
        });
    }
    goBack() {
        this.location.back();
    }
};
RegisterPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] },
    { type: _ionic_native_keyboard_ngx__WEBPACK_IMPORTED_MODULE_5__["Keyboard"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_6__["Location"] }
];
RegisterPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-register',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./register.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./register.page.scss */ "./src/app/register/register.page.scss")).default]
    })
], RegisterPage);



/***/ })

}]);
//# sourceMappingURL=register-register-module-es2015.js.map