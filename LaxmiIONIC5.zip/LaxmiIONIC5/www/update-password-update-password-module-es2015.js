(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["update-password-update-password-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/update-password/update-password.page.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/update-password/update-password.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <!-- <ion-back-button (click)=\"goBack()\" color=\"danger\"></ion-back-button> -->\n      <ion-icon name=\"arrow-back-outline\" class=\"backarrow1\" (click)=\" goBack()\"></ion-icon>\n    </ion-buttons>\n    <ion-title class=\"main-title\">Change Password</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"main-content\">\n    <h4 class=\"password-txt\"><b>Change Password</b></h4>\n  </div>\n  <div class=\"main-content\">\n    <form [formGroup]=\"ionicForm\" novalidate>\n    <div class=\"order-no-bg\">\n      <ion-input placeholder=\"New Password\" formControlName=\"newPass\" [(ngModel)]=\"newPass\" type=\"password\" class=\"order_no_txt\"></ion-input>\n      <span class=\"error-wrap\" *ngIf=\"ionicForm.get('newPass').touched || ionicForm.get('newPass').dirty\">\n        <small *ngIf=\"ionicForm.get('newPass').hasError('required')\" class=\"error\">Password is required.</small>\n        <small *ngIf=\"ionicForm.get('newPass').hasError('minlength')\" class=\"error\">Password should be minimum 6 digits.</small>    \n      </span>\n    </div>\n\n    <div class=\"order-no-bg\">\n      <ion-input placeholder=\"Confirm Password\" formControlName=\"confirmPass\" [(ngModel)]=\"confirmPass\" type=\"password\" class=\"order_no_txt\"></ion-input>\n      <span class=\"error-wrap\" *ngIf=\"ionicForm.get('confirmPass').touched || ionicForm.get('confirmPass').dirty\">\n        <small *ngIf=\"ionicForm.get('confirmPass').hasError('required')\" class=\"error\">Password is required.</small>\n        <small *ngIf=\"ionicForm.get('confirmPass').hasError('minlength')\" class=\"error\">Password should be minimum 6 digits.</small>    \n      </span>\n    </div>\n    </form>\n  </div>\n\n  <button ion-button class=\"ChangePassword_btn\" (click)=\"fnSubmit()\">Submit</button>\n</ion-content>");

/***/ }),

/***/ "./src/app/update-password/update-password-routing.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/update-password/update-password-routing.module.ts ***!
  \*******************************************************************/
/*! exports provided: UpdatePasswordPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdatePasswordPageRoutingModule", function() { return UpdatePasswordPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _update_password_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./update-password.page */ "./src/app/update-password/update-password.page.ts");




const routes = [
    {
        path: '',
        component: _update_password_page__WEBPACK_IMPORTED_MODULE_3__["UpdatePasswordPage"]
    }
];
let UpdatePasswordPageRoutingModule = class UpdatePasswordPageRoutingModule {
};
UpdatePasswordPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], UpdatePasswordPageRoutingModule);



/***/ }),

/***/ "./src/app/update-password/update-password.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/update-password/update-password.module.ts ***!
  \***********************************************************/
/*! exports provided: UpdatePasswordPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdatePasswordPageModule", function() { return UpdatePasswordPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _update_password_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./update-password-routing.module */ "./src/app/update-password/update-password-routing.module.ts");
/* harmony import */ var _update_password_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./update-password.page */ "./src/app/update-password/update-password.page.ts");







let UpdatePasswordPageModule = class UpdatePasswordPageModule {
};
UpdatePasswordPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _update_password_routing_module__WEBPACK_IMPORTED_MODULE_5__["UpdatePasswordPageRoutingModule"]
        ],
        declarations: [_update_password_page__WEBPACK_IMPORTED_MODULE_6__["UpdatePasswordPage"]]
    })
], UpdatePasswordPageModule);



/***/ }),

/***/ "./src/app/update-password/update-password.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/update-password/update-password.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".menu_btn {\n  color: #E4322E;\n}\n\n.main-title {\n  text-align: center;\n  color: #E4322E;\n  margin-right: 42px;\n}\n\n.error-wrap {\n  color: #E4322E;\n}\n\n.order-no-bg {\n  background-color: #f5f0f0;\n  width: 90%;\n  height: 45px;\n  margin-left: 20px;\n  border-radius: 7px;\n  margin-top: 15px;\n}\n\n.order_no_txt {\n  text-align: start;\n  color: #010944;\n  margin-left: 10px;\n}\n\n.password-txt {\n  color: #E4322E;\n  margin: 25px;\n}\n\n.ChangePassword_btn {\n  background-color: #E4322E;\n  color: #fff;\n  font-size: 20px;\n  height: 45px;\n  width: 90%;\n  border-radius: 10px;\n  display: block;\n  margin: auto;\n  border: 1px solid #fff;\n  margin-left: 19px;\n  margin-top: 25%;\n}\n\n.main-content {\n  margin-top: 18%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC91cGRhdGUtcGFzc3dvcmQvdXBkYXRlLXBhc3N3b3JkLnBhZ2Uuc2NzcyIsInNyYy9hcHAvdXBkYXRlLXBhc3N3b3JkL3VwZGF0ZS1wYXNzd29yZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0FDQ0o7O0FEQ0M7RUFDRSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQ0VIOztBREFBO0VBQ0csY0FBQTtBQ0dIOztBRERFO0VBQ0cseUJBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQ0lMOztBREZDO0VBQ0csaUJBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUNLSjs7QURIQztFQUNJLGNBQUE7RUFDQSxZQUFBO0FDTUw7O0FESkU7RUFDRyx5QkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUNPTDs7QURMRTtFQUNHLGVBQUE7QUNRTCIsImZpbGUiOiJzcmMvYXBwL3VwZGF0ZS1wYXNzd29yZC91cGRhdGUtcGFzc3dvcmQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1lbnVfYnRue1xuICAgIGNvbG9yOiAjRTQzMjJFO1xuIH1cbiAubWFpbi10aXRsZXtcbiAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgIGNvbG9yOiAjRTQzMjJFO1xuICAgbWFyZ2luLXJpZ2h0OiA0MnB4O1xufVxuLmVycm9yLXdyYXB7XG4gICBjb2xvcjojRTQzMjJFO1xuIH1cbiAgLm9yZGVyLW5vLWJne1xuICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmMGYwO1xuICAgICB3aWR0aDogOTAlO1xuICAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xuICAgICBib3JkZXItcmFkaXVzOiA3cHg7XG4gICAgIG1hcmdpbi10b3A6IDE1cHg7XG4gfVxuIC5vcmRlcl9ub190eHR7XG4gICAgdGV4dC1hbGlnbjogc3RhcnQ7XG4gICAgY29sb3I6ICMwMTA5NDQ7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gfVxuIC5wYXNzd29yZC10eHR7XG4gICAgIGNvbG9yOiAjRTQzMjJFO1xuICAgICBtYXJnaW46IDI1cHg7XG4gIH1cbiAgLkNoYW5nZVBhc3N3b3JkX2J0bntcbiAgICAgYmFja2dyb3VuZC1jb2xvcjogI0U0MzIyRTtcbiAgICAgY29sb3I6ICNmZmY7XG4gICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICAgaGVpZ2h0OiA0NXB4O1xuICAgICB3aWR0aDogOTAlO1xuICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgbWFyZ2luOiBhdXRvO1xuICAgICBib3JkZXI6IDFweCBzb2xpZCAjZmZmO1xuICAgICBtYXJnaW4tbGVmdDogMTlweDtcbiAgICAgbWFyZ2luLXRvcDogMjUlO1xuICB9XG4gIC5tYWluLWNvbnRlbnR7XG4gICAgIG1hcmdpbi10b3A6MTglO1xuICB9IiwiLm1lbnVfYnRuIHtcbiAgY29sb3I6ICNFNDMyMkU7XG59XG5cbi5tYWluLXRpdGxlIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI0U0MzIyRTtcbiAgbWFyZ2luLXJpZ2h0OiA0MnB4O1xufVxuXG4uZXJyb3Itd3JhcCB7XG4gIGNvbG9yOiAjRTQzMjJFO1xufVxuXG4ub3JkZXItbm8tYmcge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmMGYwO1xuICB3aWR0aDogOTAlO1xuICBoZWlnaHQ6IDQ1cHg7XG4gIG1hcmdpbi1sZWZ0OiAyMHB4O1xuICBib3JkZXItcmFkaXVzOiA3cHg7XG4gIG1hcmdpbi10b3A6IDE1cHg7XG59XG5cbi5vcmRlcl9ub190eHQge1xuICB0ZXh0LWFsaWduOiBzdGFydDtcbiAgY29sb3I6ICMwMTA5NDQ7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuXG4ucGFzc3dvcmQtdHh0IHtcbiAgY29sb3I6ICNFNDMyMkU7XG4gIG1hcmdpbjogMjVweDtcbn1cblxuLkNoYW5nZVBhc3N3b3JkX2J0biB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNFNDMyMkU7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LXNpemU6IDIwcHg7XG4gIGhlaWdodDogNDVweDtcbiAgd2lkdGg6IDkwJTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbjogYXV0bztcbiAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbiAgbWFyZ2luLWxlZnQ6IDE5cHg7XG4gIG1hcmdpbi10b3A6IDI1JTtcbn1cblxuLm1haW4tY29udGVudCB7XG4gIG1hcmdpbi10b3A6IDE4JTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/update-password/update-password.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/update-password/update-password.page.ts ***!
  \*********************************************************/
/*! exports provided: UpdatePasswordPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdatePasswordPage", function() { return UpdatePasswordPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");







let UpdatePasswordPage = class UpdatePasswordPage {
    constructor(formbulider, navCtrl, menu, location, auth, toast) {
        this.formbulider = formbulider;
        this.navCtrl = navCtrl;
        this.menu = menu;
        this.location = location;
        this.auth = auth;
        this.toast = toast;
        this.email = localStorage.getItem('email');
        this.ionicForm = this.formbulider.group({
            newPass: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].minLength(6), _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].maxLength(6)]],
            confirmPass: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].minLength(6), _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].maxLength(6)]]
        });
    }
    ngOnInit() {
    }
    ionViewDidLeave() {
    }
    fnSubmit() {
        if (this.email != undefined && this.newPass != undefined && this.confirmPass != undefined) {
            if (this.email != '' && this.newPass != '' && this.confirmPass != '') {
                if (this.newPass == this.confirmPass) {
                    console.log(this.email);
                    console.log(this.newPass);
                    console.log(this.confirmPass);
                    this.requestObject = {
                        "email": localStorage.getItem('email'),
                        "password": this.confirmPass
                    };
                    this.auth.showLoader();
                    console.log(this.requestObject);
                    this.auth.updatePassword(this.requestObject).subscribe((data) => {
                        this.auth.hideLoader();
                        console.log(data);
                        this.dataResponse = data;
                        if (this.dataResponse.status == true) {
                            this.auth.showToast("Password Updated");
                            setTimeout(() => {
                                this.navCtrl.navigateRoot('/home');
                            }, 3000);
                            /*  const observableVar = new Observable(subscriber => {
                               setTimeout(() => {
                                 subscriber.complete();
                                
                               }, 3000);
                             }); */
                        }
                        else {
                            this.showToast1();
                        }
                    }, (err) => {
                        this.auth.hideLoader();
                        console.log("Error=>", err);
                        //this.auth.showError(err.error.message);
                    });
                }
                else {
                    this.auth.showToast("Password does not match! ");
                }
            }
            else {
                this.showToast();
            }
        }
        else {
            this.showToast();
        }
    }
    goBack() {
        this.location.back();
    }
    showToast() {
        this.myToast = this.toast.create({
            message: 'Please Enter New Password & Confirm Password',
            duration: 2000
        }).then((toastData) => {
            console.log(toastData);
            toastData.present();
        });
    }
    showToast1() {
        this.myToast = this.toast.create({
            message: 'Something went wrong.Please try again later',
            duration: 2000
        }).then((toastData) => {
            console.log(toastData);
            toastData.present();
        });
    }
};
UpdatePasswordPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["Location"] },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
];
UpdatePasswordPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-update-password',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./update-password.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/update-password/update-password.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./update-password.page.scss */ "./src/app/update-password/update-password.page.scss")).default]
    })
], UpdatePasswordPage);



/***/ })

}]);
//# sourceMappingURL=update-password-update-password-module-es2015.js.map