function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["customer-orders-customer-orders-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/customer-orders/customer-orders.page.html":
  /*!*************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/customer-orders/customer-orders.page.html ***!
    \*************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCustomerOrdersCustomerOrdersPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\" >\n      <ion-icon name=\"arrow-back-outline\" class=\"backarrow1\" (click)=\" fnBackToYourCart()\"></ion-icon>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-button>\n\n      </ion-button>\n    </ion-buttons> \n    <ion-title class=\"main-title\">My Orders</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n  <ion-row style=\"margin-top: 12px;\">\n    <p class=\"order-status\"><b>Order Status</b></p>\n    <ion-col>\n      <ion-item lines=\"none\" style=\"float: right;\">   \n        <ion-select  #item class=\"custom-options customer-filter\" [(ngModel)]=\"selecTextStatus.select\" (ionChange)=\"OnChange(item.value)\">\n          <ion-select-option value=\"InProcess\">Inprocess</ion-select-option>\n          <ion-select-option value=\"Delivered\">Delivered</ion-select-option> \n          <ion-select-option value=\"cancel\">Cancel</ion-select-option> \n          <ion-select-option value=\"Reject\">Rejected</ion-select-option> \n        </ion-select>\n      </ion-item>\n    </ion-col> \n  </ion-row>\n  \n <div>\n  <ion-card *ngFor=\"let item of ordersList;\"  (click)=\"fnOrderSummary(item.id,item.order_number)\">\n    <ion-grid class=\"main-content\">\n      <p class=\"order-ids\">Order ID: #{{item.order_number}}</p>\n    </ion-grid>\n    <ion-row>\n      <ion-col>\n        <p class=\"d-date\">Order Date</p>\n        <p class=\"date\"><b>{{item.create_at}}</b></p>\n      </ion-col>\n\n      <ion-col>\n        <p class=\"status\" *ngIf=\"item.status == 'Approve' \"><b>Approved</b></p>\n        <p class=\"status\" *ngIf=\"item.status == 'Assigned' \"><b>Assigned</b></p>\n        <p class=\"status\" *ngIf=\"item.status == 'Pickup' \"><b>On the way</b></p>\n        <p class=\"status\" *ngIf=\"item.status == 'New' \"><b>Pending</b></p>\n        <p class=\"status\" *ngIf=\"item.status == 'Delivered' \"><b>Delivered</b></p>\n        <p class=\"status\" *ngIf=\"item.status == 'cancel' \"><b>Cancel</b></p>\n        <p class=\"status\" *ngIf=\"item.status == 'Reject' \"><b>Rejected</b></p>\n\n      </ion-col>\n    </ion-row>\n  </ion-card>\n</div>\n<div *ngIf=\"!ordersList?.length > 0\">\n  <p class=\"norecord-label\">No Records Found</p>\n</div>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/customer-orders/customer-orders-routing.module.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/customer-orders/customer-orders-routing.module.ts ***!
    \*******************************************************************/

  /*! exports provided: CustomerOrdersPageRoutingModule */

  /***/
  function srcAppCustomerOrdersCustomerOrdersRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CustomerOrdersPageRoutingModule", function () {
      return CustomerOrdersPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _customer_orders_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./customer-orders.page */
    "./src/app/customer-orders/customer-orders.page.ts");

    var routes = [{
      path: '',
      component: _customer_orders_page__WEBPACK_IMPORTED_MODULE_3__["CustomerOrdersPage"]
    }];

    var CustomerOrdersPageRoutingModule = function CustomerOrdersPageRoutingModule() {
      _classCallCheck(this, CustomerOrdersPageRoutingModule);
    };

    CustomerOrdersPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], CustomerOrdersPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/customer-orders/customer-orders.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/customer-orders/customer-orders.module.ts ***!
    \***********************************************************/

  /*! exports provided: CustomerOrdersPageModule */

  /***/
  function srcAppCustomerOrdersCustomerOrdersModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CustomerOrdersPageModule", function () {
      return CustomerOrdersPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _customer_orders_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./customer-orders-routing.module */
    "./src/app/customer-orders/customer-orders-routing.module.ts");
    /* harmony import */


    var _customer_orders_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./customer-orders.page */
    "./src/app/customer-orders/customer-orders.page.ts");

    var CustomerOrdersPageModule = function CustomerOrdersPageModule() {
      _classCallCheck(this, CustomerOrdersPageModule);
    };

    CustomerOrdersPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _customer_orders_routing_module__WEBPACK_IMPORTED_MODULE_5__["CustomerOrdersPageRoutingModule"]],
      declarations: [_customer_orders_page__WEBPACK_IMPORTED_MODULE_6__["CustomerOrdersPage"]]
    })], CustomerOrdersPageModule);
    /***/
  },

  /***/
  "./src/app/customer-orders/customer-orders.page.scss":
  /*!***********************************************************!*\
    !*** ./src/app/customer-orders/customer-orders.page.scss ***!
    \***********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCustomerOrdersCustomerOrdersPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".menu_btn {\n  color: #E4322E;\n}\n\n.main-title {\n  text-align: center;\n  color: #E4322E;\n  font-family: open sans;\n}\n\n.order-status {\n  color: black;\n  font-size: 18px;\n  margin-left: 10px;\n  margin-bottom: 5px;\n  font-family: open sans;\n}\n\n.main-card {\n  box-shadow: 5px 7px 10px 5px #e8e8e8;\n  background-color: #fff;\n}\n\n.date {\n  font-family: open sans;\n  color: black;\n  font-size: 16px;\n  margin-left: 10px;\n  margin-top: 0px;\n}\n\n.d-date {\n  font-family: open sans;\n  color: #000;\n  font-size: 18px;\n  margin-left: 10px;\n  margin-bottom: 5px;\n}\n\n.status {\n  font-family: open sans;\n  color: #E4322E;\n  font-size: 18px;\n  margin-left: 10px;\n  margin-bottom: 5px;\n}\n\n.main-content {\n  background-color: #E4322E;\n}\n\n.main-content .order-ids {\n  font-family: open sans;\n  color: #fff;\n  font-size: 20px;\n  margin: 0;\n  padding: 3px;\n}\n\n.select-text {\n  font-family: open sans;\n  min-width: 16px;\n  font-size: inherit;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  flex: 1 1 0%;\n  overflow: hidden;\n}\n\n.select-icon {\n  width: 19px;\n  height: 19px;\n  margin-left: 18px;\n}\n\n.select-icon {\n  position: relative;\n  opacity: 0.33;\n}\n\nion-select {\n  max-width: 117px;\n  border: 1px solid #E4322E;\n  border-radius: 9px;\n  padding: 9px;\n}\n\n.norecord-label {\n  font-family: open sans;\n  color: #E4322E;\n  font-size: 18px;\n  text-align: center;\n}\n\n.custom-options {\n  font-family: open sans;\n}\n\n.customer-filter {\n  width: 170px;\n  max-width: 160px;\n  height: 40px;\n  padding: 0;\n}\n\n.customer-filter::part(text) {\n  padding: 0 10px;\n  font-size: 17px;\n  font-family: open sans;\n}\n\n.customer-filter::part(icon) {\n  width: 45px !important;\n  height: 45px !important;\n  background-color: #E4322E !important;\n  display: flex !important;\n  justify-content: center !important;\n  opacity: 1;\n  align-items: center;\n}\n\n.customer-filter::part(icon) * {\n  display: none;\n}\n\n.customer-filter::part(icon)::after {\n  content: \"\";\n  background-image: url(\"/../../assets/imgs/down-arrow.png\");\n  width: 35px;\n  height: 18px;\n  background-position: center;\n  background-color: #e4322e;\n  z-index: 1;\n  background-size: 70%;\n  background-repeat: no-repeat;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9jdXN0b21lci1vcmRlcnMvY3VzdG9tZXItb3JkZXJzLnBhZ2Uuc2NzcyIsInNyYy9hcHAvY3VzdG9tZXItb3JkZXJzL2N1c3RvbWVyLW9yZGVycy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0FDQ0o7O0FEQ0E7RUFDSSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxzQkFBQTtBQ0VKOztBREFBO0VBQ0ksWUFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7QUNHSjs7QUREQTtFQUNJLG9DQUFBO0VBQ0Esc0JBQUE7QUNJSjs7QURGQTtFQUNJLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUNLSjs7QURIQTtFQUNJLHNCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FDTUo7O0FESkE7RUFDSSxzQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQ09KOztBRExBO0VBQ0kseUJBQUE7QUNRSjs7QURQSTtFQUNJLHNCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxTQUFBO0VBQ0EsWUFBQTtBQ1NSOztBRE5BO0VBQ0ksc0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FDU0o7O0FEUEE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FDVUo7O0FEUkE7RUFDSSxrQkFBQTtFQUNBLGFBQUE7QUNXSjs7QURUQTtFQUNJLGdCQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7QUNZSjs7QURWQTtFQUNJLHNCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQ2FKOztBRFhBO0VBQ0ksc0JBQUE7QUNjSjs7QURYQTtFQUNJLFlBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0FDY0o7O0FEWkE7RUFDSSxlQUFBO0VBQ0EsZUFBQTtFQUNBLHNCQUFBO0FDZUo7O0FEYkE7RUFDUSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0Esb0NBQUE7RUFDQSx3QkFBQTtFQUNBLGtDQUFBO0VBQ0EsVUFBQTtFQUNBLG1CQUFBO0FDZ0JSOztBRGZRO0VBQ0ksYUFBQTtBQ2lCWjs7QURmSTtFQUNJLFdBQUE7RUFDQSwwREFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsMkJBQUE7RUFDQSx5QkFBQTtFQUNBLFVBQUE7RUFDQSxvQkFBQTtFQUNBLDRCQUFBO0FDaUJSIiwiZmlsZSI6InNyYy9hcHAvY3VzdG9tZXItb3JkZXJzL2N1c3RvbWVyLW9yZGVycy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWVudV9idG57XG4gICAgY29sb3I6ICNFNDMyMkU7XG4gfVxuLm1haW4tdGl0bGV7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjRTQzMjJFO1xuICAgIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG59XG4ub3JkZXItc3RhdHVze1xuICAgIGNvbG9yOiBibGFjaztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogNXB4OyBcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuLm1haW4tY2FyZHtcbiAgICBib3gtc2hhZG93OiA1cHggN3B4IDEwcHggNXB4ICNlOGU4ZTg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjsgIFxufVxuLmRhdGV7XG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgICBjb2xvcjogYmxhY2s7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgIG1hcmdpbi10b3A6IDBweDtcbn1cbi5kLWRhdGV7XG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgICBjb2xvcjogIzAwMDtcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogNXB4O1xufVxuLnN0YXR1c3tcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICAgIGNvbG9yOiAjRTQzMjJFO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICBtYXJnaW4tYm90dG9tOiA1cHg7XG59XG4ubWFpbi1jb250ZW50e1xuICAgIGJhY2tncm91bmQtY29sb3I6I0U0MzIyRSA7XG4gICAgLm9yZGVyLWlkc3tcbiAgICAgICAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgICAgIGZvbnQtc2l6ZToyMHB4IDtcbiAgICAgICAgbWFyZ2luOiAwO1xuICAgICAgICBwYWRkaW5nOiAzcHg7XG4gICAgfVxufVxuLnNlbGVjdC10ZXh0IHtcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICAgIG1pbi13aWR0aDogMTZweDtcbiAgICBmb250LXNpemU6IGluaGVyaXQ7XG4gICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICBmbGV4OiAxIDEgMCU7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cbi5zZWxlY3QtaWNvbiB7XG4gICAgd2lkdGg6IDE5cHg7XG4gICAgaGVpZ2h0OiAxOXB4O1xuICAgIG1hcmdpbi1sZWZ0OiAxOHB4O1xufVxuLnNlbGVjdC1pY29uIHtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgb3BhY2l0eTogMC4zMztcbn1cbmlvbi1zZWxlY3R7XG4gICAgbWF4LXdpZHRoOiAxMTdweDtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjRTQzMjJFO1xuICAgIGJvcmRlci1yYWRpdXM6IDlweDtcbiAgICBwYWRkaW5nOiA5cHg7XG59XG4ubm9yZWNvcmQtbGFiZWx7XG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2FucztcbiAgICBjb2xvcjojRTQzMjJFO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4uY3VzdG9tLW9wdGlvbnN7XG4gICAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cblxuLmN1c3RvbWVyLWZpbHRlcntcbiAgICB3aWR0aDogMTcwcHg7XG4gICAgbWF4LXdpZHRoOiAxNjBweDtcbiAgICBoZWlnaHQ6IDQwcHg7XG4gICAgcGFkZGluZzogMDtcbn1cbi5jdXN0b21lci1maWx0ZXI6OnBhcnQodGV4dCl7XG4gICAgcGFkZGluZzogMCAxMHB4O1xuICAgIGZvbnQtc2l6ZTogMTdweDtcbiAgICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuLmN1c3RvbWVyLWZpbHRlcjo6cGFydChpY29uKSB7XG4gICAgICAgIHdpZHRoOiA0NXB4ICFpbXBvcnRhbnQ7XG4gICAgICAgIGhlaWdodDogNDVweCAhaW1wb3J0YW50O1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTQzMjJFICFpbXBvcnRhbnQ7XG4gICAgICAgIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXIgIWltcG9ydGFudDtcbiAgICAgICAgb3BhY2l0eTogMTtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgKntcbiAgICAgICAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgICAgIH1cbiAgICAmOjphZnRlcntcbiAgICAgICAgY29udGVudDogXCJcIjtcbiAgICAgICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcvLi4vLi4vYXNzZXRzL2ltZ3MvZG93bi1hcnJvdy5wbmcnKTtcbiAgICAgICAgd2lkdGg6IDM1cHg7XG4gICAgICAgIGhlaWdodDogMThweDtcbiAgICAgICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTQzMjJlO1xuICAgICAgICB6LWluZGV4OiAxO1xuICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IDcwJTtcbiAgICAgICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgICB9XG59XG5cbiIsIi5tZW51X2J0biB7XG4gIGNvbG9yOiAjRTQzMjJFO1xufVxuXG4ubWFpbi10aXRsZSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICNFNDMyMkU7XG4gIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG59XG5cbi5vcmRlci1zdGF0dXMge1xuICBjb2xvcjogYmxhY2s7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIG1hcmdpbi1ib3R0b206IDVweDtcbiAgZm9udC1mYW1pbHk6IG9wZW4gc2Fucztcbn1cblxuLm1haW4tY2FyZCB7XG4gIGJveC1zaGFkb3c6IDVweCA3cHggMTBweCA1cHggI2U4ZThlODtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbn1cblxuLmRhdGUge1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICBjb2xvcjogYmxhY2s7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIG1hcmdpbi10b3A6IDBweDtcbn1cblxuLmQtZGF0ZSB7XG4gIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG4gIGNvbG9yOiAjMDAwO1xuICBmb250LXNpemU6IDE4cHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG59XG5cbi5zdGF0dXMge1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICBjb2xvcjogI0U0MzIyRTtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgbWFyZ2luLWJvdHRvbTogNXB4O1xufVxuXG4ubWFpbi1jb250ZW50IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0U0MzIyRTtcbn1cbi5tYWluLWNvbnRlbnQgLm9yZGVyLWlkcyB7XG4gIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LXNpemU6IDIwcHg7XG4gIG1hcmdpbjogMDtcbiAgcGFkZGluZzogM3B4O1xufVxuXG4uc2VsZWN0LXRleHQge1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICBtaW4td2lkdGg6IDE2cHg7XG4gIGZvbnQtc2l6ZTogaW5oZXJpdDtcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIGZsZXg6IDEgMSAwJTtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLnNlbGVjdC1pY29uIHtcbiAgd2lkdGg6IDE5cHg7XG4gIGhlaWdodDogMTlweDtcbiAgbWFyZ2luLWxlZnQ6IDE4cHg7XG59XG5cbi5zZWxlY3QtaWNvbiB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgb3BhY2l0eTogMC4zMztcbn1cblxuaW9uLXNlbGVjdCB7XG4gIG1heC13aWR0aDogMTE3cHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNFNDMyMkU7XG4gIGJvcmRlci1yYWRpdXM6IDlweDtcbiAgcGFkZGluZzogOXB4O1xufVxuXG4ubm9yZWNvcmQtbGFiZWwge1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xuICBjb2xvcjogI0U0MzIyRTtcbiAgZm9udC1zaXplOiAxOHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5jdXN0b20tb3B0aW9ucyB7XG4gIGZvbnQtZmFtaWx5OiBvcGVuIHNhbnM7XG59XG5cbi5jdXN0b21lci1maWx0ZXIge1xuICB3aWR0aDogMTcwcHg7XG4gIG1heC13aWR0aDogMTYwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgcGFkZGluZzogMDtcbn1cblxuLmN1c3RvbWVyLWZpbHRlcjo6cGFydCh0ZXh0KSB7XG4gIHBhZGRpbmc6IDAgMTBweDtcbiAgZm9udC1zaXplOiAxN3B4O1xuICBmb250LWZhbWlseTogb3BlbiBzYW5zO1xufVxuXG4uY3VzdG9tZXItZmlsdGVyOjpwYXJ0KGljb24pIHtcbiAgd2lkdGg6IDQ1cHggIWltcG9ydGFudDtcbiAgaGVpZ2h0OiA0NXB4ICFpbXBvcnRhbnQ7XG4gIGJhY2tncm91bmQtY29sb3I6ICNFNDMyMkUgIWltcG9ydGFudDtcbiAgZGlzcGxheTogZmxleCAhaW1wb3J0YW50O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlciAhaW1wb3J0YW50O1xuICBvcGFjaXR5OiAxO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLmN1c3RvbWVyLWZpbHRlcjo6cGFydChpY29uKSAqIHtcbiAgZGlzcGxheTogbm9uZTtcbn1cbi5jdXN0b21lci1maWx0ZXI6OnBhcnQoaWNvbik6OmFmdGVyIHtcbiAgY29udGVudDogXCJcIjtcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLy4uLy4uL2Fzc2V0cy9pbWdzL2Rvd24tYXJyb3cucG5nXCIpO1xuICB3aWR0aDogMzVweDtcbiAgaGVpZ2h0OiAxOHB4O1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XG4gIGJhY2tncm91bmQtY29sb3I6ICNlNDMyMmU7XG4gIHotaW5kZXg6IDE7XG4gIGJhY2tncm91bmQtc2l6ZTogNzAlO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/customer-orders/customer-orders.page.ts":
  /*!*********************************************************!*\
    !*** ./src/app/customer-orders/customer-orders.page.ts ***!
    \*********************************************************/

  /*! exports provided: CustomerOrdersPage */

  /***/
  function srcAppCustomerOrdersCustomerOrdersPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CustomerOrdersPage", function () {
      return CustomerOrdersPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../auth.service */
    "./src/app/auth.service.ts");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../common.service */
    "./src/app/common.service.ts");

    var CustomerOrdersPage = /*#__PURE__*/function () {
      function CustomerOrdersPage(datePipe, location, menu, navCtrl, commonService, auth) {
        var _this = this;

        _classCallCheck(this, CustomerOrdersPage);

        this.datePipe = datePipe;
        this.location = location;
        this.menu = menu;
        this.navCtrl = navCtrl;
        this.commonService = commonService;
        this.auth = auth;
        this.ordersList = [];
        this.selecTextStatus = {
          select: null
        };

        this.fngetOrderList = function (value) {
          _this.requestObject = {
            "order_status": value,
            "user_id": _this.user_id
          };

          _this.auth.showLoader();

          console.log(_this.requestObject);

          _this.auth.getOrderList(_this.requestObject).subscribe(function (data) {
            console.log(data);

            _this.auth.hideLoader();

            _this.dataResponse = data.data;
            _this.ordersList = _this.dataResponse;

            _this.ordersList.forEach(function (element) {
              // this.commonService.customerOrder.push();
              element.create_at = _this.datePipe.transform(new Date(element.create_at), "dd-MM-yyyy");
            });

            console.log("order list-->", _this.ordersList);
          }, function (err) {
            console.log("Error=>", err);

            _this.auth.hideLoader();
          });
        };

        this.selecTextStatus.select = "InProcess";
        this.menu.enable(true);
        this.user_id = localStorage.getItem("id");
        console.log("id-->", this.user_id);
      }

      _createClass(CustomerOrdersPage, [{
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          this.fngetOrderList(this.selecTextStatus.select);
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          this.url = this.commonService.url();
        }
      }, {
        key: "fnOrderSummary",
        value: function fnOrderSummary(id, order_number) {
          this.navCtrl.navigateForward('summary', {
            state: {
              id: id,
              order_number: order_number
            }
          });
        }
      }, {
        key: "OnChange",
        value: function OnChange(value) {
          this.status = value;
          console.log(this.status);
          this.fngetOrderList(value);
        }
      }, {
        key: "fnBackToYourCart",
        value: function fnBackToYourCart() {
          this.navCtrl.navigateRoot('dashboard');
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.location.back();
        }
      }, {
        key: "doRefresh",
        value: function doRefresh(event) {
          var _this2 = this;

          console.log('Begin async operation', event);
          setTimeout(function () {
            console.log('Async operation has ended');

            _this2.fngetOrderList(_this2.selecTextStatus.select);

            event.target.complete();
          }, 2000);
        }
      }]);

      return CustomerOrdersPage;
    }();

    CustomerOrdersPage.ctorParameters = function () {
      return [{
        type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"]
      }, {
        type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["Location"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"]
      }, {
        type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]
      }];
    };

    CustomerOrdersPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-customer-orders',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./customer-orders.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/customer-orders/customer-orders.page.html"))["default"],
      providers: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"]],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./customer-orders.page.scss */
      "./src/app/customer-orders/customer-orders.page.scss"))["default"]]
    })], CustomerOrdersPage);
    /***/
  }
}]);
//# sourceMappingURL=customer-orders-customer-orders-module-es5.js.map