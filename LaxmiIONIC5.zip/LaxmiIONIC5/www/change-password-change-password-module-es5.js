function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["change-password-change-password-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/change-password/change-password.page.html":
  /*!*************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/change-password/change-password.page.html ***!
    \*************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppChangePasswordChangePasswordPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-icon name=\"arrow-back-outline\" class=\"backarrow1\" (click)=\"goBack()\"></ion-icon>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-button>\n\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"main-title\">Change Password</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"main-content\">\n    <h4 class=\"password-txt\"><b>Change Password</b></h4>\n  </div>\n  <div class=\"main-content\">\n    <form [formGroup]=\"ionicForm\" novalidate>\n      <div class=\"order-no-bg\">\n        <ion-input placeholder=\"Old Password\" formControlName=\"oldPass\" [(ngModel)]=\"oldPass\" type=\"password\"\n          class=\"order_no_txt\"></ion-input>\n        <span class=\"error-wrap\" *ngIf=\"ionicForm.get('oldPass').touched || ionicForm.get('oldPass').dirty\">\n          <small *ngIf=\"ionicForm.get('oldPass').hasError('required')\" class=\"error\">Password is required.</small>\n          <small *ngIf=\"ionicForm.get('oldPass').hasError('minlength')\" class=\"error\">Password should be minimum 6\n            digits.</small>\n        </span>\n      </div>\n\n      <div class=\"order-no-bg\">\n        <ion-input placeholder=\"New Password\" formControlName=\"newPass\" [(ngModel)]=\"newPass\" type=\"password\"\n          class=\"order_no_txt\"></ion-input>\n        <span class=\"error-wrap\"\n          *ngIf=\"ionicForm.get('newPass').touched || ionicForm.get('newPass').dirty || formSubmitclicked\">\n          <small *ngIf=\"ionicForm.get('newPass').hasError('required')\" class=\"error\">Password is required.</small>\n          <small *ngIf=\"ionicForm.get('newPass').hasError('minlength')\" class=\"error\">Password should be minimum 6\n            digits.</small>\n        </span>\n      </div>\n    </form>\n  </div>\n\n  <!-- <button ion-button class=\"ChangePassword_btn\" >Change Password</button> -->\n  <button ion-button class=\"ChangePassword_btn\" (click)=\"fnChangePassword()\">Change Password</button>\n\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/change-password/change-password-routing.module.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/change-password/change-password-routing.module.ts ***!
    \*******************************************************************/

  /*! exports provided: ChangePasswordPageRoutingModule */

  /***/
  function srcAppChangePasswordChangePasswordRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ChangePasswordPageRoutingModule", function () {
      return ChangePasswordPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _change_password_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./change-password.page */
    "./src/app/change-password/change-password.page.ts");

    var routes = [{
      path: '',
      component: _change_password_page__WEBPACK_IMPORTED_MODULE_3__["ChangePasswordPage"]
    }];

    var ChangePasswordPageRoutingModule = function ChangePasswordPageRoutingModule() {
      _classCallCheck(this, ChangePasswordPageRoutingModule);
    };

    ChangePasswordPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ChangePasswordPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/change-password/change-password.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/change-password/change-password.module.ts ***!
    \***********************************************************/

  /*! exports provided: ChangePasswordPageModule */

  /***/
  function srcAppChangePasswordChangePasswordModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ChangePasswordPageModule", function () {
      return ChangePasswordPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _change_password_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./change-password-routing.module */
    "./src/app/change-password/change-password-routing.module.ts");
    /* harmony import */


    var _change_password_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./change-password.page */
    "./src/app/change-password/change-password.page.ts");

    var ChangePasswordPageModule = function ChangePasswordPageModule() {
      _classCallCheck(this, ChangePasswordPageModule);
    };

    ChangePasswordPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _change_password_routing_module__WEBPACK_IMPORTED_MODULE_5__["ChangePasswordPageRoutingModule"]],
      declarations: [_change_password_page__WEBPACK_IMPORTED_MODULE_6__["ChangePasswordPage"]]
    })], ChangePasswordPageModule);
    /***/
  },

  /***/
  "./src/app/change-password/change-password.page.scss":
  /*!***********************************************************!*\
    !*** ./src/app/change-password/change-password.page.scss ***!
    \***********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppChangePasswordChangePasswordPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".menu_btn {\n  color: #E4322E;\n}\n\n.main-title {\n  text-align: center;\n  color: #E4322E;\n}\n\n.error-wrap {\n  color: #E4322E;\n}\n\n.order-no-bg {\n  background-color: #f5f0f0;\n  width: 90%;\n  height: 45px;\n  margin-left: 20px;\n  border-radius: 7px;\n  margin-top: 20px;\n}\n\n.order_no_txt {\n  text-align: start;\n  color: #010944;\n  margin-left: 10px;\n  margin-bottom: 4px;\n}\n\n.password-txt {\n  color: #E4322E;\n  margin: 25px;\n}\n\n.ChangePassword_btn {\n  background-color: #E4322E;\n  color: #fff;\n  font-size: 20px;\n  height: 45px;\n  width: 90%;\n  border-radius: 10px;\n  display: block;\n  margin: auto;\n  border: 1px solid #fff;\n  margin-left: 19px;\n  margin-top: 25%;\n}\n\n.main-content {\n  margin-top: 18%;\n}\n\n.error-wrap {\n  color: red;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9jaGFuZ2UtcGFzc3dvcmQvY2hhbmdlLXBhc3N3b3JkLnBhZ2Uuc2NzcyIsInNyYy9hcHAvY2hhbmdlLXBhc3N3b3JkL2NoYW5nZS1wYXNzd29yZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRyxjQUFBO0FDQ0g7O0FEQ0E7RUFDSSxrQkFBQTtFQUNBLGNBQUE7QUNFSjs7QURBQztFQUNFLGNBQUE7QUNHSDs7QUREQztFQUNHLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUNJSjs7QURGQTtFQUNHLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUNLSDs7QURIQTtFQUNJLGNBQUE7RUFDQSxZQUFBO0FDTUo7O0FESkM7RUFDRyx5QkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUNPSjs7QURMQztFQUNHLGVBQUE7QUNRSjs7QUROQztFQUNFLFVBQUE7QUNTSCIsImZpbGUiOiJzcmMvYXBwL2NoYW5nZS1wYXNzd29yZC9jaGFuZ2UtcGFzc3dvcmQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1lbnVfYnRue1xuICAgY29sb3I6ICNFNDMyMkU7XG59XG4ubWFpbi10aXRsZXtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICNFNDMyMkU7XG4gfVxuIC5lcnJvci13cmFwe1xuICAgY29sb3I6I0U0MzIyRTtcbiB9XG4gLm9yZGVyLW5vLWJne1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmNWYwZjA7XG4gICAgd2lkdGg6IDkwJTtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XG4gICAgYm9yZGVyLXJhZGl1czogN3B4O1xuICAgIG1hcmdpbi10b3A6IDIwcHg7XG59XG4ub3JkZXJfbm9fdHh0e1xuICAgdGV4dC1hbGlnbjogc3RhcnQ7XG4gICBjb2xvcjogIzAxMDk0NDtcbiAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgbWFyZ2luLWJvdHRvbTogNHB4O1xufVxuLnBhc3N3b3JkLXR4dHtcbiAgICBjb2xvcjogI0U0MzIyRTtcbiAgICBtYXJnaW46IDI1cHg7XG4gfVxuIC5DaGFuZ2VQYXNzd29yZF9idG57XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0U0MzIyRTtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIHdpZHRoOiA5MCU7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBtYXJnaW46IGF1dG87XG4gICAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbiAgICBtYXJnaW4tbGVmdDogMTlweDtcbiAgICBtYXJnaW4tdG9wOiAyNSU7XG4gfVxuIC5tYWluLWNvbnRlbnR7XG4gICAgbWFyZ2luLXRvcDoxOCU7XG4gfVxuIC5lcnJvci13cmFwe1xuICAgY29sb3I6IHJlZDtcbiB9IiwiLm1lbnVfYnRuIHtcbiAgY29sb3I6ICNFNDMyMkU7XG59XG5cbi5tYWluLXRpdGxlIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI0U0MzIyRTtcbn1cblxuLmVycm9yLXdyYXAge1xuICBjb2xvcjogI0U0MzIyRTtcbn1cblxuLm9yZGVyLW5vLWJnIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjBmMDtcbiAgd2lkdGg6IDkwJTtcbiAgaGVpZ2h0OiA0NXB4O1xuICBtYXJnaW4tbGVmdDogMjBweDtcbiAgYm9yZGVyLXJhZGl1czogN3B4O1xuICBtYXJnaW4tdG9wOiAyMHB4O1xufVxuXG4ub3JkZXJfbm9fdHh0IHtcbiAgdGV4dC1hbGlnbjogc3RhcnQ7XG4gIGNvbG9yOiAjMDEwOTQ0O1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgbWFyZ2luLWJvdHRvbTogNHB4O1xufVxuXG4ucGFzc3dvcmQtdHh0IHtcbiAgY29sb3I6ICNFNDMyMkU7XG4gIG1hcmdpbjogMjVweDtcbn1cblxuLkNoYW5nZVBhc3N3b3JkX2J0biB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNFNDMyMkU7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LXNpemU6IDIwcHg7XG4gIGhlaWdodDogNDVweDtcbiAgd2lkdGg6IDkwJTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbjogYXV0bztcbiAgYm9yZGVyOiAxcHggc29saWQgI2ZmZjtcbiAgbWFyZ2luLWxlZnQ6IDE5cHg7XG4gIG1hcmdpbi10b3A6IDI1JTtcbn1cblxuLm1haW4tY29udGVudCB7XG4gIG1hcmdpbi10b3A6IDE4JTtcbn1cblxuLmVycm9yLXdyYXAge1xuICBjb2xvcjogcmVkO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/change-password/change-password.page.ts":
  /*!*********************************************************!*\
    !*** ./src/app/change-password/change-password.page.ts ***!
    \*********************************************************/

  /*! exports provided: ChangePasswordPage */

  /***/
  function srcAppChangePasswordChangePasswordPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ChangePasswordPage", function () {
      return ChangePasswordPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../auth.service */
    "./src/app/auth.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");

    var ChangePasswordPage = /*#__PURE__*/function () {
      function ChangePasswordPage(location, navCtrl, formbulider, menu, auth, toast) {
        _classCallCheck(this, ChangePasswordPage);

        this.location = location;
        this.navCtrl = navCtrl;
        this.formbulider = formbulider;
        this.menu = menu;
        this.auth = auth;
        this.toast = toast;
        this.menu.enable(true);
        this.role = localStorage.getItem("role");
        console.log(this.role);
      }

      _createClass(ChangePasswordPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.user_id = localStorage.getItem("id");
          console.log(this.user_id);
          this.ionicForm = this.formbulider.group({
            oldPass: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].minLength(6), _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].maxLength(6)]],
            newPass: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].minLength(6), _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].maxLength(6)]]
          });
        }
      }, {
        key: "fnChangePassword",
        value: function fnChangePassword() {
          var _this = this;

          if (this.oldPass != null && this.newPass != null) {
            this.auth.showLoader(); // if (this.newPass.length >= 6 && this.oldPass.length >=6) {

            this.requestObject = {
              "user_id": this.user_id,
              "old_password": this.oldPass,
              "password": this.newPass
            }; // console.log(this.requestObject);

            this.auth.changePassword(this.requestObject).subscribe(function (data) {
              _this.auth.hideLoader(); //  console.log(data);


              _this.dataResponse = data;

              if (_this.dataResponse.status == true) {
                if (_this.role == 'Customer') {
                  _this.navCtrl.navigateRoot('/dashboard');

                  _this.auth.showToast('Password Successfully Updated ');
                } else if (_this.role == 'DeliveryBoy') {
                  _this.navCtrl.navigateRoot('/my-account');

                  _this.auth.showToast('Password Successfully Updated ');
                } else if (_this.role == 'Salesman') {
                  _this.navCtrl.navigateRoot('/sales-dashboard');

                  _this.auth.showToast('Password Successfully Updated ');
                } else {
                  _this.auth.showToast('Password Not update ');
                } //this.auth.showToast('Password Successfully Updated ');
                //this.navCtrl.navigateForward('/dashboard');

              } else {
                _this.auth.showToast('Old password not match ');
              }
            }, function (err) {
              _this.auth.hideLoader();

              console.log("Error=>", err); //this.auth.showError(err.error.message);
            }); // } else {
            //   this.auth.showToast('Please Enter Old Password & New Password should be 6 digits');
            // }
          } else {
            console.log("please enter all fields");
            this.auth.showToast('Please enter old & new password');
          }
        }
      }, {
        key: "fnBackToYourCart",
        value: function fnBackToYourCart() {
          if (this.role == 'Customer') {
            this.navCtrl.navigateRoot('/dashboard');
          } else if (this.role == 'Salesman') {
            this.navCtrl.navigateRoot('/sales-dashboard');
          } else {
            this.navCtrl.navigateRoot('/my-account');
          }
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.location.back();
        }
      }]);

      return ChangePasswordPage;
    }();

    ChangePasswordPage.ctorParameters = function () {
      return [{
        type: _angular_common__WEBPACK_IMPORTED_MODULE_5__["Location"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"]
      }, {
        type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }];
    };

    ChangePasswordPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-change-password',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./change-password.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/change-password/change-password.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./change-password.page.scss */
      "./src/app/change-password/change-password.page.scss"))["default"]]
    })], ChangePasswordPage);
    /***/
  }
}]);
//# sourceMappingURL=change-password-change-password-module-es5.js.map