(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["product-list-product-list-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/product-list/product-list.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/product-list/product-list.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\" >\n      <ion-icon name=\"arrow-back-outline\" class=\"backarrow1\" (click)=\"goBack()\"></ion-icon>\n    </ion-buttons>\n  \n    <!-- <ion-buttons slot=\"end\">\n      <ion-button>\n        <img src=\"../../assets/imgs/buy (3).png\" class=\"img\" (click)=\"fnAddToCart()\">\n      </ion-button>\n    </ion-buttons> -->\n  \n    <ion-title class=\"main-title\">Select Product</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n<div *ngFor=\"let item of lazyListProduct;\">\n  <ion-card (click)=\"showModal(item)\">\n    <ion-grid>\n      <ion-row >\n         <ion-col size=\"4\" *ngIf=\"item.images\">\n          <img *ngIf=\"item.images.length > 0\" src=\"{{url.file_url}}assets/uploads/products/thumbs/{{item.images[0].product_image}}\" style=\"width:100%;\">\n          <img *ngIf=\"item.images.length == 0\" src=\"../../assets/imgs/not_found.png\" style=\"width:100%;\"> \n        </ion-col> \n    \n        <ion-col>\n          <h5 class=\"p-label1 product-name-size\"><b>{{item.product_name}} {{item.product_weight}}Kg</b></h5>\n          <h6 class=\"p-label product-price-size\">₹{{item.product_price}}</h6>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-card>\n</div> \n\n  <ion-infinite-scroll (ionInfinite)=\"doInfinite($event)\" *ngIf=\"!isloadmore\">\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"Loading more data...\">\n    </ion-infinite-scroll-content>\n</ion-infinite-scroll>\n</ion-content>");

/***/ }),

/***/ "./src/app/product-list/product-list-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/product-list/product-list-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: ProductListPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductListPageRoutingModule", function() { return ProductListPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _product_list_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./product-list.page */ "./src/app/product-list/product-list.page.ts");




const routes = [
    {
        path: '',
        component: _product_list_page__WEBPACK_IMPORTED_MODULE_3__["ProductListPage"]
    }
];
let ProductListPageRoutingModule = class ProductListPageRoutingModule {
};
ProductListPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ProductListPageRoutingModule);



/***/ }),

/***/ "./src/app/product-list/product-list.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/product-list/product-list.module.ts ***!
  \*****************************************************/
/*! exports provided: ProductListPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductListPageModule", function() { return ProductListPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _product_list_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./product-list-routing.module */ "./src/app/product-list/product-list-routing.module.ts");
/* harmony import */ var _product_list_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./product-list.page */ "./src/app/product-list/product-list.page.ts");







let ProductListPageModule = class ProductListPageModule {
};
ProductListPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _product_list_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProductListPageRoutingModule"]
        ],
        declarations: [_product_list_page__WEBPACK_IMPORTED_MODULE_6__["ProductListPage"]]
    })
], ProductListPageModule);



/***/ }),

/***/ "./src/app/product-list/product-list.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/product-list/product-list.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".main-title {\n  text-align: center;\n  color: #E4322E;\n  font-size: 15px;\n  margin-right: 30px;\n}\n\n.img {\n  float: right;\n}\n\n.img1 {\n  font-size: 24px;\n  float: left;\n}\n\n.card {\n  box-shadow: 5px 7px 10px 5px #e8e8e8;\n  background-color: #fff;\n  width: 87%;\n  margin: 25px;\n}\n\n.p-label {\n  color: #010944;\n  margin: 0;\n  margin-left: 10px;\n}\n\n.p-label1 {\n  margin-bottom: 4px;\n  margin-left: 10px;\n  color: #E4322E;\n}\n\n.backarrow1 {\n  margin-left: 10px;\n  color: #E4322E;\n  font-size: 26px;\n}\n\n@media only screen and (min-device-width: 768px) and (max-device-width: 1024px) {\n  .product-name-size {\n    font-size: 38px;\n  }\n\n  .product-price-size {\n    font-size: 28px;\n  }\n\n  .card-first {\n    height: auto;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy95YXNoY29tcHV0ZXJzL0Rlc2t0b3AvQXJzaGFkIFdvcmtzcGFjZS9Jb25pY1dvcmtTcGFjZS9sYWtzaG1pLWZvb2Qvc3JjL2FwcC9wcm9kdWN0LWxpc3QvcHJvZHVjdC1saXN0LnBhZ2Uuc2NzcyIsInNyYy9hcHAvcHJvZHVjdC1saXN0L3Byb2R1Y3QtbGlzdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUNDSjs7QURDQztFQUVHLFlBQUE7QUNDSjs7QURDQztFQUVHLGVBQUE7RUFDQSxXQUFBO0FDQ0o7O0FEQ0M7RUFDRyxvQ0FBQTtFQUNBLHNCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUNFSjs7QURBQTtFQUNJLGNBQUE7RUFDQSxTQUFBO0VBQ0EsaUJBQUE7QUNHSjs7QUREQTtFQUNJLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FDSUo7O0FERkE7RUFDSSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0FDS0o7O0FESEE7RUFHSTtJQUFtQixlQUFBO0VDS3JCOztFREpFO0lBQW9CLGVBQUE7RUNRdEI7O0VEUEU7SUFBWSxZQUFBO0VDV2Q7QUFDRiIsImZpbGUiOiJzcmMvYXBwL3Byb2R1Y3QtbGlzdC9wcm9kdWN0LWxpc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1haW4tdGl0bGV7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjRTQzMjJFO1xuICAgIGZvbnQtc2l6ZTogMTVweDsgXG4gICAgbWFyZ2luLXJpZ2h0OiAzMHB4XG4gfVxuIC5pbWd7XG5cbiAgICBmbG9hdDogcmlnaHQ7XG4gfVxuIC5pbWcxe1xuXG4gICAgZm9udC1zaXplOiAyNHB4O1xuICAgIGZsb2F0OiBsZWZ0O1xuIH1cbiAuY2FyZHtcbiAgICBib3gtc2hhZG93OiA1cHggN3B4IDEwcHggNXB4ICNlOGU4ZTg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgICB3aWR0aDogODclO1xuICAgIG1hcmdpbjogMjVweDtcbn1cbi5wLWxhYmVse1xuICAgIGNvbG9yOiAjMDEwOTQ0O1xuICAgIG1hcmdpbjogMDtcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbn1cbi5wLWxhYmVsMXtcbiAgICBtYXJnaW4tYm90dG9tOiA0cHg7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgY29sb3I6ICNFNDMyMkU7XG59XG4uYmFja2Fycm93MXtcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICBjb2xvcjogI0U0MzIyRTtcbiAgICBmb250LXNpemU6IDI2cHg7XG59XG5AbWVkaWEgb25seSBzY3JlZW4gXG5hbmQgKG1pbi1kZXZpY2Utd2lkdGggOiA3NjhweCkgXG5hbmQgKG1heC1kZXZpY2Utd2lkdGggOiAxMDI0cHgpIHtcbiAgICAucHJvZHVjdC1uYW1lLXNpemV7Zm9udC1zaXplOiAzOHB4O31cbiAgICAucHJvZHVjdC1wcmljZS1zaXple2ZvbnQtc2l6ZTogMjhweDt9XG4gICAgLmNhcmQtZmlyc3R7aGVpZ2h0OiBhdXRvO31cbn1cblxuIiwiLm1haW4tdGl0bGUge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjRTQzMjJFO1xuICBmb250LXNpemU6IDE1cHg7XG4gIG1hcmdpbi1yaWdodDogMzBweDtcbn1cblxuLmltZyB7XG4gIGZsb2F0OiByaWdodDtcbn1cblxuLmltZzEge1xuICBmb250LXNpemU6IDI0cHg7XG4gIGZsb2F0OiBsZWZ0O1xufVxuXG4uY2FyZCB7XG4gIGJveC1zaGFkb3c6IDVweCA3cHggMTBweCA1cHggI2U4ZThlODtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgd2lkdGg6IDg3JTtcbiAgbWFyZ2luOiAyNXB4O1xufVxuXG4ucC1sYWJlbCB7XG4gIGNvbG9yOiAjMDEwOTQ0O1xuICBtYXJnaW46IDA7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuXG4ucC1sYWJlbDEge1xuICBtYXJnaW4tYm90dG9tOiA0cHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBjb2xvcjogI0U0MzIyRTtcbn1cblxuLmJhY2thcnJvdzEge1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgY29sb3I6ICNFNDMyMkU7XG4gIGZvbnQtc2l6ZTogMjZweDtcbn1cblxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWluLWRldmljZS13aWR0aDogNzY4cHgpIGFuZCAobWF4LWRldmljZS13aWR0aDogMTAyNHB4KSB7XG4gIC5wcm9kdWN0LW5hbWUtc2l6ZSB7XG4gICAgZm9udC1zaXplOiAzOHB4O1xuICB9XG5cbiAgLnByb2R1Y3QtcHJpY2Utc2l6ZSB7XG4gICAgZm9udC1zaXplOiAyOHB4O1xuICB9XG5cbiAgLmNhcmQtZmlyc3Qge1xuICAgIGhlaWdodDogYXV0bztcbiAgfVxufSJdfQ== */");

/***/ }),

/***/ "./src/app/product-list/product-list.page.ts":
/*!***************************************************!*\
  !*** ./src/app/product-list/product-list.page.ts ***!
  \***************************************************/
/*! exports provided: ProductListPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductListPage", function() { return ProductListPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _modal_popup_modal_popup_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../modal-popup/modal-popup.page */ "./src/app/modal-popup/modal-popup.page.ts");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth.service.ts");
/* harmony import */ var _common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../common.service */ "./src/app/common.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");








let ProductListPage = class ProductListPage {
    constructor(loadingCtrl, location, modalController, navCtrl, auth, commonService) {
        this.loadingCtrl = loadingCtrl;
        this.location = location;
        this.modalController = modalController;
        this.navCtrl = navCtrl;
        this.auth = auth;
        this.commonService = commonService;
        this.allProducts = [];
        this.lazyListProduct = [];
        this.page = 1;
        this.isloadmore = false;
        // this.getProductList(this.page);
        this.url = this.commonService.url();
    }
    ngOnInit() {
        this.getProductList(false, "");
    }
    /* async showModal(data) {
     const modal = await this.modalController.create({
       component: ModalPopupPage,
       cssClass: 'myModal',
       componentProps: {
         'name': data
       }
     });
     return await modal.present();
   } */
    goBack() {
        this.location.back();
    }
    fnBackToDashboard() {
        this.navCtrl.navigateRoot('dashboard');
    }
    fnAddToCart() {
        this.navCtrl.navigateRoot('your-cart');
    }
    getProductList(isFirstLoad, event) {
        if (isFirstLoad === false)
            this.showLoader();
        this.requestObject = {
            "page_no": this.page,
            "offset": "10"
        };
        this.auth.getProductDetails(this.requestObject).subscribe((data) => {
            this.hideLoader();
            this.dataResponse = data.data.product_data;
            for (let i = 0; i < this.dataResponse.length; i++) {
                this.lazyListProduct.push(this.dataResponse[i]);
            }
            if (isFirstLoad)
                event.target.complete();
            this.page++;
        }, (err) => {
            this.hideLoader();
            console.log("Error=>", err);
            //this.auth.showError(err.error.message);
        });
    }
    showLoader() {
        this.loadingCtrl.create({
            message: 'Please wait...'
        }).then((res) => {
            res.present();
        });
    }
    hideLoader() {
        this.loadingCtrl.dismiss().then((res) => {
            console.log('Loading dismissed!', res);
        }).catch((error) => {
            console.log('error', error);
        });
    }
    doInfinite(event) {
        this.getProductList(true, event);
    }
    showModal(data) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const presentModel = yield this.modalController.create({
                component: _modal_popup_modal_popup_page__WEBPACK_IMPORTED_MODULE_3__["ModalPopupPage"],
                componentProps: {
                    'name': data
                },
                showBackdrop: true,
                mode: "ios",
                cssClass: 'change-select-card-modal'
            });
            presentModel.onWillDismiss().then((data) => {
                console.log(data);
                //custom code
            });
            return yield presentModel.present();
        });
    }
};
ProductListPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_6__["Location"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] },
    { type: _common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"] }
];
ProductListPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-product-list',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./product-list.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/product-list/product-list.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./product-list.page.scss */ "./src/app/product-list/product-list.page.scss")).default]
    })
], ProductListPage);



/***/ })

}]);
//# sourceMappingURL=product-list-product-list-module-es2015.js.map